from flask import Blueprint, request, jsonify, render_template, redirect, url_for
from models import db, User
import bcrypt
from flask_jwt_extended import create_access_token
from datetime import timedelta

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json() or request.form
    u = data.get('username'); p = data.get('password')
    user = User.query.filter_by(username=u).first()
    if not user or not bcrypt.checkpw(p.encode(), user.password_hash.encode()):
        return jsonify({'msg': 'Bad username or password'}), 401
    token = create_access_token(identity=user.id, expires_delta=timedelta(hours=1))
    return jsonify({'access_token': token, 'user': user.to_dict()})

@auth_bp.route('/login-form', methods=['POST'])
def login_form():
    return login()
