from flask import Blueprint, request, render_template, redirect, url_for
from flask_jwt_extended import verify_jwt_in_request_optional, get_jwt_identity
from models import User

dash_bp = Blueprint('dash', __name__)

@dash_bp.route('/welcome')
def welcome():
    token = request.args.get('token')
    if token:
        request.environ['HTTP_AUTHORIZATION'] = 'Bearer ' + token
    try:
        verify_jwt_in_request_optional()
        uid = get_jwt_identity()
    except:
        uid = None
    user = User.query.get(uid) if uid else None
    if not user:
        return redirect(url_for('index'))
    return render_template('dashboard.html', user=user)
