import os
from app import create_app
from models import db, User
import bcrypt

app = create_app()

with app.app_context():
    db.create_all()

    username = os.getenv('SAMPLE_USER', 'alice')
    email = os.getenv('SAMPLE_EMAIL', 'alice@example.com')
    pwd = os.getenv('SAMPLE_PASSWORD', 'password123')

    if not User.query.filter_by(username=username).first():
        h = bcrypt.hashpw(pwd.encode(), bcrypt.gensalt()).decode()
        u = User(username=username, email=email, password_hash=h)
        db.session.add(u); db.session.commit()
