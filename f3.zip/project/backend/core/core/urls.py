"""
URL configuration for core project.

The `urlpatterns` list routes URLs to views. 
For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
"""

from django.contrib import admin
from django.urls import path, include

# JWT imports
from rest_framework_simplejwt.views import TokenRefreshView

# ✅ Import your custom JWT login view
from trains.views import CustomTokenObtainPairView


urlpatterns = [
    # Django Admin
    path('admin/', admin.site.urls),

    # ✅ Custom JWT endpoints
    path('api/token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    # ✅ App routes
    path('api/', include('trains.urls')),
]
