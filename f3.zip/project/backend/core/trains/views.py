import logging
import traceback
from rest_framework import generics, status, serializers
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, BasePermission
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django.contrib.auth.models import User
from .models import Train
from .serializers import TrainSerializer

# ------------------------------------------------------------------
# LOGGING CONFIGURATION
# ------------------------------------------------------------------
import os
LOG_DIR = os.path.join(os.path.dirname(__file__), "logs")
os.makedirs(LOG_DIR, exist_ok=True)

LOG_FILE = os.path.join(LOG_DIR, "app.log")

logging.basicConfig(
    level=logging.DEBUG,
    format="[%(asctime)s] [%(levelname)s] [%(filename)s:%(lineno)d] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8"),
        logging.StreamHandler(),  # also print to console
    ],
)
logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Custom permission – works with JWT
# ------------------------------------------------------------------
class IsAdminUser(BasePermission):
    def has_permission(self, request, view):
        allowed = request.user.is_authenticated and request.user.is_staff
        if not allowed:
            logger.warning(
                f"Unauthorized access attempt by user={request.user} at view={view.__class__.__name__}"
            )
        return allowed


# ------------------------------------------------------------------
# TRAIN CRUD – WITH LOGGING + ERROR HANDLING
# ------------------------------------------------------------------
class TrainListCreateView(generics.ListCreateAPIView):
    queryset = Train.objects.all()
    serializer_class = TrainSerializer
    permission_classes = [IsAuthenticated, IsAdminUser]

    def perform_create(self, serializer):
        try:
            serializer.save()
            logger.info("✅ Train created successfully.")
        except Exception as e:
            tb = traceback.format_exc()
            logger.error(f"❌ Error while creating Train: {e}\n{tb}")
            raise serializers.ValidationError(
                {"detail": f"Error while creating Train: {str(e)}"}
            )

    def list(self, request, *args, **kwargs):
        try:
            logger.debug(f"📥 Fetching train list requested by {request.user}")
            return super().list(request, *args, **kwargs)
        except Exception as e:
            tb = traceback.format_exc()
            logger.error(f"❌ Error listing trains: {e}\n{tb}")
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class TrainDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Train.objects.all()
    serializer_class = TrainSerializer
    permission_classes = [IsAuthenticated, IsAdminUser]
    lookup_field = 'train_number'  # /api/trains/<train_number>/

    def destroy(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            train_num = instance.train_number
            self.perform_destroy(instance)
            logger.info(f"🗑️ Train {train_num} deleted successfully.")
            return Response(
                {"message": f"Train {train_num} deleted successfully."},
                status=status.HTTP_200_OK,
            )
        except Exception as e:
            tb = traceback.format_exc()
            logger.error(f"❌ Error deleting train: {e}\n{tb}")
            return Response(
                {"error": f"Error deleting train: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


# ------------------------------------------------------------------
# CUSTOM JWT LOGIN (accepts username or email as identifier)
# ------------------------------------------------------------------
class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        identifier = attrs.get("username")
        password = attrs.get("password")

        try:
            user = None
            try:
                user = User.objects.get(username=identifier)
            except User.DoesNotExist:
                user = User.objects.get(email=identifier)

            if not user.check_password(password):
                logger.warning(f"⚠️ Incorrect password attempt for user={identifier}")
                raise serializers.ValidationError({"detail": "Incorrect password"})

            data = super().validate({"username": user.username, "password": password})
            logger.info(f"🔐 Token issued successfully for user={user.username}")
            return data

        except User.DoesNotExist:
            logger.error(f"❌ Invalid login identifier: {identifier}")
            raise serializers.ValidationError({"detail": "Invalid username or email"})

        except Exception as e:
            tb = traceback.format_exc()
            logger.error(f"❌ Unexpected error in login: {e}\n{tb}")
            raise serializers.ValidationError({"detail": f"Unexpected error: {str(e)}"})


class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer
