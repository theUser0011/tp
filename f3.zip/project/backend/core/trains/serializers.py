from rest_framework import serializers
from .models import Train, Station, Stop

# 🔹 Import for authentication
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
import logging, traceback

logger = logging.getLogger(__name__)

# ==========================
# 🔹  AUTH SERIALIZER
# ==========================
class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    """
    Custom login serializer that accepts email only.
    """

    def validate(self, attrs):
        email = attrs.get("username")  # frontend still sends 'username' field
        password = attrs.get("password")

        if not email or "@" not in email:
            raise serializers.ValidationError({"detail": "Please enter a valid email address."})

        try:
            # get user by email only
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            raise serializers.ValidationError({"detail": "Invalid email or password."})

        if not user.check_password(password):
            logger.warning(f"⚠️ Invalid password attempt for email={email}")
            raise serializers.ValidationError({"detail": "Invalid email or password."})

        # proceed with token creation
        data = super().validate({"username": user.username, "password": password})

        # include custom data
        data.update({
            "username": user.username,
            "email": user.email,
            "role": "admin" if user.is_staff else "customer"
        })

        logger.info(f"✅ Token issued for user={user.username}, role={data['role']}")
        return data

# ==========================
# 🔹  RAILWAY SERIALIZERS
# ==========================

class StationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Station
        fields = ['id', 'name']


class StopSerializer(serializers.ModelSerializer):
    station = StationSerializer(read_only=True)

    class Meta:
        model = Stop
        fields = ['station', 'arrival_time', 'departure_time', 'stop_order']


class TrainSerializer(serializers.ModelSerializer):
    # Write: Accept dict → create Station
    origin = serializers.DictField(write_only=True, required=False)
    destination = serializers.DictField(write_only=True, required=False)

    # Read: Return full Station object
    origin_detail = StationSerializer(source='origin', read_only=True)
    destination_detail = StationSerializer(source='destination', read_only=True)

    # Stops (read-only)
    intermediate_stops = StopSerializer(source='stop_set', many=True, read_only=True)

    class Meta:
        model = Train
        fields = [
            'id', 'train_number', 'train_name',
            'origin', 'destination',  # write
            'origin_detail', 'destination_detail',  # read
            'departure_time', 'arrival_time', 'travel_duration',
            'total_seats', 'intermediate_stops'
        ]
        read_only_fields = ['id', 'origin_detail', 'destination_detail', 'intermediate_stops']

    def validate_train_number(self, value):
        if self.instance is None and Train.objects.filter(train_number=value).exists():
            raise serializers.ValidationError("Train with this number already exists.")
        return value

    def validate(self, data):
        # Only validate origin/destination if BOTH are provided (e.g., during create or full update)
        if 'origin' in data and 'destination' in data:
            origin_name = data['origin']['name']
            dest_name = data['destination']['name']
            if origin_name == dest_name:
                raise serializers.ValidationError("Origin and destination cannot be the same.")
        return data

    def create(self, validated_data):
        origin_data = validated_data.pop('origin')
        destination_data = validated_data.pop('destination')

        origin, _ = Station.objects.get_or_create(name=origin_data['name'])
        destination, _ = Station.objects.get_or_create(name=destination_data['name'])

        train = Train.objects.create(
            origin=origin,
            destination=destination,
            **validated_data
        )
        return train

    def update(self, instance, validated_data):
        # Handle origin/destination update if provided
        if 'origin' in validated_data:
            origin_data = validated_data.pop('origin')
            origin, _ = Station.objects.get_or_create(name=origin_data['name'])
            instance.origin = origin

        if 'destination' in validated_data:
            destination_data = validated_data.pop('destination')
            destination, _ = Station.objects.get_or_create(name=destination_data['name'])
            instance.destination = destination

        # Update other fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        instance.save()
        return instance
