from django.urls import path
from .views import TrainListCreateView, TrainDetailView

urlpatterns = [
    # ------------------------------------------------------------------
    # 🔹 TRAIN CRUD ENDPOINTS
    # ------------------------------------------------------------------
    path('trains/', TrainListCreateView.as_view(), name='train-list-create'),
    path('trains/<str:train_number>/', TrainDetailView.as_view(), name='train-detail'),
]
