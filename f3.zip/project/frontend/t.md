# Sprint 1 — Project: Train Ticket Booking (Frontend + Minimal Backend)

This document explains **detailed steps** and **exact files/folders** to copy from your existing `D:\temp\f2\src` into a *new project* (Vite + React) so you can quickly deliver Sprint 1 (Admin + Customer basic pages & auth). It also includes a minimal backend (Express + Mongoose) scaffold, commands, placeholder code and a sprint checklist mapped to the user stories.

---

## 0. Prerequisites

* Node.js 18+ and npm/yarn
* Git (optional)
* MongoDB instance (local or Atlas) — for sprint you can also use an in-memory store but instructions below use MongoDB.
* Windows terminal / PowerShell or WSL

---

## 1. Create new projects (frontend + backend)

Run from a parent folder (example `D:\projects\train-app`):

```bash
# frontend
npm create vite@latest train-frontend -- --template react
cd train-frontend
npm install

# backend (new terminal)
mkdir train-backend
cd train-backend
npm init -y
npm install express mongoose cors dotenv bcryptjs jsonwebtoken
```

## 2. Frontend: copy structure & important files

From your existing `D:\temp\f2\src` copy these files/folders into `train-frontend/src` (replace or merge):

```
src/
  App.jsx            <- copy (or use the App.jsx you provided)
  main.jsx           <- copy (entry file)
  index.css
  App.css
  assets/            <- copy folder
  components/
    AdminSidebar.jsx
    CustomerSidebar.jsx
    Header.jsx
    ProtectedRoute.jsx
    figma/ImageWithFallback.jsx
    ui/ (copy any shared UI small components)
  pages/
    LandingPage.jsx
    Login.jsx
    Register.jsx
    admin/
      AdminDashboard.jsx
      TrainList.jsx
      TrainRegistration.jsx
      TrainUpdate.jsx
    customer/
      BookingForm.jsx
      BookingHistory.jsx
      CancelTicket.jsx
      CustomerDashboard.jsx
      CustomerProfile.jsx
      DeactivateAccount.jsx
      TicketDetails.jsx
      TrainSearch.jsx
  styles/
    globals.css
```

**Notes / quick edits after copy**

* Ensure all imports are relative and correct (e.g. `import LandingPage from './pages/LandingPage'` vs named export). If a file exported `export default`, import without braces.
* Install packages used in your components: `npm i react-router-dom @mui/material @emotion/react @emotion/styled react-toastify bootstrap`.
* If you used `.jsx` vs `.js` extensions, keep them consistent with `vite` resolve.

## 3. Frontend: minimal placeholder content to satisfy Sprint 1

For Sprint 1 acceptance you only need pages to render and navigation + protected routes. Replace heavy content with placeholders:

* **LandingPage.jsx** — simple hero with buttons linking to `/login` and `/register`.
* **Login.jsx** — form (email/password). On success, store a fake JWT + role (`admin` or `customer`) in `localStorage` and navigate to `/admin/dashboard` or `/customer/dashboard` accordingly. Use the **ProtectedRoute** component to read role.
* **Register.jsx** — very basic registration form that posts to backend `/api/auth/register`.

The App.jsx you supplied already configures routes; keep it.

## 4. ProtectedRoute (important)

If your existing `ProtectedRoute.jsx` uses context, ensure it checks `localStorage.token` and `localStorage.role` as fallback so sprint works without full backend JWT verification. Example behavior for sprint:

* If no token -> redirect to `/login`.
* If `requiredRole` is provided and `localStorage.role !== requiredRole` -> redirect to `/login` or landing.

(Leave note to replace with real token verification later.)

## 5. Backend: folder layout and minimal endpoints

Create `train-backend/` with:

```
train-backend/
  server.js
  routes/
    auth.js
    trains.js
  controllers/
    authController.js
    trainController.js
  models/
    User.js
    Train.js
  .env
  package.json
```

### server.js (minimal)

```js
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const trainRoutes = require('./routes/trains');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/trains', trainRoutes);

const PORT = process.env.PORT || 5000;
mongoose.connect(process.env.MONGO_URI)
  .then(()=> app.listen(PORT, ()=> console.log('Server up', PORT)))
  .catch(err => console.error(err));
```

### routes/auth.js (skeleton)

```js
const router = require('express').Router();
const { register, login } = require('../controllers/authController');
router.post('/register', register);
router.post('/login', login);
module.exports = router;
```

### controllers/authController.js (skeleton)

* `register(req,res)` -> create User (name,email,password hashed, role default `customer`).
* `login(req,res)` -> validate & return `{ token, role }` (for sprint you can return a simple signed JWT or a fake token string).

### models/User.js (mongoose)

Fields: `name, email (unique), password, role ('admin'|'customer'), active (boolean)`

### routes/trains.js

* `GET /` list trains
* `POST /` create train (admin only)
* `PUT /:id` update
* `DELETE /:id` delete

For sprint, skip complex schedule validation; leave TODOs.

## 6. Environment (.env)

```
MONGO_URI=mongodb+srv://<user>:<pass>@cluster.../trainapp
JWT_SECRET=verysecret
PORT=5000
```

## 7. Frontend <-> Backend wiring

* In frontend, create `src/api/index.js` with basic axios client:

```js
import axios from 'axios';
const API = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api' });
export default API;
```

* Use `API.post('/auth/login', payload)` etc.
* Add `.env` in frontend root:

```
VITE_API_URL=http://localhost:5000/api
```

## 8. Quick placeholder code examples (Login flow)

* On `Login.jsx` submit -> `POST /api/auth/login` -> if success set:

```js
localStorage.setItem('token', res.data.token);
localStorage.setItem('role', res.data.role);
// redirect based on role
```

* On app load ProtectedRoute reads `localStorage.role`.

## 9. Files to create in new project (copy + small edits)

1. `src/App.jsx` — (copy provided) ensure `import 'bootstrap/dist/css/bootstrap.min.css';` installed
2. `src/main.jsx` — ensure `ReactDOM.createRoot(...).render(<App />)`
3. `src/components/ProtectedRoute.jsx` — ensure simple role check
4. `src/pages/Login.jsx`, `Register.jsx`, `LandingPage.jsx` — replace contents with minimal working forms
5. `src/pages/admin/*` and `src/pages/customer/*` — keep but inside each file put placeholder content like `<div>This is Admin Dashboard (empty for sprint)</div>`
6. `src/styles/globals.css` and `src/index.css` and `src/App.css` — copy

## 10. Commands to run

Terminal 1 (backend):

```bash
cd train-backend
node server.js
```

Terminal 2 (frontend):

```bash
cd train-frontend
npm run dev
```

## 11. Sprint 1 acceptance checklist (mapped to user stories)

* [x] US001: Admin menu -> implemented as AdminDashboard with links to Train Registration / Train List (placeholders)
* [x] US002: Admin Train Registration -> page + backend `POST /api/trains` (basic validation: unique train number)
* [x] US003: Train update -> page + backend `PUT /api/trains/:id`
* [x] US004: Delete train -> backend `DELETE /api/trains/:id` and mark bookings (for sprint, mark TODO)
* [x] US005..US012: Customer pages exist as placeholders and Login/Register route + basic auth

## 12. Suggested minimal UI placeholders (examples)

* `AdminDashboard.jsx` contains buttons linking to `/admin/train-register` and `/admin/train-list`.
* `TrainRegistration.jsx` contains a form: Train Number, Train Name, Origin, Destination, Departure Time, Arrival Time -> posts to backend.

## 13. Testing

* Use Postman or curl to test backend endpoints.
* After login, check `localStorage` values and try to access `/admin/dashboard` as customer to verify ProtectedRoute redirects.

## 14. Next steps (after sprint 1)

* Replace placeholder pages with real UI and table lists.
* Implement seat availability logic, fare calculation, refund policy logic.
* Add e2e tests and CI.

---

### Appendix: Useful snippets (copy into project)

* `package.json` (backend) `scripts`: `"start": "node server.js"`
* `package.json` (frontend) add any missing dependencies.

---

If you want, I can also generate the minimal `server.js`, `models/User.js`, `routes/auth.js`, and a compact `Login.jsx` + `ProtectedRoute.jsx` ready to paste into your new project. Tell me if you prefer MongoDB or an in-memory fake store for the backend (I can include code).
