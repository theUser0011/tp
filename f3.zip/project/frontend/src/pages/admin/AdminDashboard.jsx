import React from 'react';
import { useNavigate } from 'react-router-dom';
import { AdminSidebar } from '../../components/AdminSidebar';
import { Header } from '../../components/Header';
import { getDashboardData } from '../../components/common/adminStyles';
import { logout } from '../../utils/logout';
import '../../styles/AdminDashboard.css';

export const AdminDashboard = () => {
  const navigate = useNavigate();
  const { stats, recentBookings, popularRoutes } = getDashboardData();

  const handleLogout = () => {
    logout(navigate, true);
  };

  return (
    <div className="admin-dashboard d-flex bg-light min-vh-100">
      {/* Sidebar */}
      <AdminSidebar />

      {/* Main Content */}
      <div className="dashboard-content flex-grow-1 p-4" style={{ marginLeft: '280px' }}>
        {/* Header */}
        <Header title="Admin Dashboard" />

        {/* Logout Button */}
        <div className="text-end mb-4 d-md-none">
          {/* optional small-screen logout */}
          <button className="btn btn-danger px-4 py-2 fw-semibold shadow-sm" onClick={handleLogout}>
            Logout
          </button>
        </div>

        {/* Stats Section */}
        <div className="row g-4 m-4">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div
                className="col-12 col-sm-6 col-lg-3 fade-in"
                key={index}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="card border-0 shadow-sm stat-card h-100">
                  <div
                    className="card-body"
                    style={{
                      borderTop: `4px solid ${stat.color}`,
                      borderRadius: '8px 8px 0 0',
                    }}
                  >
                    <div className="d-flex justify-content-between align-items-start mb-2">
                      <div
                        className="icon-wrapper d-flex align-items-center justify-content-center rounded-circle"
                        style={{
                          background: stat.gradient,
                          width: '60px',
                          height: '60px',
                          boxShadow: `0 5px 15px ${stat.color}55`,
                        }}
                      >
                        <Icon size={28} color="#fff" />
                      </div>
                    </div>
                    <h3 className="fw-bold mb-1">{stat.value}</h3>
                    <p className="text-muted mb-1">{stat.title}</p>
                    <small className="text-success fw-semibold">
                      <i className="bi bi-graph-up"></i> {stat.change}
                    </small>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Recent Bookings and Popular Routes */}
        <div className="row g-4">
          {/* Recent Bookings */}
          <div className="col-12 col-lg-6">
            <div className="card shadow-sm border-0 h-100 fade-in">
              <div className="card-body">
                <h5 className="fw-bold gradient-text mb-3">Recent Bookings</h5>
                {recentBookings.map((booking, idx) => (
                  <div
                    key={booking.id}
                    className="booking-item d-flex justify-content-between align-items-center p-3 mb-2 rounded"
                    style={{ animationDelay: `${idx * 0.1}s` }}
                  >
                    <div>
                      <p className="fw-semibold mb-1">{booking.train}</p>
                      <small className="text-muted">{booking.customer} • {booking.date}</small>
                    </div>
                    <div className="text-end">
                      <p className="fw-semibold text-primary mb-0">{booking.amount}</p>
                      <small className="text-muted">{booking.id}</small>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Popular Routes */}
          <div className="col-12 col-lg-6">
            <div className="card shadow-sm border-0 h-100 fade-in">
              <div className="card-body">
                <h5 className="fw-bold gradient-text mb-3">Popular Routes</h5>
                {popularRoutes.map((route, idx) => (
                  <div key={idx} className="mb-4 route-item" style={{ animationDelay: `${idx * 0.1}s` }}>
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <p className="fw-semibold mb-0">{route.route}</p>
                      <span
                        className="badge rounded-pill"
                        style={{
                          backgroundColor: `${route.color}20`,
                          color: route.color,
                          border: `1px solid ${route.color}40`,
                        }}
                      >
                        {route.bookings} bookings
                      </span>
                    </div>
                    <div className="progress" style={{ height: '8px' }}>
                      <div
                        className="progress-bar"
                        role="progressbar"
                        style={{
                          width: `${route.percentage}%`,
                          background: `linear-gradient(90deg, ${route.color}, ${route.color}CC)`,
                        }}
                      ></div>
                    </div>
                    <small className="text-end d-block mt-1 fw-semibold" style={{ color: route.color }}>
                      {route.revenue}
                    </small>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
