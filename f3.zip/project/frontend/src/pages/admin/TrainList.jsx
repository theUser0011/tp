import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AdminSidebar } from '../../components/AdminSidebar';
import { Header } from '../../components/Header';
import api from '../../api/api';
import { toast } from 'react-toastify';
import Cookies from 'js-cookie';

export const TrainList = () => {
  const navigate = useNavigate();
  const [trains, setTrains] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchTrains();
  }, []);

  const fetchTrains = async () => {
    try {
      setLoading(true);
      const response = await api.get('/trains/', {
        headers: {
          Authorization: `Bearer ${Cookies.get('accessToken')}`,
        },
      });
      setTrains(response.data || []);
    } catch (err) {
      console.error('Error fetching trains:', err);
      toast.error('Failed to load trains');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (trainId) => {
    if (!window.confirm('Are you sure you want to delete this train?')) return;

    try {
      await api.delete(`/trains/${trainId}/`, {
        headers: {
          Authorization: `Bearer ${Cookies.get('accessToken')}`,
        },
      });
      setTrains(trains.filter((t) => t.id !== trainId));
      toast.success('Train deleted successfully');
    } catch (err) {
      console.error('Error deleting train:', err);
      toast.error('Failed to delete train');
    }
  };

  // Safe filtering with optional chaining
  const filteredTrains = trains.filter((train) =>
    train.train_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    train.train_number?.includes(searchTerm) ||
    train.origin?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    train.destination?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="admin-dashboard d-flex bg-light min-vh-100">
      {/* Sidebar */}
      <AdminSidebar />

      {/* Main Content */}
      <div className="dashboard-content flex-grow-1 p-4" style={{ marginLeft: '280px' }}>
        {/* Header */}
        <Header title="Manage Trains" />

        {/* Search & Add */}
        <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap">
          <input
            type="text"
            className="form-control w-50 mb-2"
            placeholder="Search trains..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button
            className="btn btn-primary mb-2"
            onClick={() => navigate('/admin/train-register')}
          >
            + Add New Train
          </button>
        </div>

        {/* Train Table */}
        {loading ? (
          <div className="text-center my-5">
            <div className="spinner-border text-primary" role="status"></div>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead className="table-light">
                <tr>
                  <th>Train Number</th>
                  <th>Train Name</th>
                  <th>Route</th>
                  <th>Schedule</th>
                  <th>Duration</th>
                  <th className="text-center">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredTrains.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="text-center py-5">
                      No trains found
                    </td>
                  </tr>
                ) : (
                  filteredTrains.map((train) => (
                    <tr key={train.id}>
                      <td>{train.train_number || '-'}</td>
                      <td>{train.train_name || '-'}</td>
                      <td>
                        {train.origin?.name || '-'} → {train.destination?.name || '-'}
                      </td>
                      <td>
                        {train.departure_time || '-'} - {train.arrival_time || '-'}
                      </td>
                      <td>{train.duration || '-'}</td>
                      <td className="text-center">
                        <button
                          className="btn btn-sm btn-info me-2"
                          onClick={() =>
                            navigate(`/admin/train-update/${train.id}`, {
                              state: { train },
                            })
                          }
                        >
                          Edit
                        </button>
                        <button
                          className="btn btn-sm btn-danger"
                          onClick={() => handleDelete(train.id)}
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
