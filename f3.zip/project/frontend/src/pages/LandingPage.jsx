import { Box } from '@mui/material';
import { NavigationBar } from '../components/common/NavigationBar';
import { HeroSection } from '../components/common/HeroSection';
import { FeaturesSection } from '../components/common/FeaturesSection';
import { HowItWorksSection } from '../components/common/HowItWorksSection';
import { TestimonialsSection } from '../components/common/TestimonialsSection';
import { CTASection } from '../components/common/CTASection';
import { FooterSection } from '../components/common/FooterSection';

import '../styles/LandingPage.css'

export const LandingPage = () => {
  return (
    <Box sx={{ bgcolor: 'background.default' }}>
      <NavigationBar />
      <HeroSection />
      <FeaturesSection />
      <HowItWorksSection />
      <TestimonialsSection />
      <CTASection />
      <FooterSection />
    </Box>
  );
};
