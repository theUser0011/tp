import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Train, Edit, LogOut, LayoutDashboard, BarChart3 } from 'lucide-react';
import { toast } from 'react-toastify';

export const AdminSidebar = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const menuItems = [
    { path: '/admin/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/admin/train-register', label: 'Train Registration', icon: Train },
    { path: '/admin/train-list', label: 'Manage Trains', icon: Edit },
  ];

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    toast.success('Logged out successfully');
    navigate('/login');
  };

  return (
    <div className="admin-sidebar">
      {/* Sidebar Header */}
      <div className="sidebar-header border-bottom p-3 d-flex align-items-center">
        <div className="sidebar-logo d-flex align-items-center justify-content-center me-2">
          <BarChart3 size={22} color="white" />
        </div>
        <div>
          <h6 className=" text-dark mb-0">Railway Admin</h6>
          <small className="text-muted">Management Portal</small>
        </div>
      </div>

      {/* Menu Items */}
      <ul className="nav flex-column px-3 mt-3 flex-grow-1">
        {menuItems.map((item, index) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <li
              key={item.path}
              className={`nav-item fade-in-up delay-${index}`}
            >
              <Link
                to={item.path}
                className={`nav-link sidebar-link d-flex align-items-center justify-content-between ${isActive ? 'active' : ''}`}
              >
                <div className="d-flex align-items-center">
                  <Icon
                    size={18}
                    className={`me-2 ${isActive ? 'text-white' : 'text-primary'}`}
                  />
                  <span className="sidebar-text">{item.label}</span>
                </div>
                {isActive && <span className="active-dot"></span>}
              </Link>
            </li>
          );
        })}
      </ul>

      {/* Logout Section */}
      <div className="p-3 border-top">
        <button
          onClick={handleLogout}
          className="btn btn-outline-danger w-100 d-flex align-items-center justify-content-center gap-2 logout-btn"
        >
          <LogOut size={18} />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};
