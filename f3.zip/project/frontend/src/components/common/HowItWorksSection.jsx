import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { FaSearch, FaTicketAlt, FaMapMarkerAlt } from "react-icons/fa";

export const HowItWorksSection = () => {
  const steps = [
    {
      icon: <FaSearch size={36} color="#2563eb" />,
      title: "Search Trains",
      description: "Enter your journey details and explore available trains in real-time.",
      color: "#2563eb",
    },
    {
      icon: <FaTicketAlt size={36} color="#10b981" />,
      title: "Book Tickets",
      description: "Choose your preferred train, class, and seat with instant confirmation.",
      color: "#10b981",
    },
    {
      icon: <FaMapMarkerAlt size={36} color="#8b5cf6" />,
      title: "Travel Smart",
      description: "Track live train status and enjoy a smooth, stress-free journey.",
      color: "#8b5cf6",
    },
  ];

  return (
    <section className="howitworks-section py-5">
      <div className="container">
        {/* Heading */}
        <div className="text-center mb-5">
          <h2 className="fw-bold mb-3">How It Works</h2>
          <p className="text-muted mx-auto" style={{ maxWidth: "600px" }}>
            Book your tickets in three simple steps
          </p>
        </div>

        {/* Steps */}
        <div className="row g-5 justify-content-center">
          {steps.map((step, index) => (
            <div className="col-12 col-md-4 text-center" key={index}>
              <div className="step-card p-4">
                <div className="position-relative d-inline-block mb-3">
                  {/* Main Icon Circle */}
                  <div
                    className="d-flex align-items-center justify-content-center rounded-circle step-icon"
                    style={{
                      backgroundColor: `${step.color}15`,
                      width: "90px",
                      height: "90px",
                    }}
                  >
                    {step.icon}
                  </div>

                  {/* Step Number */}
                  <div
                    className="position-absolute rounded-circle step-number"
                    style={{
                      top: "-8px",
                      right: "-8px",
                      backgroundColor: step.color,
                      width: "32px",
                      height: "32px",
                      color: "white",
                      fontWeight: "700",
                      fontSize: "1rem",
                      lineHeight: "32px",
                    }}
                  >
                    {index + 1}
                  </div>
                </div>

                <h5 className="fw-semibold mb-2">{step.title}</h5>
                <p className="text-muted">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
