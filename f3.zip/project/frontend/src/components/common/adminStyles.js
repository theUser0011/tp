import { Train, MapPin, Ticket, DollarSign } from 'lucide-react';

export function getDashboardData() {
  const cardStyle = {
    borderRadius: '12px',
    padding: '16px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
  };

  const stats = [
    {
      title: 'Total Trains',
      value: '156',
      change: '+12 this month',
      icon: Train,
      color: '#2563eb',
      bgcolor: '#eff6ff',
      gradient: 'linear-gradient(135deg, #2563eb 0%, #4f46e5 100%)',
      style: cardStyle,
    },
    {
      title: 'Active Routes',
      value: '89',
      change: '+5 new routes',
      icon: MapPin,
      color: '#10b981',
      bgcolor: '#ecfdf5',
      gradient: 'linear-gradient(135deg, #10b981 0%, #14b8a6 100%)',
      style: cardStyle,
    },
    {
      title: 'Total Bookings',
      value: '12,458',
      change: '+18% this month',
      icon: Ticket,
      color: '#8b5cf6',
      bgcolor: '#f5f3ff',
      gradient: 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)',
      style: cardStyle,
    },
    {
      title: 'Revenue',
      value: '$89,247',
      change: '+24% this month',
      icon: DollarSign,
      color: '#f59e0b',
      bgcolor: '#fffbeb',
      gradient: 'linear-gradient(135deg, #f59e0b 0%, #f97316 100%)',
      style: cardStyle,
    },
  ];

  const recentBookings = [
    { id: 'BK001', train: 'Rajdhani Express', customer: 'John Doe', date: '2025-11-05', amount: '$45', style: { borderRadius: '8px', padding: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' } },
    { id: 'BK002', train: 'Shatabdi Express', customer: 'Jane Smith', date: '2025-11-06', amount: '$38', style: { borderRadius: '8px', padding: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' } },
    { id: 'BK003', train: 'Duronto Express', customer: 'Mike Johnson', date: '2025-11-07', amount: '$52', style: { borderRadius: '8px', padding: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' } },
    { id: 'BK004', train: 'Garib Rath', customer: 'Sarah Williams', date: '2025-11-08', amount: '$28', style: { borderRadius: '8px', padding: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' } },
    { id: 'BK005', train: 'Intercity Express', customer: 'David Brown', date: '2025-11-09', amount: '$35', style: { borderRadius: '8px', padding: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' } },
  ];

  const popularRoutes = [
    { route: 'New Delhi → Mumbai', bookings: 2145, revenue: '$42,890', percentage: 85, color: '#2563eb', style: { borderRadius: '8px', padding: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' } },
    { route: 'Mumbai → Bangalore', bookings: 1876, revenue: '$37,520', percentage: 75, color: '#8b5cf6', style: { borderRadius: '8px', padding: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' } },
    { route: 'Delhi → Kolkata', bookings: 1632, revenue: '$32,640', percentage: 65, color: '#06b6d4', style: { borderRadius: '8px', padding: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' } },
    { route: 'Chennai → Hyderabad', bookings: 1421, revenue: '$28,420', percentage: 57, color: '#10b981', style: { borderRadius: '8px', padding: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' } },
  ];

  return { stats, recentBookings, popularRoutes };
}
