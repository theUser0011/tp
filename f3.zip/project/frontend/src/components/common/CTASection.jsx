import { Box, Container, Typography, Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';

export const CTASection = () => {
  const navigate = useNavigate();
  return (
    <Box sx={{ py: 10, background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)', color: 'white' }}>
      <Container maxWidth="md" sx={{ textAlign: 'center' }}>
        <Typography variant="h3" sx={{ fontWeight: 700, mb: 2, color: 'white' }}>
          Start Your Journey Today
        </Typography>
        <Typography variant="h6" sx={{ mb: 4, color: 'rgba(255,255,255,0.9)' }}>
          Create your account and get exclusive deals on train bookings
        </Typography>
        <Button
          size="large"
          variant="contained"
          onClick={() => navigate('/register')}
          sx={{
            bgcolor: 'white',
            color: 'primary.main',
            px: 5,
            py: 2,
            fontSize: '1.1rem',
            '&:hover': { bgcolor: 'grey.100', transform: 'translateY(-2px)', boxShadow: 6 },
            transition: 'all 0.3s',
          }}
        >
          Create Account
        </Button>
      </Container>
    </Box>
  );
};
