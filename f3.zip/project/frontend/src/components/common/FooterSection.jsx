import { Box, Container, Typography, Grid } from '@mui/material';
import { Train } from 'lucide-react';

export const FooterSection = () => (
 <div></div>
);
