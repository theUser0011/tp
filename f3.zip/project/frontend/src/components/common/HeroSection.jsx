import { Box, Container, Typography, Button, Grid, Chip } from '@mui/material';
import { useNavigate } from 'react-router-dom';

export const HeroSection = () => {
  const navigate = useNavigate();
  return (
    <Box
      sx={{
        background: 'linear-gradient(135deg, #2563eb 0%, #1e40af 100%)',
        color: 'white',
        py: 12,
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      <Box
        sx={{
          position: 'absolute',
          inset: 0,
          opacity: 0.2,
          backgroundImage: 'url(/hero.png)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />
      <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
        <Grid container spacing={4} alignItems="center">
          <Grid item xs={12} md={7}>
            <Chip label="✨ Trusted by 10M+ Travelers" sx={{ mb: 3, bgcolor: 'rgba(255,255,255,0.2)', color: 'white' }} />
            <Typography variant="h2" sx={{ fontWeight: 800, mb: 3, color: 'white' }}>
              Book Your Train Tickets Easily & Quickly
            </Typography>
            <Typography variant="h6" sx={{ mb: 4, color: 'rgba(255,255,255,0.9)', lineHeight: 1.6 }}>
              Experience seamless railway booking with real-time availability, instant confirmation, and secure payments
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
              <Button
                size="large"
                variant="contained"
                onClick={() => navigate('/customer/search-trains')}
                sx={{
                  bgcolor: 'white',
                  color: 'primary.main',
                  px: 4,
                  py: 1.5,
                  fontSize: '1.1rem',
                  '&:hover': { bgcolor: 'grey.100', transform: 'translateY(-2px)', boxShadow: 4 },
                  transition: 'all 0.3s',
                }}
              >
                Book Now
              </Button>
              <Button
                size="large"
                variant="outlined"
                onClick={() => navigate('/login')}
                sx={{
                  borderColor: 'white',
                  color: 'white',
                  px: 4,
                  py: 1.5,
                  fontSize: '1.1rem',
                  '&:hover': { borderColor: 'white', bgcolor: 'rgba(255,255,255,0.1)', transform: 'translateY(-2px)' },
                  transition: 'all 0.3s',
                }}
              >
                Login
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};
