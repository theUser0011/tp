import Cookies from 'js-cookie';
import { toast } from 'react-toastify';

export const logout = (navigate, isAdmin = false) => {
  try {
    // ✅ Clear auth cookies
    Cookies.remove('accessToken');
    Cookies.remove('refreshToken');

    // ✅ Clear user info
    localStorage.removeItem('currentUser');

    // ✅ Clear any cached pages
    sessionStorage.clear();

    toast.success('Logged out successfully!');

    // ✅ Navigate to correct login page (and replace history)
    navigate(isAdmin ? '/admin/login' : '/login', { replace: true });
  } catch (err) {
    console.error('Logout error:', err);
    toast.error('Error during logout. Please try again.');
  }
};
