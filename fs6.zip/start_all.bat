@echo off
title TTBS-B4-V System Launcher
echo ============================================
echo   Launching TTBS-B4-V Backend and Frontend in Windows Terminal
echo ============================================

REM Get the directory of this batch file
set "ROOT_DIR=%~dp0"
cd /d "%ROOT_DIR%"

echo Current Directory: %ROOT_DIR%
echo.

REM Build full paths for backend and frontend
set "BACKEND_PATH=%ROOT_DIR%TTBS-B4-V-Backend"
set "FRONTEND_PATH=%ROOT_DIR%TTBS-B4-V-Frontend"

echo Backend Path: %BACKEND_PATH%
echo Frontend Path: %FRONTEND_PATH%
echo.

echo Starting both servers in Windows Terminal...

REM Launch both in separate Windows Terminal tabs using absolute paths
wt -w 0 new-tab --title "Backend" cmd /k "cd /d %BACKEND_PATH% && call cd core && python manage.py runserver 0.0.0.0:8000" ^
 ; new-tab --title "Frontend" cmd /k "cd /d %FRONTEND_PATH% && npm start"

echo.
echo ============================================
echo Both Backend and Frontend started successfully!
echo Tabs opened in Windows Terminal.
echo ============================================
