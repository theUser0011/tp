import { useState, useEffect } from 'react';
import { AdminSidebar } from '../../components/AdminSidebar';
import { Header } from '../../components/Header';
import api from '../../api/api';
import { toast } from 'react-toastify';
import { Plus, Trash2, Train } from 'lucide-react';
import '../../styles/AdminDashboard.css';

export const TrainRegistration = () => {
  // ------------------------------------------------------------
  // FORM DATA STATE
  // ------------------------------------------------------------
  const [formData, setFormData] = useState({
    trainNumber: '',
    trainName: '',
    origin: '',
    destination: '',
    departureTime: '',
    arrivalTime: '',
    duration: '',
    classes: {
      sleeper: { available: true, price: '' },
      ac3Tier: { available: true, price: '' },
      ac2Tier: { available: true, price: '' },
      ac1Tier: { available: true, price: '' },
    },
  });

  // ------------------------------------------------------------
  // STOPS + STATIONS
  // ------------------------------------------------------------
  const [stops, setStops] = useState([{ station: '', arrivalTime: '', departureTime: '' }]);
  const [stations, setStations] = useState([]);
  const [loading, setLoading] = useState(false);

  // ------------------------------------------------------------
  // FETCH STATIONS ON MOUNT
  // ------------------------------------------------------------
  useEffect(() => {
    const fetchStations = async () => {
      try {
        const res = await api.get('/stations/');
        setStations(res.data);
      } catch (err) {
        console.error('Error fetching stations:', err);
        toast.error('Failed to load stations');
      }
    };
    fetchStations();
  }, []);

  // ------------------------------------------------------------
  // STOP HANDLERS
  // ------------------------------------------------------------
  const handleAddStop = () =>
    setStops([...stops, { station: '', arrivalTime: '', departureTime: '' }]);

  const handleRemoveStop = (index) =>
    stops.length > 1 && setStops(stops.filter((_, i) => i !== index));

  const handleStopChange = (index, field, value) => {
    const newStops = [...stops];
    newStops[index][field] = value;
    setStops(newStops);
  };

  // ------------------------------------------------------------
  // VALIDATION FUNCTION (frontend pre-checks)
  // ------------------------------------------------------------
  const validateTrainData = () => {
    if (!formData.trainNumber || !formData.trainName || !formData.origin || !formData.destination) {
      toast.error('Please fill all required fields');
      return false;
    }

    // Prevent same origin and destination
    if (formData.origin === formData.destination) {
      toast.error('Origin and destination cannot be the same.');
      return false;
    }

    // Check stops for invalid station IDs or duplicates
    const usedStations = new Set([Number(formData.origin), Number(formData.destination)]);
    for (let stop of stops) {
      if (stop.station) {
        const stId = Number(stop.station);
        if (usedStations.has(stId)) {
          toast.error('Stops cannot include origin, destination, or duplicate stations.');
          return false;
        }
        usedStations.add(stId);
      }
    }

    // Validate time order (optional)
    if (formData.departureTime && formData.arrivalTime) {
      if (formData.departureTime === formData.arrivalTime) {
        toast.error('Departure and arrival time cannot be the same.');
        return false;
      }
    }

    return true;
  };

  // ------------------------------------------------------------
  // SUBMIT HANDLER
  // ------------------------------------------------------------
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Run validations
    if (!validateTrainData()) return;

    const payload = {
      train_number: formData.trainNumber,
      train_name: formData.trainName,
      origin: Number(formData.origin),
      destination: Number(formData.destination),
      departure_time: formData.departureTime ? formData.departureTime + ':00' : '',
      arrival_time: formData.arrivalTime ? formData.arrivalTime + ':00' : '',
      travel_duration: formData.duration,
      total_seats: {
        SL: formData.classes.sleeper.available ? Number(formData.classes.sleeper.price) || 0 : 0,
        '3A': formData.classes.ac3Tier.available ? Number(formData.classes.ac3Tier.price) || 0 : 0,
        '2A': formData.classes.ac2Tier.available ? Number(formData.classes.ac2Tier.price) || 0 : 0,
        '1A': formData.classes.ac1Tier.available ? Number(formData.classes.ac1Tier.price) || 0 : 0,
      },
      stops: stops
        .filter(stop => stop.station)
        .map((stop, index) => ({
          station: Number(stop.station),
          arrival_time: stop.arrivalTime ? stop.arrivalTime + ':00' : '',
          departure_time: stop.departureTime ? stop.departureTime + ':00' : '',
          stop_order: index + 1, // ✅ required field for backend
        })),
    };

    console.log(payload);

    try {
      setLoading(true);
      await api.post('/trains/', payload);
      toast.success('✅ Train registered successfully!');

      // Reset form
      setFormData({
        trainNumber: '',
        trainName: '',
        origin: '',
        destination: '',
        departureTime: '',
        arrivalTime: '',
        duration: '',
        classes: {
          sleeper: { available: true, price: '' },
          ac3Tier: { available: true, price: '' },
          ac2Tier: { available: true, price: '' },
          ac1Tier: { available: true, price: '' },
        },
      });
      setStops([{ station: '', arrivalTime: '', departureTime: '' }]);
    } catch (err) {
      console.error('Error creating train:', err);
      toast.error(err?.response?.data?.detail || '❌ Error registering train');
    } finally {
      setLoading(false);
    }
  };

  // ------------------------------------------------------------
  // RENDER JSX
  // ------------------------------------------------------------
  return (
    <div className="admin-dashboard d-flex bg-light min-vh-100">
      <AdminSidebar />

      <div className="dashboard-content flex-grow-1 p-4" style={{ marginLeft: '280px' }}>
        <Header title="Train Registration" />

        <div className="card shadow-sm border-0 train-card p-4">
          {/* Header */}
          <div className="d-flex align-items-center mb-4 gap-3">
            <div className="train-icon bg-primary text-white rounded-circle d-flex align-items-center justify-content-center">
              <Train size={28} />
            </div>
            <div>
              <h5 className="mb-0">Register New Train</h5>
              <small className="text-muted">Add a new train to the system</small>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit}>
            {/* Basic Info */}
            <h6 className="gradient-text mb-3">Basic Information</h6>
            <div className="row mb-4">
              <div className="col-md-6 mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Train Number"
                  value={formData.trainNumber}
                  onChange={(e) => setFormData({ ...formData, trainNumber: e.target.value })}
                  required
                />
              </div>
              <div className="col-md-6 mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Train Name"
                  value={formData.trainName}
                  onChange={(e) => setFormData({ ...formData, trainName: e.target.value })}
                  required
                />
              </div>
              <div className="col-md-6 mb-3">
                <select
                  className="form-control"
                  value={formData.origin}
                  onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
                  required
                >
                  <option value="">Select Origin</option>
                  {stations.map(st => (
                    <option
                      key={st.id}
                      value={st.id}
                      disabled={st.id === Number(formData.destination)}
                    >
                      {st.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-6 mb-3">
                <select
                  className="form-control"
                  value={formData.destination}
                  onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                  required
                >
                  <option value="">Select Destination</option>
                  {stations.map(st => (
                    <option
                      key={st.id}
                      value={st.id}
                      disabled={st.id === Number(formData.origin)}
                    >
                      {st.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Schedule */}
            <h6 className="gradient-text mb-3">Schedule Information</h6>
            <div className="row mb-4">
              <div className="col-md-4 mb-3">
                <input type="time" className="form-control" value={formData.departureTime}
                  onChange={(e) => setFormData({ ...formData, departureTime: e.target.value })} />
              </div>
              <div className="col-md-4 mb-3">
                <input type="time" className="form-control" value={formData.arrivalTime}
                  onChange={(e) => setFormData({ ...formData, arrivalTime: e.target.value })} />
              </div>
              <div className="col-md-4 mb-3">
                <input type="text" className="form-control" placeholder="Duration"
                  value={formData.duration} onChange={(e) => setFormData({ ...formData, duration: e.target.value })} />
              </div>
            </div>

            {/* Stops */}
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h6 className="gradient-text">Intermediate Stops</h6>
              <button type="button" className="btn btn-success btn-sm" onClick={handleAddStop}>
                <Plus size={16} /> Add Stop
              </button>
            </div>

            {stops.map((stop, idx) => (
              <div className="row mb-2 align-items-center stop-card" key={idx}>
                <div className="col-md-4 mb-2">
                  <select
                    className="form-control"
                    value={stop.station}
                    onChange={(e) => handleStopChange(idx, 'station', e.target.value)}
                  >
                    <option value="">Select Stop Station</option>
                    {stations.map(st => (
                      <option
                        key={st.id}
                        value={st.id}
                        disabled={
                          st.id === Number(formData.origin) ||
                          st.id === Number(formData.destination) ||
                          stops.some((s, i) => s.station === st.id && i !== idx)
                        }
                      >
                        {st.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="col-md-3 mb-2">
                  <input type="time" className="form-control" value={stop.arrivalTime}
                    onChange={(e) => handleStopChange(idx, 'arrivalTime', e.target.value)} />
                </div>
                <div className="col-md-3 mb-2">
                  <input type="time" className="form-control" value={stop.departureTime}
                    onChange={(e) => handleStopChange(idx, 'departureTime', e.target.value)} />
                </div>
                <div className="col-md-2">
                  <button type="button" className="btn btn-danger btn-sm"
                    onClick={() => handleRemoveStop(idx)} disabled={stops.length === 1}>
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}

            {/* Classes */}
            <h6 className="gradient-text mt-4 mb-3">Class & Pricing</h6>
            <div className="row mb-4">
              {Object.entries(formData.classes).map(([key, value]) => {
                const labels = { sleeper: 'Sleeper Class', ac3Tier: 'AC 3-Tier', ac2Tier: 'AC 2-Tier', ac1Tier: 'AC 1st Class' };
                return (
                  <div className="col-md-6 mb-3" key={key}>
                    <div className="card p-2 border-warning">
                      <div className="form-check mb-2">
                        <input className="form-check-input" type="checkbox" checked={value.available}
                          onChange={(e) => setFormData({
                            ...formData,
                            classes: { ...formData.classes, [key]: { ...value, available: e.target.checked } }
                          })} />
                        <label className="form-check-label">{labels[key]}</label>
                      </div>
                      <input type="number" className="form-control" placeholder="Price (₹)"
                        value={value.price} disabled={!value.available}
                        onChange={(e) => setFormData({
                          ...formData,
                          classes: { ...formData.classes, [key]: { ...value, price: e.target.value } }
                        })} />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Submit + Cancel */}
            <div className="d-flex gap-2">
              <button type="submit" className="btn btn-primary flex-grow-1" disabled={loading}>
                {loading ? 'Registering...' : 'Register Train'}
              </button>
              <button type="button" className="btn btn-outline-secondary flex-grow-1"
                onClick={() => window.history.back()}>Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
