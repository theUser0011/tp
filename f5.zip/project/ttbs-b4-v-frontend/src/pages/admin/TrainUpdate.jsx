import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { AdminSidebar } from '../../components/AdminSidebar';
import { Header } from '../../components/Header';
import { Train } from 'lucide-react';
import { toast } from 'react-toastify';
import api from '../../api/api';

export default function TrainUpdate() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    trainNumber: '',
    trainName: '',
    originId: '',
    destinationId: '',
    originName: '',
    destinationName: '',
    departureTime: '',
    arrivalTime: '',
    duration: '',
    stops: [],
  });

  useEffect(() => {
    const fetchTrain = async () => {
      try {
        const response = await api.get(`/trains/${id}/`);
        const data = response.data;

        setFormData({
          trainNumber: data.train_number || '',
          trainName: data.train_name || '',
          originId: data.origin || '',
          destinationId: data.destination || '',
          originName: data.origin_detail?.name || '',
          destinationName: data.destination_detail?.name || '',
          departureTime: data.departure_time || '',
          arrivalTime: data.arrival_time || '',
          duration: data.travel_duration || '',
          stops: data.stops_detail || [],
        });
      } catch (error) {
        console.error('Error fetching train:', error);
        toast.error('Train not found');
        navigate('/admin/train-list');
      }
    };
    fetchTrain();
  }, [id, navigate]);

  const handleStopChange = (index, value) => {
    const updatedStops = [...formData.stops];
    updatedStops[index].name = value;
    setFormData({ ...formData, stops: updatedStops });
  };

  const handleAddStop = () => {
    setFormData({
      ...formData,
      stops: [...formData.stops, { id: null, name: '' }],
    });
  };

  const handleRemoveStop = (index) => {
    const updatedStops = formData.stops.filter((_, i) => i !== index);
    setFormData({ ...formData, stops: updatedStops });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Convert stop objects into IDs or names as per your backend logic
      const stopNames = formData.stops.map((stop) => stop.name).filter((n) => n);

      const payload = {
        train_number: formData.trainNumber,
        train_name: formData.trainName,
        origin: formData.originId, // ✅ send only ID
        destination: formData.destinationId, // ✅ send only ID
        departure_time: formData.departureTime,
        arrival_time: formData.arrivalTime,
        travel_duration: formData.duration,
        stops: stopNames, // backend should handle names or IDs accordingly
      };

      await api.put(`/trains/${id}/`, payload);
      toast.success('✅ Train updated successfully!');
      navigate('/admin/train-list');
    } catch (error) {
      console.error('Error updating train:', error.response?.data || error);
      toast.error('❌ Failed to update train');
    }
  };

  return (
    <div className="d-flex bg-light min-vh-100">
      <AdminSidebar />
      <div className="flex-grow-1" style={{ marginLeft: '280px' }}>
        <Header title="Update Train" />

        <div className="p-4">
          <div className="card shadow-sm border-0 mx-auto" style={{ maxWidth: '900px' }}>
            <div className="card-body">
              <div className="d-flex align-items-center mb-4">
                <div className="bg-primary text-white p-3 rounded me-3">
                  <Train size={24} />
                </div>
                <div>
                  <h5 className="card-title mb-0">Update Train Information</h5>
                  <small className="text-muted">Modify train details and stops</small>
                </div>
              </div>

              <form onSubmit={handleSubmit}>
                <div className="row g-3">
                  <div className="col-md-6">
                    <label className="form-label">Train Number</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.trainNumber}
                      onChange={(e) =>
                        setFormData({ ...formData, trainNumber: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <label className="form-label">Train Name</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.trainName}
                      onChange={(e) =>
                        setFormData({ ...formData, trainName: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <label className="form-label">Origin Station</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.originName}
                      onChange={(e) =>
                        setFormData({ ...formData, originName: e.target.value })
                      }
                      placeholder="e.g., Delhi"
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <label className="form-label">Destination Station</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.destinationName}
                      onChange={(e) =>
                        setFormData({ ...formData, destinationName: e.target.value })
                      }
                      placeholder="e.g., Mumbai"
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <label className="form-label">Departure Time</label>
                    <input
                      type="time"
                      className="form-control"
                      value={formData.departureTime}
                      onChange={(e) =>
                        setFormData({ ...formData, departureTime: e.target.value })
                      }
                    />
                  </div>

                  <div className="col-md-6">
                    <label className="form-label">Arrival Time</label>
                    <input
                      type="time"
                      className="form-control"
                      value={formData.arrivalTime}
                      onChange={(e) =>
                        setFormData({ ...formData, arrivalTime: e.target.value })
                      }
                    />
                  </div>

                  <div className="col-12">
                    <label className="form-label">Duration</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.duration}
                      onChange={(e) =>
                        setFormData({ ...formData, duration: e.target.value })
                      }
                      placeholder="e.g., 11h 00m"
                    />
                  </div>

                  {/* 🚉 Stops Section */}
                  <div className="col-12 mt-4">
                    <label className="form-label fw-bold">Stops</label>
                    {formData.stops.map((stop, index) => (
                      <div key={index} className="d-flex align-items-center mb-2">
                        <input
                          type="text"
                          className="form-control me-2"
                          value={stop.name}
                          placeholder={`Stop ${index + 1}`}
                          onChange={(e) => handleStopChange(index, e.target.value)}
                        />
                        <button
                          type="button"
                          className="btn btn-outline-danger btn-sm"
                          onClick={() => handleRemoveStop(index)}
                        >
                          Remove
                        </button>
                      </div>
                    ))}
                    <button
                      type="button"
                      className="btn btn-outline-primary btn-sm mt-2"
                      onClick={handleAddStop}
                    >
                      + Add Stop
                    </button>
                  </div>
                </div>

                <div className="d-flex gap-2 mt-4">
                  <button type="submit" className="btn btn-primary flex-grow-1">
                    Save Changes
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => navigate('/admin/train-list')}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
