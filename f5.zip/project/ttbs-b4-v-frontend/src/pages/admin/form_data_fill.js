(() => {
  const data = {
    trainNumber: "12163",
    trainName: "Chennai Express",
    origin: "Mumbai Central",
    destination: "Chennai Central",
    departure: "06:00",
    arrival: "20:30",
    duration: "14h 30m",
    stopStation: "Pune Junction",
    stopArrival: "09:00",
    stopDeparture: "09:15",
    prices: {
      sleeper: 450,
      ac3: 900,
      ac2: 1300,
      ac1: 1800
    }
  };

  // --- BASIC INFO ---
  const inputs = document.querySelectorAll('form input.form-control');
  if (inputs.length >= 10) {
    // Basic info
    inputs[0].value = data.trainNumber;      // Train Number
    inputs[1].value = data.trainName;        // Train Name
    inputs[2].value = data.origin;           // Origin
    inputs[3].value = data.destination;      // Destination

    // Schedule
    inputs[4].value = data.departure;        // Departure
    inputs[5].value = data.arrival;          // Arrival
    inputs[6].value = data.duration;         // Duration

    // Stop info
    inputs[7].value = data.stopStation;      // Stop Station
    inputs[8].value = data.stopArrival;      // Stop Arrival
    inputs[9].value = data.stopDeparture;    // Stop Departure

    // Class & Pricing (assuming same order as Sleeper, 3A, 2A, 1A)
    const priceInputs = Array.from(document.querySelectorAll('input[type="number"]'));
    if (priceInputs.length >= 4) {
      priceInputs[0].value = data.prices.sleeper;
      priceInputs[1].value = data.prices.ac3;
      priceInputs[2].value = data.prices.ac2;
      priceInputs[3].value = data.prices.ac1;
    }

    console.log("✅ Form auto-filled successfully!");
  } else {
    console.warn("⚠️ Form structure not found or not loaded yet.");
  }
})();
