(() => {
const data = {
  train_number: "12026",
  train_name: "Pune–Hyderabad Shatabdi Express",
  origin: 3,            // Pune Junction
  destination: 5,       // Hyderabad
  departure_time: "06:00",
  arrival_time: "12:45",
  travel_duration: "06:45",
  total_seats: {
    SL: 480,
    "3A": 880,
    "2A": 1200,
    "1A": 1650
  },
  stops: [
    {
      station: 4,       // Bangalore City (intermediate stop)
      arrival_time: "09:10",
      departure_time: "09:20",
      stop_order: 1
    }
  ]
};


  // Helper to set value for React-controlled inputs
  function setInputValue(input, value) {
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      Object.getPrototypeOf(input),
      'value'
    ).set;
    nativeInputValueSetter.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
  }

  // Fill text inputs (train number, name, times)
  const textInputs = document.querySelectorAll('form input.form-control[type="text"], form input.form-control[type="time"]');
  if (textInputs.length >= 5) {
    setInputValue(textInputs[0], data.train_number);
    setInputValue(textInputs[1], data.train_name);
    setInputValue(textInputs[2], data.departure_time);
    setInputValue(textInputs[3], data.arrival_time);
    setInputValue(textInputs[4], data.travel_duration);
  }

  // Fill select dropdowns (origin & destination)
  const selects = document.querySelectorAll('form select.form-control');
  if (selects.length >= 2) {
    selects[0].value = data.origin;
    selects[0].dispatchEvent(new Event('change', { bubbles: true }));
    selects[1].value = data.destination;
    selects[1].dispatchEvent(new Event('change', { bubbles: true }));
  }

  // Intermediate Stop (first stop-card)
  const stopCard = document.querySelector('.stop-card');
  if (stopCard) {
    const stopSelect = stopCard.querySelector('select.form-control');
    if (stopSelect) {
      stopSelect.value = data.stops[0].station;
      stopSelect.dispatchEvent(new Event('change', { bubbles: true }));
    }

    const stopInputs = stopCard.querySelectorAll('input.form-control[type="time"]');
    if (stopInputs.length >= 2) {
      setInputValue(stopInputs[0], data.stops[0].arrival_time);
      setInputValue(stopInputs[1], data.stops[0].departure_time);
    }
  }

  // Class & Pricing (assume 4 number inputs)
  const priceInputs = document.querySelectorAll('input[type="number"]');
  if (priceInputs.length >= 4) {
    setInputValue(priceInputs[0], data.total_seats.SL);
    setInputValue(priceInputs[1], data.total_seats["3A"]);
    setInputValue(priceInputs[2], data.total_seats["2A"]);
    setInputValue(priceInputs[3], data.total_seats["1A"]);
  }

  console.log("✅ Form auto-filled successfully!");
})();
