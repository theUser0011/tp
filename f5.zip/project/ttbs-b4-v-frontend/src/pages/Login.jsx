import { useState } from 'react';
import { useNavigate, useLocation, Link as RouterLink } from 'react-router-dom';
import { LogIn, Train } from 'lucide-react';
import api from '../api/api';
import { jwtDecode } from 'jwt-decode';

import Cookies from 'js-cookie';
import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Link,
  Avatar,
  Divider,
  Chip,
} from '@mui/material';
import { toast } from 'react-toastify';

export const Login = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // ✅ Determine if admin or user login route
  const isAdminLogin = location.pathname.includes('admin');

  const [formData, setFormData] = useState({
    identifier: '',
    password: '',
  });

  const [loading, setLoading] = useState(false);

  // ------------------------------------------------------------------
  // LOGIN HANDLER (Unified for both Admin & Customer)
  // ------------------------------------------------------------------
  const handleSubmit = async (e) => {
    e.preventDefault();
    const identifier = formData.identifier.trim();
    const password = formData.password.trim();
    if (!identifier || !password) {
      toast.error('Please enter both username/email and password.');
      return;
    }
    // 1 Handle Dummy Customer Login (skip backend)
    const dummyUsers = ['user@gmail.com', 'user@example.com'];
    if (dummyUsers.includes(identifier.toLowerCase())) {
      const fakeUser = {
        username: 'user',
        email: identifier,
        role: 'customer',
      };
      localStorage.setItem('currentUser', JSON.stringify(fakeUser));
      toast.success('Customer login successful!');
      navigate('/customer/dashboard');
      return; // stop here - don’t call backend
    }
    // 2 Handle Real Admin Login via Backend
    try {
      setLoading(true);
      const response = await api.post('/token/', {
        username: identifier,
        password: password,
      });

      const { access, refresh } = response.data;

      // Decode access token to extract user info (including role)
      let decoded;
      try {
        decoded = jwtDecode(access);
        console.log(decoded);
      } catch (err) {
        console.error('Invalid JWT token:', err);
        toast.error('Login failed: Invalid token.');
        return;
      }

      const role = decoded.role;

      // ✅ Validate role before proceeding
      if (!role || !['admin', 'customer'].includes(role)) {
        toast.error('Invalid user role. Please contact support.');
        // ensure cleanup
        Cookies.remove('accessToken');
        Cookies.remove('refreshToken');
        localStorage.removeItem('currentUser');
        navigate('/login');
        return;
      }

      // ✅ Proceed if role is valid
      if (role === 'admin') {
        navigate('/admin/dashboard');
      } else {
        navigate('/customer/dashboard');
      }

      // ✅ Store tokens in cookies
      Cookies.set('accessToken', access, { expires: 1 });
      Cookies.set('refreshToken', refresh, { expires: 7 });

      // ✅ Store user info locally
      const userProfile = {
        username: decoded.username || decoded.email?.split('@')[0] || 'user',
        email: decoded.email || identifier,
        role: role,
      };
      localStorage.setItem('currentUser', JSON.stringify(userProfile));

      toast.success(`${role === 'admin' ? 'Admin' : 'Customer'} login successful!`);
      console.log(response, userProfile);

    } catch (error) {
      console.error('Login error:', error);
      if (error.response?.status === 400 || error.response?.status === 401) {
        toast.error('Invalid username/email or password.');
      } else if (error.code === 'ERR_NETWORK') {
        toast.error('Backend not reachable. Please start Django server.');
      } else {
        toast.error('Unexpected error occurred. Try again later.');
      }
    } finally {
      setLoading(false);
    }

  };


  // ------------------------------------------------------------------
  // 🧱 UI LAYOUT
  // ------------------------------------------------------------------
  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
        p: 2,
      }}
    >
      <Card
        elevation={8}
        sx={{
          maxWidth: 480,
          width: '100%',
          borderRadius: 3,
          backdropFilter: 'blur(8px)',
        }}
      >
        <CardContent sx={{ p: 5 }}>
          {/* Header */}
          <Box sx={{ textAlign: 'center', mb: 4 }}>
            <Avatar
              sx={{
                bgcolor: 'primary.lighter',
                width: 72,
                height: 72,
                mx: 'auto',
                mb: 2,
              }}
            >
              <Train size={40} color="#2563eb" />
            </Avatar>
            <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
              {isAdminLogin ? 'Admin Login' : 'User Login'}
            </Typography>
            <Typography color="text.secondary">
              {isAdminLogin
                ? 'Sign in to access the admin dashboard'
                : 'Sign in to access your railway account'}
            </Typography>
          </Box>

          {/* ------------------- LOGIN FORM ------------------- */}
          <Box component="form" onSubmit={handleSubmit} sx={{ mb: 3 }}>
            <TextField
              fullWidth
              label="Email"
              type="text"
              value={formData.identifier}
              onChange={(e) =>
                setFormData({ ...formData, identifier: e.target.value })
              }
              required
              sx={{ mb: 3 }}
              placeholder="admin or user@example.com"
            />

            <TextField
              fullWidth
              label="Password"
              type="password"
              value={formData.password}
              onChange={(e) =>
                setFormData({ ...formData, password: e.target.value })
              }
              required
              sx={{ mb: 4 }}
              placeholder="Enter your password"
            />

            <Button
              fullWidth
              size="large"
              type="submit"
              variant="contained"
              startIcon={<LogIn size={20} />}
              disabled={loading}
              sx={{
                py: 1.5,
                fontSize: '1rem',
                textTransform: 'none',
                boxShadow: 2,
                '&:hover': {
                  boxShadow: 4,
                  transform: 'translateY(-2px)',
                },
                transition: 'all 0.3s',
              }}
            >
              {loading
                ? 'Logging in...'
                : isAdminLogin
                  ? 'Login as Admin'
                  : 'Login as Customer'}
            </Button>
          </Box>

          {/* Registration Link (only for customers) */}
          {!isAdminLogin && (
            <Box sx={{ textAlign: 'center', mb: 3 }}>
              <Typography color="text.secondary" sx={{ mb: 1 }}>
                Don’t have an account?{' '}
                <Link
                  component={RouterLink}
                  to="/register"
                  sx={{ fontWeight: 600 }}
                >
                  Create Account
                </Link>
              </Typography>
            </Box>
          )}

          {/* Divider & Footer */}
          <Divider sx={{ my: 3 }}>
            <Chip label="Secure Login" size="small" />
          </Divider>

          <Box sx={{ textAlign: 'center' }}>
            <Link
              component={RouterLink}
              to="/"
              color="text.secondary"
              sx={{ textDecoration: 'none' }}
            >
              ← Back to Home
            </Link>
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
};
