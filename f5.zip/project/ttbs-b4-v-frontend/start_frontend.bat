
REM Start React Frontend
echo Starting React Frontend...
@REM cd "C:\path\to\your\react_project"

cd "TTBS-B4-V-Frontend"
start cmd /k "npm run dev -- --host"

cd..

