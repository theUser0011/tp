import logging
from rest_framework import serializers
from django.contrib.auth.models import User
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from .models import Train, Station, Stop, UserProfile

logger = logging.getLogger(__name__)

# ============================================================
# 🔐 AUTHENTICATION SERIALIZER – Custom JWT with role support
# ============================================================
class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token["username"] = user.username
        token["email"] = user.email
        try:
            token["role"] = user.profile.role
        except (AttributeError, UserProfile.DoesNotExist):
            token["role"] = "admin" if user.is_staff else "customer"
        return token

    def validate(self, attrs):
        email = attrs.get("username")
        password = attrs.get("password")

        if not email or "@" not in email:
            raise serializers.ValidationError({"detail": "Please enter a valid email address."})

        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            logger.warning(f"Invalid login attempt: email={email}")
            raise serializers.ValidationError({"detail": "Invalid email or password."})

        if not user.check_password(password):
            logger.warning(f"Incorrect password attempt for email={email}")
            raise serializers.ValidationError({"detail": "Invalid email or password."})

        data = super().validate({"username": user.username, "password": password})
        try:
            role = user.profile.role
        except (AttributeError, UserProfile.DoesNotExist):
            role = "admin" if user.is_staff else "customer"

        data.update({"username": user.username, "email": user.email, "role": role})
        logger.info(f"✅ Token issued for {user.username} ({role})")
        return data


# ============================================================
# 🏙️ STATION SERIALIZER
# ============================================================
class StationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Station
        fields = ["id", "name"]


# ============================================================
# 🛑 STOP SERIALIZER (Intermediate Stops)
# ============================================================
class StopSerializer(serializers.ModelSerializer):
    station_detail = StationSerializer(source="station", read_only=True)

    class Meta:
        model = Stop
        fields = [
            "id",
            "station",
            "station_detail",
            "arrival_time",
            "departure_time",
            "stop_order",
        ]


# ============================================================
# 🚆 TRAIN SERIALIZER
# ============================================================
class TrainSerializer(serializers.ModelSerializer):
    origin = serializers.PrimaryKeyRelatedField(queryset=Station.objects.all())
    destination = serializers.PrimaryKeyRelatedField(queryset=Station.objects.all())
    origin_detail = StationSerializer(source="origin", read_only=True)
    destination_detail = StationSerializer(source="destination", read_only=True)

    # Input stops + output intermediate stops
    stops = StopSerializer(many=True, write_only=True)
    intermediate_stops = StopSerializer(source="stop_set", many=True, read_only=True)

    class Meta:
        model = Train
        fields = [
            "id", "train_number", "train_name",
            "origin", "origin_detail", "destination", "destination_detail",
            "departure_time", "arrival_time", "travel_duration",
            "total_seats", "stops", "intermediate_stops"
        ]

    # ----------------------------
    # VALIDATIONS
    # ----------------------------
    def validate_train_number(self, value):
        if self.instance is None and Train.objects.filter(train_number=value).exists():
            raise serializers.ValidationError("Train with this number already exists.")
        return value

    def validate(self, data):
        origin = data.get("origin")
        destination = data.get("destination")
        departure_time = data.get("departure_time")

        if origin and destination and origin == destination:
            raise serializers.ValidationError("Origin and destination cannot be the same.")

        queryset = Train.objects.filter(
            origin=origin,
            destination=destination,
            departure_time=departure_time
        )
        if self.instance:
            queryset = queryset.exclude(pk=self.instance.pk)
        if queryset.exists():
            raise serializers.ValidationError(
                "A train with this route and departure time already exists."
            )

        return data

    # ----------------------------
    # CREATE & UPDATE METHODS
    # ----------------------------
    def create(self, validated_data):
        stops_data = validated_data.pop("stops", [])
        train = Train.objects.create(**validated_data)
        logger.info(f"🚆 Train created: {train.train_name} ({train.train_number})")

        for stop_data in stops_data:
            Stop.objects.create(train=train, **stop_data)
        return train

    def update(self, instance, validated_data):
        if "origin" in validated_data:
            instance.origin = validated_data.pop("origin")
        if "destination" in validated_data:
            instance.destination = validated_data.pop("destination")

        stops_data = validated_data.pop("stops", None)
        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        instance.save()

        # Optional: Update stops if provided
        if stops_data is not None:
            instance.stop_set.all().delete()
            for stop_data in stops_data:
                Stop.objects.create(train=instance, **stop_data)

        logger.info(f"✏️ Train updated: {instance.train_name} ({instance.train_number})")
        return instance
