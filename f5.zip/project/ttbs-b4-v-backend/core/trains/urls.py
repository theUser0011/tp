from django.urls import path
from .views import (
    TrainListCreateView,
    TrainDetailView,
    StationListCreateView,
    StationDetailView,
    StationBulkCreateView
)

urlpatterns = [
    # Train routes
    path('trains/', TrainListCreateView.as_view(), name='train-list-create'),
    path('trains/<int:pk>/', TrainDetailView.as_view(), name='train-detail'),

    # Station routes
    path('stations/', StationListCreateView.as_view(), name='station-list-create'),
    path('stations/<int:pk>/', StationDetailView.as_view(), name='station-detail'),
    path('stations/bulk-create/', StationBulkCreateView.as_view(), name='station-bulk-create'),
]
