# trains/admin.py
from django.contrib import admin
from .models import Train, Station, Stop

@admin.register(Station)
class StationAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']

class StopInline(admin.TabularInline):
    model = Stop
    extra = 1

@admin.register(Train)
class TrainAdmin(admin.ModelAdmin):
    list_display = ['train_number', 'train_name', 'origin', 'destination', 'departure_time']
    search_fields = ['train_number', 'train_name']
    inlines = [StopInline]