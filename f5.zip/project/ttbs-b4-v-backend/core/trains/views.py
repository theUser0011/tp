import os
import logging
import traceback
from rest_framework import generics, status, serializers
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, BasePermission
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework.views import APIView
from django.contrib.auth.models import User
from .models import Train, Station, Stop
from .serializers import TrainSerializer, StationSerializer, CustomTokenObtainPairSerializer

# ------------------------------------------------------------------
# LOGGING CONFIGURATION
# ------------------------------------------------------------------
LOG_DIR = os.path.join(os.path.dirname(__file__), "logs")
os.makedirs(LOG_DIR, exist_ok=True)

LOG_FILE = os.path.join(LOG_DIR, "app.log")

logging.basicConfig(
    level=logging.DEBUG,
    format="[%(asctime)s] [%(levelname)s] [%(filename)s:%(lineno)d] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8"),
        logging.StreamHandler(),  # also log to console
    ],
)
logger = logging.getLogger(__name__)

# ------------------------------------------------------------------
# PERMISSIONS – Admin Only for sensitive actions
# ------------------------------------------------------------------
class IsAdminUser(BasePermission):
    def has_permission(self, request, view):
        allowed = request.user.is_authenticated and request.user.is_staff
        if not allowed:
            logger.warning(f"Unauthorized access attempt by {request.user} → {view.__class__.__name__}")
        return allowed


# ------------------------------------------------------------------
# TRAIN CRUD (List, Create, Retrieve, Update, Delete)
# ------------------------------------------------------------------
class TrainListCreateView(generics.ListCreateAPIView):
    queryset = Train.objects.all().order_by("id")
    serializer_class = TrainSerializer
    permission_classes = [IsAuthenticated, IsAdminUser]

    def perform_create(self, serializer):
        try:
            serializer.save()
            logger.info("✅ Train created successfully.")
        except Exception as e:
            tb = traceback.format_exc()
            logger.error(f"❌ Error while creating Train: {e}\n{tb}")
            raise serializers.ValidationError({"detail": str(e)})

    def list(self, request, *args, **kwargs):
        try:
            logger.debug(f"Train list requested by {request.user}")
            return super().list(request, *args, **kwargs)
        except Exception as e:
            tb = traceback.format_exc()
            logger.error(f"❌ Error listing trains: {e}\n{tb}")
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class TrainDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Train.objects.all()
    serializer_class = TrainSerializer
    permission_classes = [IsAuthenticated, IsAdminUser]

    def destroy(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            train_num = instance.train_number
            self.perform_destroy(instance)
            logger.info(f"✅ Train {train_num} deleted successfully.")
            return Response({"message": f"Train {train_num} deleted successfully."}, status=status.HTTP_200_OK)
        except Exception as e:
            tb = traceback.format_exc()
            logger.error(f"❌ Error deleting train: {e}\n{tb}")
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# ------------------------------------------------------------------
# STATION CRUD + BULK CREATE
# ------------------------------------------------------------------
class StationListCreateView(generics.ListCreateAPIView):
    queryset = Station.objects.all().order_by("id")
    serializer_class = StationSerializer
    permission_classes = [IsAuthenticated, IsAdminUser]


class StationDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Station.objects.all()
    serializer_class = StationSerializer
    permission_classes = [IsAuthenticated, IsAdminUser]

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        name = instance.name
        self.perform_destroy(instance)
        logger.info(f"✅ Station '{name}' deleted successfully.")
        return Response({"message": f"Station '{name}' deleted successfully."}, status=status.HTTP_200_OK)


class StationBulkCreateView(APIView):
    """
    Bulk create stations.
    Example:
    POST /api/stations/bulk-create/
    {
        "stations": ["Mumbai Central", "Chennai Central", "Pune Junction"]
    }
    """
    permission_classes = [IsAuthenticated, IsAdminUser]

    def post(self, request):
        station_names = request.data.get("stations")
        if not isinstance(station_names, list):
            return Response({"detail": "Expected a list of station names."}, status=status.HTTP_400_BAD_REQUEST)

        created, skipped = [], []
        for name in station_names:
            name = name.strip()
            if not name:
                continue
            station, created_flag = Station.objects.get_or_create(name=name)
            if created_flag:
                created.append(station.name)
            else:
                skipped.append(station.name)

        logger.info(f"✅ Bulk station creation complete. Created: {len(created)}, Skipped: {len(skipped)}")
        return Response(
            {"created": created, "skipped_existing": skipped},
            status=status.HTTP_201_CREATED
        )


# ------------------------------------------------------------------
# CUSTOM JWT VIEW
# ------------------------------------------------------------------
class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer
