# trains/models.py
from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.db.models.signals import post_save
from django.dispatch import receiver
from datetime import datetime, timedelta


# ------------------------------------------------------------------
# USER PROFILE (with auto-role for superusers)
# ------------------------------------------------------------------
class UserProfile(models.Model):
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('customer', 'Customer'),
    ]
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='profile'
    )
    role = models.CharField(
        max_length=20,
        choices=ROLE_CHOICES,
        default='customer'
    )

    class Meta:
        verbose_name = 'User Profile'
        verbose_name_plural = 'User Profiles'

    def __str__(self):
        return f"{self.user.username} ({self.role})"


# Auto-create profile: superuser → admin, normal user → customer
@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        role = 'admin' if instance.is_superuser else 'customer'
        UserProfile.objects.create(user=instance, role=role)


# Keep role in sync if is_superuser flag changes
@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    if hasattr(instance, 'profile'):
        expected_role = 'admin' if instance.is_superuser else 'customer'
        if instance.profile.role != expected_role:
            instance.profile.role = expected_role
            instance.profile.save()
            # Avoid recursion: only save profile, not full user
            UserProfile.objects.filter(pk=instance.profile.pk).update(role=expected_role)

# ------------------------------------------------------------------
# RAILWAY SYSTEM MODELS
# ------------------------------------------------------------------
class Station(models.Model):
    name = models.CharField(max_length=100, unique=True)

    class Meta:
        verbose_name = 'Station'
        verbose_name_plural = 'Stations'
        ordering = ['name']

    def __str__(self):
        return self.name


class Train(models.Model):
    CLASS_CHOICES = [
        ('SL', 'Sleeper'),
        ('3A', 'AC 3 Tier'),
        ('2A', 'AC 2 Tier'),
        ('1A', 'AC First Class'),
    ]

    train_number = models.CharField(max_length=10, unique=True)
    train_name = models.CharField(max_length=100)
    origin = models.ForeignKey(
        'Station', on_delete=models.CASCADE, related_name='trains_origin'
    )
    destination = models.ForeignKey(
        'Station', on_delete=models.CASCADE, related_name='trains_destination'
    )
    intermediate_stops = models.ManyToManyField(
        'Station', through='Stop', related_name='stopping_trains'
    )
    departure_time = models.TimeField()  # at origin
    arrival_time = models.TimeField()    # at destination
    travel_duration = models.DurationField(null=True, blank=True)
    total_seats = models.JSONField(
        default=dict
    )  # e.g., {"SL": 100, "3A": 60, "2A": 40, "1A": 20}
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Train'
        verbose_name_plural = 'Trains'
        # unique_together = ('origin', 'destination', 'departure_time')
        ordering = ['train_number']

    def clean(self):
        if self.origin == self.destination:
            raise ValidationError("Origin and destination cannot be the same.")

        # Prevent schedule conflict (same route + time)
        conflicts = Train.objects.filter(
            origin=self.origin,
            destination=self.destination,
            departure_time=self.departure_time,
        ).exclude(pk=self.pk)
        if conflicts.exists():
            raise ValidationError(
                "Another train already runs on this schedule between these stations."
            )

    def save(self, *args, **kwargs):
        from django.db import transaction

        # TEMP FIX: auto-create origin/destination stations if missing
        if isinstance(self.origin, str):
            self.origin, _ = Station.objects.get_or_create(name=self.origin)
        if isinstance(self.destination, str):
            self.destination, _ = Station.objects.get_or_create(name=self.destination)

        # Calculate travel duration
        if self.departure_time and self.arrival_time:
            fmt = "%H:%M:%S"
            dep = datetime.strptime(str(self.departure_time), fmt)
            arr = datetime.strptime(str(self.arrival_time), fmt)
            if arr < dep:  # Next-day arrival
                arr += timedelta(days=1)
            self.travel_duration = arr - dep

        self.full_clean()
        super().save(*args, **kwargs)
    def __str__(self):
        return f"{self.train_number} - {self.train_name}"


class Stop(models.Model):
    train = models.ForeignKey(Train, on_delete=models.CASCADE)
    station = models.ForeignKey(Station, on_delete=models.CASCADE)
    arrival_time = models.TimeField()
    departure_time = models.TimeField()
    stop_order = models.PositiveIntegerField()

    class Meta:
        verbose_name = 'Train Stop'
        verbose_name_plural = 'Train Stops'
        unique_together = ('train', 'station')
        ordering = ['train', 'stop_order']

    def clean(self):
        if self.arrival_time and self.departure_time:
            if self.departure_time <= self.arrival_time:
                raise ValidationError("Departure time must be after arrival time.")

    def __str__(self):
        return f"{self.train} @ {self.station} ({self.arrival_time} - {self.departure_time})"