cd railway-booking-system

# 2. Create virtual environment
python -m venv venv
venv\Scripts\activate
cd core
pip install -r requirements.txt

# 3. Install dependencies
<!-- pip install django djangorestframework psycopg2-binary python-dotenv -->

<!-- django-admin startproject core
cd core
python manage.py startapp trains -->


psql -U postgres
root

CREATE DATABASE railway_db;
CREATE USER railway_user WITH PASSWORD 'securepass123';
ALTER SCHEMA public OWNER TO railway_user;


<!-- ---------------------------
GRANT ALL PRIVILEGES ON DATABASE railway_db TO railway_user;
GRANT ALL ON SCHEMA public TO railway_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO railway_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO railway_user;
ALTER ROLE railway_user SET search_path TO public;

-- Terminate all connections to railway_db (except your current session)
SELECT pg_terminate_backend(pg_stat_activity.pid)
FROM pg_stat_activity
WHERE pg_stat_activity.datname = 'railway_db' 
  AND pid <> pg_backend_pid();

-- Now drop the database
DROP DATABASE railway_db;

from django.contrib.auth.models import User
from trains.models import UserProfile

# List all users and their profiles
users = User.objects.all()
for user in users:
    try:
        profile = user.profile
        print(f"User: {user.username} | Email: {user.email} | Superuser: {user.is_superuser} | Role: {profile.role}")
    except UserProfile.DoesNotExist:
        print(f"User: {user.username} | NO PROFILE!")

# 1. Open psql (replace <db_name> with your DB name, e.g. rtbs_db)
psql -d railway_db -U railway_user
securepass123

# 2. Run the query

SELECT
    u.username,
    u.is_superuser,
    up.role
FROM auth_user u
LEFT JOIN trains_userprofile up ON up.user_id = u.id
ORDER BY u.username;  
      
----------------------------------- -->

<!-- One time Creation only -->
python manage.py makemigrations trains
python manage.py migrate 
python manage.py createsuperuser
<!-- --------------------------- -->

py manage.py runserver  

To check table exist in DATABASE



\c railway_db
\dt
\q