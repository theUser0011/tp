1. Admin Login – Get JWT Token
http

```
POST http://127.0.0.1:8000/api/token/
Content-Type: application/json

{
  "username": "admin",
  "password": "admin123"
}
```

Response (200 OK)
json

```
{
  "refresh": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.xxxx",
  "access": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNzYyMjM1OTMyLCJpYXQiOjE3NjIyMzIzMzIsImp0aSI6IjFhNGFjNjI1MmVjZjRmNjA4OGM0YmExYTY1YjRkNzliIiwidXNlcl9pZCI6IjEifQ.j0UAvKokmgWDVaUeR-E_3JEgj6re2MuQBOf-Ky7ag-8"
}
```

Use access token in Authorization: Bearer <token>
2. Create Train
http

```
POST http://127.0.0.1:8000/api/trains/
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNzYyMjM1OTMyLCJpYXQiOjE3NjIyMzIzMzIsImp0aSI6IjFhNGFjNjI1MmVjZjRmNjA4OGM0YmExYTY1YjRkNzliIiwidXNlcl9pZCI6IjEifQ.j0UAvKokmgWDVaUeR-E_3JEgj6re2MuQBOf-Ky7ag-8
Content-Type: application/json

{
  "train_number": "12001",
  "train_name": "Shatabdi Express",
  "origin": { "name": "New Delhi" },
  "destination": { "name": "Mumbai Central" },
  "departure_time": "06:00:00",
  "arrival_time": "22:00:00",
  "total_seats": {
    "SL": 200,
    "3A": 100,
    "2A": 50
  }
}
```

Response (201 Created)
json

```
{
  "id": 1,
  "train_number": "12001",
  "train_name": "Shatabdi Express",
  "origin_detail": { "id": 1, "name": "New Delhi" },
  "destination_detail": { "id": 2, "name": "Mumbai Central" },
  "departure_time": "06:00:00",
  "arrival_time": "22:00:00",
  "travel_duration": "16:00:00",
  "total_seats": { "SL": 200, "3A": 100, "2A": 50 },
  "intermediate_stops": []
}
```

3. List All Trains
http

```
GET http://127.0.0.1:8000/api/trains/
Authorization: Bearer <access_token>
```

Response (200 OK)
json

```
[
  {
    "id": 1,
    "train_number": "12001",
    "train_name": "Shatabdi Express",
    "origin_detail": { "id": 1, "name": "New Delhi" },
    "destination_detail": { "id": 2, "name": "Mumbai Central" },
    ...
  }
]
```

4. Get Train by Number
http

```
GET http://127.0.0.1:8000/api/trains/12001/
Authorization: Bearer <access_token>
```

Response (200 OK)
json

```
{
  "id": 1,
  "train_number": "12001",
  "train_name": "Shatabdi Express",
  "origin_detail": { "id": 1, "name": "New Delhi" },
  "destination_detail": { "id": 2, "name": "Mumbai Central" },
  "departure_time": "06:00:00",
  "arrival_time": "22:00:00",
  "travel_duration": "16:00:00",
  "total_seats": { "SL": 200, "3A": 100, "2A": 50 },
  "intermediate_stops": []
}
```

5. Update Train (PATCH)
http

```
PATCH http://127.0.0.1:8000/api/trains/12001/
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "train_name": "Shatabdi Express (Premium)",
  "total_seats": { "1A": 24 }
}
```

Response (200 OK)
json

```
{
  "id": 1,
  "train_number": "12001",
  "train_name": "Shatabdi Express (Premium)",
  "total_seats": { "SL": 200, "3A": 100, "2A": 50, "1A": 24 },
  ...
}
```

6. Delete Train
http

```
DELETE http://127.0.0.1:8000/api/trains/12001/
Authorization: Bearer <access_token>
```

Response (200 OK)
json

```
{
  "message": "Train 12001 deleted successfully."
}
```

7. Refresh JWT Token
http

```
POST http://127.0.0.1:8000/api/token/refresh/
Content-Type: application/json

{
  "refresh": "<your_refresh_token>"
}
```

Response (200 OK)
json

```
{
  "access": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.xxxx"
}
```

API Summary Table
MethodURLAuthPurposePOST/api/token/NoneGet JWTPOST/api/trains/JWT + AdminCreate TrainGET/api/trains/JWT + AdminList TrainsGET/api/trains/<number>/JWT + AdminGet TrainPATCH/api/trains/<number>/JWT + AdminUpdate TrainDELETE/api/trains/<number>/JWT + AdminDelete TrainPOST/api/token/refresh/Refresh TokenRenew Access
Thunder Client Collection (JSON)
Save as railway-sprint1.json and import in Thunder Client
json

```
{
  "name": "Railway Booking System - Sprint 1",
  "version": "1.0",
  "requests": [
    {
      "id": "login",
      "name": "1. Admin Login (JWT)",
      "method": "POST",
      "url": "http://127.0.0.1:8000/api/token/",
      "headers": [{ "key": "Content-Type", "value": "application/json" }],
      "body": { "mode": "json", "json": "{\n  \"username\": \"admin\",\n  \"password\": \"admin123\"\n}" },
      "tests": [
        "tc.setVar('access_token', tc.response.json.access);",
        "tc.setVar('refresh_token', tc.response.json.refresh);"
      ]
    },
    {
      "id": "create-train",
      "name": "2. Create Train",
      "method": "POST",
      "url": "http://127.0.0.1:8000/api/trains/",
      "headers": [
        { "key": "Authorization", "value": "Bearer {{access_token}}" },
        { "key": "Content-Type", "value": "application/json" }
      ],
      "body": { "mode": "json", "json": "{\n  \"train_number\": \"12002\",\n  \"train_name\": \"Rajdhani Express\",\n  \"origin\": {\"name\": \"Delhi\"},\n  \"destination\": {\"name\": \"Mumbai\"},\n  \"departure_time\": \"16:00:00\",\n  \"arrival_time\": \"08:00:00\",\n  \"total_seats\": {\"1A\": 50}\n}" }
    },
    {
      "id": "list-trains",
      "name": "3. List Trains",
      "method": "GET",
      "url": "http://127.0.0.1:8000/api/trains/",
      "headers": [{ "key": "Authorization", "value": "Bearer {{access_token}}" }]
    },
    {
      "id": "get-train",
      "name": "4. Get Train",
      "method": "GET",
      "url": "http://127.0.0.1:8000/api/trains/12002/",
      "headers": [{ "key": "Authorization", "value": "Bearer {{access_token}}" }]
    },
    {
      "id": "update-train",
      "name": "5. Update Train",
      "method": "PATCH",
      "url": "http://127.0.0.1:8000/api/trains/12002/",
      "headers": [
        { "key": "Authorization", "value": "Bearer {{access_token}}" },
        { "key": "Content-Type", "value": "application/json" }
      ],
      "body": { "mode": "json", "json": "{\n  \"train_name\": \"Rajdhani Premium\"\n}" }
    },
    {
      "id": "delete-train",
      "name": "6. Delete Train",
      "method": "DELETE",
      "url": "http://127.0.0.1:8000/api/trains/12002/",
      "headers": [{ "key": "Authorization", "value": "Bearer {{access_token}}" }]
    },
    {
      "id": "refresh-token",
      "name": "7. Refresh Token",
      "method": "POST",
      "url": "http://127.0.0.1:8000/api/token/refresh/",
      "headers": [{ "key": "Content-Type", "value": "application/json" }],
      "body": { "mode": "json", "json": "{\n  \"refresh\": \"{{refresh_token}}\"\n}" },
      "tests": ["tc.setVar('access_token', tc.response.json.access);"]
    }
  ],
  "variables": [
    { "key": "access_token", "value": "", "enabled": true },
    { "key": "refresh_token", "value": "", "enabled": true }
  ]
}
```

SPRINT 1 = OFFICIALLY CLOSED
You now have:

* Full JWT Auth

* Admin-only Train CRUD

* Nested station handling

* Validation

* Admin panel

* Thunder Client ready

* Production-grade code

NEXT: SPRINT 2 – CUSTOMER MODULE
Reply:
"Start Sprint 2 – Customer Registration, Login (JWT), Profile, Soft Delete + React Login Page"
I’ll deliver:

* customers app

* JWT customer auth

* React + Vite login

* Full Thunder Client collection