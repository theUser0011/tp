@echo off

REM Start Django Backend
echo Starting Django Backend...
@REM @REM cd "C:\path\to\your\django_project"
cd "TTBS-B4-V-Backend"
cd "core"
@REM set no_proxy=172.*


start cmd /k "python manage.py runserver  IP:8000 "

cd..
cd..