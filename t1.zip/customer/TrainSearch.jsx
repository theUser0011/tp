import { useState, useEffect } from 'react';
import { CustomerSidebar } from '../../components/CustomerSidebar';
import { Header } from '../../components/Header';
import {
  Search,
  Train,
  ArrowRight,
  Calendar,
  MapPin,
  Clock,
  TrendingUp,
} from 'lucide-react';
import { toast } from 'react-toastify';
import api from '../../api/api';
import {
  Box,
  Grid,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Chip,
  InputAdornment,
  Autocomplete,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
} from '@mui/material';
import { Add, Remove } from '@mui/icons-material';
import { useDispatch } from 'react-redux';
import { setBookingData } from '../../redux/bookingSlice';
import { useNavigate } from 'react-router-dom'; // ← NEW

const TrainSearch = () => {
  const navigate = useNavigate(); // ← NEW
  const dispatch = useDispatch();

  const [stations, setStations] = useState([]);
  const [stationLoading, setStationLoading] = useState(false);
  const [searchParams, setSearchParams] = useState({
    origin: '',
    destination: '',
    travelDate: '',
  });
  const [searchResults, setSearchResults] = useState([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [loading, setLoading] = useState(false);
  const [selectedSeats, setSelectedSeats] = useState({});

  // Removed: selectedTrain, booking, handleBookingComplete

  // ──────────────────────────────────────────────────────────────
  // Load stations
  // ──────────────────────────────────────────────────────────────
  useEffect(() => {
    const fetchStations = async () => {
      try {
        setStationLoading(true);
        const response = await api.get('stations/');
        if (Array.isArray(response.data)) {
          setStations(response.data.map((s) => s.name));
        } else {
          console.warn('Unexpected station API format:', response.data);
        }
      } catch (error) {
        console.error('Error fetching stations:', error);
        toast.error('Failed to load station list.');
      } finally {
        setStationLoading(false);
      }
    };
    fetchStations();
  }, []);

  // ──────────────────────────────────────────────────────────────
  // Search trains
  // ──────────────────────────────────────────────────────────────
  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchParams.origin || !searchParams.destination || !searchParams.travelDate) {
      toast.error('Please fill all fields');
      return;
    }
    if (searchParams.origin === searchParams.destination) {
      toast.error('Origin and destination cannot be the same');
      return;
    }

    try {
      setLoading(true);
      setHasSearched(false);
      const response = await api.get('trains/search/', {
        params: {
          origin: searchParams.origin,
          destination: searchParams.destination,
          date: searchParams.travelDate,
        },
      });
      const trains = response.data || [];
      console.log('Search results:', trains);
      setSearchResults(trains);
      setHasSearched(true);

      // ── Initialise selectedSeats from available_classes (array) ──
      const initialSeats = {};
      trains.forEach((train) => {
        initialSeats[train.train_number] = {};
        if (Array.isArray(train.available_classes)) {
          train.available_classes.forEach((cls) => {
            initialSeats[train.train_number][cls] = 0;
          });
        }
      });
      setSelectedSeats(initialSeats);

      if (trains.length === 0) {
        toast.info('No trains found for the selected route');
      } else {
        toast.success(`Found ${trains.length} train(s)`);
      }
    } catch (error) {
      console.error('Error fetching trains:', error);
      toast.error('Failed to fetch trains. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  // ──────────────────────────────────────────────────────────────
  // Seat change (+ / -)
  // ──────────────────────────────────────────────────────────────
  const handleSeatChange = (trainNumber, cls, delta) => {
    setSelectedSeats((prev) => {
      const current = prev[trainNumber]?.[cls] ?? 0;
      const maxSeats =
        searchResults
          .find((t) => t.train_number === trainNumber)
          ?.available_seats?.[cls] ?? 0;
      const updated = Math.min(Math.max(current + delta, 0), maxSeats);
      return {
        ...prev,
        [trainNumber]: { ...prev[trainNumber], [cls]: updated },
      };
    });
  };

  // ──────────────────────────────────────────────────────────────
  // Book now → Navigate to /customer/booking + persist data
  // ──────────────────────────────────────────────────────────────
  const handleBookNow = (train) => {
    const seatsToBook = selectedSeats[train.train_number] || {};
    const totalSeats = Object.values(seatsToBook).reduce((a, b) => a + b, 0);
    if (totalSeats === 0) {
      toast.error('Please select at least one seat');
      return;
    }

    const payload = {
      train,
      travelDate: searchParams.travelDate,
      seatsToBook,
    };

    // 1. Save to Redux (keeps any existing logic happy)
    dispatch(setBookingData(payload));

    // 2. Save to localStorage so BookingForm can read it independently
    localStorage.setItem('pendingBooking', JSON.stringify(payload));

    // 3. Navigate to dedicated booking page
    navigate('/customer/booking');
  };

  // ──────────────────────────────────────────────────────────────
  // Render
  // ──────────────────────────────────────────────────────────────
  return (
    <Box sx={{ display: 'flex', bgcolor: 'background.default', minHeight: '100vh' }}>
      <CustomerSidebar />
      <Box sx={{ flex: 1, ml: '280px' }}>
        <Header title="Search Trains" />
        <Box sx={{ p: 4 }}>
          {/* Removed conditional rendering of BookingForm / TicketDetails */}

          {/* Search Card (unchanged) */}
          <Card
            elevation={0}
            sx={{
              mb: 4,
              border: '1px solid',
              borderColor: 'rgba(37, 99, 235, 0.2)',
              background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
              boxShadow: '0 10px 25px -5px rgba(37, 99, 235, 0.1)',
              transition: 'all 0.3s',
              '&:hover': {
                boxShadow: '0 20px 40px -10px rgba(37, 99, 235, 0.2)',
                transform: 'translateY(-2px)',
              },
            }}
          >
            <CardContent sx={{ p: 4 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                <Box
                  sx={{
                    width: 48,
                    height: 48,
                    borderRadius: 2,
                    background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: '0 4px 12px rgba(37, 99, 235, 0.3)',
                  }}
                >
                  <Search size={24} color="white" />
                </Box>
                <Box>
                  <Typography variant="h6">Search Your Train</Typography>
                  <Typography variant="body2" color="text.secondary">
                    Enter journey details to find available trains
                  </Typography>
                </Box>
              </Box>

              <Box
                component="form"
                onSubmit={handleSearch}
                sx={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 3,
                  p: 3,
                  background: 'linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(248,250,252,0.9) 100%)',
                  borderRadius: 2,
                }}
              >
                <Box sx={{ display: 'flex', gap: 2, justifyContent: 'space-evenly', flexWrap: 'wrap' }}>
                  <Box sx={{ flex: '1 1 250px', maxWidth: 400 }}>
                    <Autocomplete
                      freeSolo
                      options={stations}
                      loading={stationLoading}
                      value={searchParams.origin}
                      onChange={(_, v) => setSearchParams({ ...searchParams, origin: v || '' })}
                      onInputChange={(_, v) => setSearchParams({ ...searchParams, origin: v })}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="From Station"
                          placeholder="Select origin station"
                          required
                          fullWidth
                          sx={{ '& .MuiInputBase-root': { padding: '10px 14px' } }}
                          InputProps={{
                            ...params.InputProps,
                            startAdornment: (
                              <InputAdornment position="start">
                                <MapPin size={20} color="#2563eb" />
                              </InputAdornment>
                            ),
                          }}
                        />
                      )}
                    />
                  </Box>

                  <Box sx={{ flex: '1 1 250px', maxWidth: 400 }}>
                    <Autocomplete
                      freeSolo
                      options={stations}
                      loading={stationLoading}
                      value={searchParams.destination}
                      onChange={(_, v) => setSearchParams({ ...searchParams, destination: v || '' })}
                      onInputChange={(_, v) => setSearchParams({ ...searchParams, destination: v })}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="To Station"
                          placeholder="Select destination station"
                          required
                          fullWidth
                          sx={{ '& .MuiInputBase-root': { padding: '10px 14px' } }}
                          InputProps={{
                            ...params.InputProps,
                            startAdornment: (
                              <InputAdornment position="start">
                                <MapPin size={20} color="#8b5cf6" />
                              </InputAdornment>
                            ),
                          }}
                        />
                      )}
                    />
                  </Box>
                </Box>

                <TextField
                  fullWidth
                  label="Travel Date"
                  type="date"
                  value={searchParams.travelDate}
                  onChange={(e) => setSearchParams({ ...searchParams, travelDate: e.target.value })}
                  required
                  sx={{ '& .MuiInputBase-root': { padding: '8px 12px' } }}
                  InputLabelProps={{ shrink: true }}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <Calendar size={20} color="#06b6d4" />
                      </InputAdornment>
                    ),
                  }}
                  inputProps={{ min: new Date().toISOString().split('T')[0] }}
                />

                <Box sx={{ textAlign: 'center' }}>
                  <Button
                    type="submit"
                    variant="contained"
                    fullWidth
                    size="large"
                    startIcon={<Search size={20} />}
                    disabled={loading}
                    sx={{
                      py: 1.5,
                      textTransform: 'none',
                      fontWeight: 600,
                      fontSize: '1rem',
                      borderRadius: 2,
                      background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                      '&:hover': {
                        background: 'linear-gradient(135deg, #1d4ed8 0%, #7c3aed 100%)',
                        boxShadow: '0 8px 20px rgba(37,99,235,0.25)',
                        transform: 'scale(1.02)',
                      },
                      transition: 'all 0.2s ease',
                    }}
                  >
                    {loading ? 'Searching...' : 'Search Trains'}
                  </Button>
                </Box>
              </Box>
            </CardContent>
          </Card>

          {/* Results */}
          {hasSearched && (
            <Box>
              {searchResults.length === 0 ? (
                <Card
                  elevation={0}
                  sx={{
                    border: '1px solid',
                    borderColor: 'divider',
                    textAlign: 'center',
                    py: 8,
                    background:
                      'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
                  }}
                >
                  <Train size={48} color="#d1d5db" />
                  <Typography variant="h6" sx={{ mt: 2, mb: 1 }}>
                    No Trains Found
                  </Typography>
                  <Typography color="text.secondary">
                    Try searching with different stations or dates
                  </Typography>
                </Card>
              ) : (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <TrendingUp size={20} color="#10b981" />
                    <Typography variant="h6" color="text.secondary">
                      Found {searchResults.length} train{searchResults.length > 1 ? 's' : ''} for your journey
                    </Typography>
                  </Box>

                  {searchResults.map((train) => (
                    <Card
                      key={train.train_number}
                      elevation={0}
                      sx={{
                        border: '1px solid',
                        borderColor: 'rgba(37, 99, 235, 0.2)',
                        background:
                          'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
                        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                        '&:hover': {
                          boxShadow: '0 20px 40px -10px rgba(37, 99, 235, 0.25)',
                          transform: 'translateY(-4px)',
                          borderColor: 'rgba(37, 99, 235, 0.4)',
                        },
                      }}
                    >
                      <CardContent sx={{ p: 3 }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
                          <Box>
                            <Typography
                              variant="h6"
                              sx={{
                                mb: 0.5,
                                background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                                backgroundClip: 'text',
                                WebkitBackgroundClip: 'text',
                                WebkitTextFillColor: 'transparent',
                              }}
                            >
                              {train.train_name}
                            </Typography>
                            <Typography color="text.secondary">
                              Train No: {train.train_number}
                            </Typography>
                          </Box>
                          <Chip
                            icon={<Clock size={16} />}
                            label={train.travel_duration || '—'}
                            sx={{
                              background: 'linear-gradient(135deg, #06b6d4 0%, #3b82f6 100%)',
                              color: 'white',
                            }}
                          />
                        </Box>

                        <Grid container spacing={2} alignItems="center" sx={{ mb: 3 }}>
                          <Grid xs={5}>
                            <Typography variant="caption" color="text.secondary">
                              Departure
                            </Typography>
                            <Typography variant="h6">{train.departure_time}</Typography>
                            <Typography color="text.secondary">{train.origin}</Typography>
                          </Grid>
                          <Grid xs={2} sx={{ textAlign: 'center' }}>
                            <ArrowRight color="#6b7280" />
                          </Grid>
                          <Grid xs={5} sx={{ textAlign: 'right' }}>
                            <Typography variant="caption" color="text.secondary">
                              Arrival
                            </Typography>
                            <Typography variant="h6">{train.arrival_time}</Typography>
                            <Typography color="text.secondary">{train.destination}</Typography>
                          </Grid>
                        </Grid>

                        {/* Seat selection table */}
                        {Array.isArray(train.available_classes) && train.available_classes.length > 0 && (
                          <TableContainer component={Paper} sx={{ mb: 2 }}>
                            <Table size="small">
                              <TableHead>
                                <TableRow>
                                  <TableCell>Class</TableCell>
                                  <TableCell align="center">Seats Available</TableCell>
                                  <TableCell align="center">Fare (₹)</TableCell>
                                  <TableCell align="center">Select Seats</TableCell>
                                </TableRow>
                              </TableHead>
                              <TableBody>
                                {train.available_classes.map((cls) => (
                                  <TableRow key={cls}>
                                    <TableCell>{cls}</TableCell>
                                    <TableCell align="center">
                                      {train.available_seats?.[cls] ?? 'N/A'}
                                    </TableCell>
                                    <TableCell align="center">
                                      {train.fare_per_class?.[cls] ?? 'N/A'}
                                    </TableCell>
                                    <TableCell align="center">
                                      <IconButton
                                        size="small"
                                        onClick={() => handleSeatChange(train.train_number, cls, -1)}
                                        disabled={(selectedSeats[train.train_number]?.[cls] ?? 0) === 0}
                                      >
                                        <Remove />
                                      </IconButton>
                                      {selectedSeats[train.train_number]?.[cls] ?? 0}
                                      <IconButton
                                        size="small"
                                        onClick={() => handleSeatChange(train.train_number, cls, 1)}
                                        disabled={
                                          (selectedSeats[train.train_number]?.[cls] ?? 0) >=
                                          (train.available_seats?.[cls] ?? 0)
                                        }
                                      >
                                        <Add />
                                      </IconButton>
                                    </TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </TableContainer>
                        )}

                        <Button
                          variant="contained"
                          onClick={() => handleBookNow(train)}
                          sx={{
                            textTransform: 'none',
                            px: 3,
                            background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                            '&:hover': {
                              background: 'linear-gradient(135deg, #1d4ed8 0%, #7c3aed 100%)',
                              transform: 'scale(1.05)',
                            },
                            transition: 'all 0.2s',
                          }}
                        >
                          Book Now
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </Box>
              )}
            </Box>
          )}
        </Box>
      </Box>
    </Box>
  );
};

export default TrainSearch;