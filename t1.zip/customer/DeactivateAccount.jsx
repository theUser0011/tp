import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { CustomerSidebar } from "../../components/CustomerSidebar";
import { Header } from "../../components/Header";
import { AlertTriangle } from "lucide-react";
import { toast } from "react-toastify";
import api from "../../api/api";

// ✅ MUI Imports
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  List,
  ListItem,
} from "@mui/material";

export default function DeactivateAccount() {
  const navigate = useNavigate();
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [confirmText, setConfirmText] = useState("");
  const [loading, setLoading] = useState(false);

  const handleDeactivate = async () => {
    if (confirmText !== "DEACTIVATE") {
      toast.error("Please type DEACTIVATE to confirm");
      return;
    }

    try {
      setLoading(true);
      await api.post("customers/deactivate/");

      localStorage.removeItem("currentUser");
      localStorage.removeItem("access");
      localStorage.removeItem("refresh");

      toast.success("Account deactivated successfully");
      navigate("/");
    } catch (error) {
      console.error("Deactivation error:", error);
      toast.error("Failed to deactivate account");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ display: "flex", minHeight: "100vh", bgcolor: "background.default" }}>
      <CustomerSidebar />

      <Box sx={{ flex: 1, ml: "280px" }}>
        <Header title="Deactivate Account" />

        <Box sx={{ display: "flex", justifyContent: "center", py: 5 }}>
          <Card
            sx={{
              width: "100%",
              maxWidth: 650,
              border: "1px solid",
              borderColor: "error.main",
              borderRadius: 4,
              boxShadow: 3,
            }}
          >
            <CardContent sx={{ p: 4 }}>
              {/* Header */}
              <Box sx={{ display: "flex", alignItems: "center", mb: 4 }}>
                <Box
                  sx={{
                    p: 2,
                    bgcolor: "error.light",
                    opacity: 0.7,
                    color:"while",
                    borderRadius: 3,
                    mr: 2,
                  }}
                >
                  <AlertTriangle color="#d32f2f" size={28} />
                </Box>
                <Box>
                  <Typography variant="h5" color="error.main" fontWeight="600">
                    Deactivate Account
                  </Typography>
                  <Typography variant="body2" color="error.main">
                    This action is permanent and cannot be undone
                  </Typography>
                </Box>
              </Box>

              {/* Warning Box */}
              <Box
                sx={{
                  p: 3,
                  mb: 4,
                  borderRadius: 3,
                  border: "1px solid",
                  borderColor: "error.main",
                  bgcolor: "error.light",
                  opacity: 0.7,
                }}
              >
                <Typography variant="subtitle1" color="error.white" fontWeight="600" mb={1}>
                  What happens when you deactivate:
                </Typography>
                <List dense sx={{ color: "error.white", pl: 2 }}>
                  <ListItem sx={{ py: 0 }}>• Your account will be permanently deleted</ListItem>
                  <ListItem sx={{ py: 0 }}>• All your booking history will be removed</ListItem>
                  <ListItem sx={{ py: 0 }}>• You will lose access to all active bookings</ListItem>
                  <ListItem sx={{ py: 0 }}>• This action cannot be reversed</ListItem>
                </List>
              </Box>

              <Typography variant="body2" color="text.secondary" mb={4}>
                If you're sure you want to proceed, click the button below to deactivate your account.
              </Typography>

              {/* Action Buttons */}
              <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                <Button
                  variant="contained"
                  color="error"
                  onClick={() => setShowConfirmDialog(true)}
                  sx={{ fontWeight: 600, py: 1.3 }}
                >
                  Deactivate My Account
                </Button>

                <Button
                  variant="outlined"
                  color="secondary"
                  onClick={() => navigate("/customer/dashboard")}
                  sx={{ fontWeight: 600, py: 1.3 }}
                >
                  Cancel
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Box>
      </Box>

      {/* Confirmation Dialog */}
      <Dialog
        open={showConfirmDialog}
        onClose={() => setShowConfirmDialog(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          <Box display="flex" alignItems="center" gap={1}>
            <AlertTriangle color="#d32f2f" size={22} />
            <Typography color="error.main" fontWeight={600}>
              Final Confirmation
            </Typography>
          </Box>
        </DialogTitle>

        <DialogContent>
          <Typography variant="body2" color="text.secondary" mb={2}>
            This will permanently delete your account and all associated data.
          </Typography>

          <TextField
            fullWidth
            label='Type "DEACTIVATE" to confirm'
            value={confirmText}
            onChange={(e) => setConfirmText(e.target.value)}
            variant="outlined"
          />
        </DialogContent>

        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button
            onClick={handleDeactivate}
            variant="contained"
            color="error"
            fullWidth
            disabled={loading}
            sx={{ fontWeight: 600 }}
          >
            {loading ? "Processing..." : "Deactivate"}
          </Button>

          <Button
            onClick={() => {
              setShowConfirmDialog(false);
              setConfirmText("");
            }}
            variant="outlined"
            color="secondary"
            fullWidth
            sx={{ fontWeight: 600 }}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
