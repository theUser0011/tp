import { Box, Typography, Button, Card, CardContent, Avatar } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { CheckCircle } from "lucide-react";
import Cookies from "js-cookie";

export const NewCustomerDashboard = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Clear all stored tokens and session info
    Cookies.remove("accessToken");
    Cookies.remove("refreshToken");
    localStorage.clear();

    navigate("/login");
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)",
        p: 2,
      }}
    >
      <Card
        elevation={10}
        sx={{
          maxWidth: 480,
          width: "100%",
          borderRadius: 4,
          textAlign: "center",
          backdropFilter: "blur(8px)",
        }}
      >
        <CardContent sx={{ p: 5 }}>
          <Avatar
            sx={{
              bgcolor: "success.light",
              width: 80,
              height: 80,
              mx: "auto",
              mb: 3,
            }}
          >
            <CheckCircle size={45} color="#16a34a" />
          </Avatar>

          <Typography variant="h4" sx={{ fontWeight: 700, mb: 2 }}>
            Welcome, Customer! 🎉
          </Typography>

          <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
            You’ve successfully logged into your customer dashboard.
          </Typography>

          <Typography variant="body2" sx={{ mb: 4 }}>
            Explore train schedules, book tickets, and manage your bookings from here.
          </Typography>

          <Button
            variant="contained"
            color="error"
            onClick={handleLogout}
            sx={{
              px: 4,
              py: 1.5,
              fontSize: "1rem",
              textTransform: "none",
              borderRadius: 2,
              boxShadow: 3,
              "&:hover": { boxShadow: 6, transform: "translateY(-2px)" },
              transition: "all 0.3s ease",
            }}
          >
            Logout
          </Button>
        </CardContent>
      </Card>
    </Box>
  );
};
