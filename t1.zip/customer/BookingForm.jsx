import { useDispatch, useSelector } from 'react-redux';
import { clearBookingData, setBookingDetails } from '../../redux/bookingSlice';
import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Button,
  TextField,
  Grid,
  Typography,
  Card,
  CardContent,
  Divider,
  CircularProgress,
} from '@mui/material';
import { CustomerSidebar } from '../../components/CustomerSidebar';
import { Header } from '../../components/Header';
import { toast } from 'react-toastify';
import api from '../../api/api';

const BookingForm = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  // ──────────────────────────────────────────────────────────────
  // 1. Get data from Redux (fallback)
  // 2. Then override with localStorage (priority for navigation flow)
  // ──────────────────────────────────────────────────────────────
  const reduxState = useSelector((state) => state.booking);
  const stored = JSON.parse(localStorage.getItem('pendingBooking') || '{}');

  const activeTrain = stored.train || reduxState.train;
  const travelDate = stored.travelDate || reduxState.travelDate;
  const seatsToBook = stored.seatsToBook || reduxState.seatsToBook || {};

  // ──────────────────────────────────────────────────────────────
  // Persist any updates back to localStorage (for refresh safety)
  // ──────────────────────────────────────────────────────────────
  useEffect(() => {
    if (activeTrain) {
      localStorage.setItem(
        'pendingBooking',
        JSON.stringify({ train: activeTrain, travelDate, seatsToBook })
      );
    }
  }, [activeTrain, travelDate, seatsToBook]);

  // Optional: Restore from old key (backward compatibility)
  useEffect(() => {
    if (!activeTrain) {
      const saved = JSON.parse(localStorage.getItem('savedBookingState') || '{}');
      if (saved?.train) {
        dispatch(setBookingDetails(saved));
      }
    }
  }, [activeTrain, dispatch]);

  // ──────────────────────────────────────────────────────────────
  // Train memo (unchanged)
  // ──────────────────────────────────────────────────────────────
  const train = useMemo(() => {
    if (!activeTrain) return null;
    return {
      ...activeTrain,
      farePerClass: activeTrain.farePerClass || activeTrain.fare_per_class || {},
      availableClasses:
        activeTrain.availableClasses || activeTrain.available_classes || {},
    };
  }, [activeTrain]);

  // ──────────────────────────────────────────────────────────────
  // Total passengers & dynamic form (unchanged)
  // ──────────────────────────────────────────────────────────────
  const totalPassengers = useMemo(() => {
    if (!seatsToBook) return 1;
    return (
      Object.values(seatsToBook).reduce((sum, c) => sum + (c || 0), 0) || 1
    );
  }, [seatsToBook]);

  const [passengers, setPassengers] = useState([]);
  useEffect(() => {
    setPassengers(
      Array.from({ length: totalPassengers }, () => ({
        name: '',
        age: '',
        gender: '',
      }))
    );
  }, [totalPassengers]);

  const handlePassengerChange = (index, field, value) => {
    setPassengers((prev) => {
      const updated = [...prev];
      updated[index][field] = value;
      return updated;
    });
  };

  // ──────────────────────────────────────────────────────────────
  // Submit → backend API (one booking per class)
  // ──────────────────────────────────────────────────────────────
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const incomplete = passengers.some((p) => !p.name || !p.age || !p.gender);
    if (incomplete) {
      toast.error('Please fill all passenger details.');
      return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      toast.error('Please login again.');
      navigate('/login');
      return;
    }

    setSubmitting(true);

    try {
      const bookingsToCreate = [];
      let passengerIdx = 0;

      for (const [cls, count] of Object.entries(seatsToBook)) {
        if (count === 0) continue;

        const classPassengers = passengers.slice(passengerIdx, passengerIdx + count);

        const payload = {
          train: Number(train.id),           // ← Safe integer
          travel_class: cls,
          number_of_seats: Number(count),
          travel_date: travelDate,
          passengers: classPassengers,
        };

        bookingsToCreate.push(
          api.post('bookings/', payload, {
            headers: { Authorization: `Bearer ${token}` },
          })
        );

        passengerIdx += count;
      }

      const responses = await Promise.all(bookingsToCreate);
      const createdBookings = responses.map((res) => res.data);

      // Save fallback
      const existing = JSON.parse(localStorage.getItem('bookings') || '[]');
      localStorage.setItem('bookings', JSON.stringify([...existing, ...createdBookings]));

      toast.success('Booking confirmed!');
      dispatch(clearBookingData());
      localStorage.removeItem('pendingBooking');
      localStorage.removeItem('savedBookingState'); // clean old key

      // Navigate to ticket details
      const latest = createdBookings[createdBookings.length - 1];
      navigate('/customer/ticket-details', {
        state: {
          booking: {
            ...latest,
            trainName: train.train_name,
            trainNumber: train.train_number,
            origin: train.origin,
            destination: train.destination,
            departureTime: train.departure_time,
            arrivalTime: train.arrival_time,
            passengers: latest.passengers || [],
          },
        },
      });
    } catch (error) {
      console.error('Booking error:', error);
      const msg = error.response?.data?.train?.[0] || 'Invalid data. Please try again.';
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  // ──────────────────────────────────────────────────────────────
  // Render: No train selected
  // ──────────────────────────────────────────────────────────────
  if (!train) {
    return (
      <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: 'background.default' }}>
        <CustomerSidebar />
        <Box
          sx={{
            flex: 1,
            ml: '280px',
            p: 6,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <Card sx={{ maxWidth: 500, textAlign: 'center', p: 6 }}>
            <Typography variant="h6" gutterBottom>
              No train selected. Please search for trains first.
            </Typography>
            <Button
              variant="contained"
              sx={{ mt: 3 }}
              onClick={() => navigate('/customer/search-trains')}
            >
              Back to Train Search
            </Button>
          </Card>
        </Box>
      </Box>
    );
  }

  // ──────────────────────────────────────────────────────────────
  // Main UI (100% unchanged)
  // ──────────────────────────────────────────────────────────────
  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: 'background.default' }}>
      <CustomerSidebar />
      <Box sx={{ flex: 1, ml: '280px', pt: 6, pb: 8, px: { xs: 3, md: 6 } }}>
        <Header title="Book Ticket" />



        <Box sx={{ maxWidth: 900, mx: 'auto', display: 'flex', flexDirection: 'column', gap: 6 }}>
          {/* Train Details Card */}
                  {/* Back button */}
        <Button
          variant="outlined"
          sx={{ m: 4, px: 3 }}
          onClick={() => navigate('/customer/search-trains')}
        >
          Back to Search
        </Button>
          <Card sx={{ p: 3 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Train Details
              </Typography>
              <Divider sx={{ mb: 2 }} />
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Typography variant="caption" color="textSecondary">
                    Train Name
                  </Typography>
                  <Typography sx={{ mt: 0.5 }}>
                    {train.train_name || 'N/A'}
                  </Typography>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="caption" color="textSecondary">
                    Train Number
                  </Typography>
                  <Typography sx={{ mt: 0.5 }}>
                    {train.train_number || 'N/A'}
                  </Typography>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="caption" color="textSecondary">
                    Route
                  </Typography>
                  <Typography sx={{ mt: 0.5 }}>
                    {train.origin} to {train.destination}
                  </Typography>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="caption" color="textSecondary">
                    Travel Date
                  </Typography>
                  <Typography sx={{ mt: 0.5 }}>{travelDate || 'N/A'}</Typography>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="caption" color="textSecondary">
                    Departure
                  </Typography>
                  <Typography sx={{ mt: 0.5 }}>
                    {train.departure_time || 'N/A'}
                  </Typography>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="caption" color="textSecondary">
                    Arrival
                  </Typography>
                  <Typography sx={{ mt: 0.5 }}>
                    {train.arrival_time || 'N/A'}
                  </Typography>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Selected Classes Summary */}
          {seatsToBook && Object.keys(seatsToBook).length > 0 && (
            <Card sx={{ p: 3 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Selected Classes
                </Typography>
                <Divider sx={{ mb: 2 }} />
                {Object.entries(seatsToBook).map(([cls, count]) => (
                  <Box key={cls} sx={{ mb: 1 }}>
                    <Typography>
                      {cls} – {count} × ₹{train.farePerClass[cls] ?? 'N/A'} = ₹
                      {count * (train.farePerClass[cls] || 0)}
                    </Typography>
                    {train.available_seats?.[cls] !== undefined && (
                      <Typography variant="caption" color="text.secondary">
                        ({train.available_seats[cls]} seats left)
                      </Typography>
                    )}
                  </Box>
                ))}
                <Divider sx={{ my: 2 }} />
                <Typography align="right" sx={{ fontWeight: 600 }}>
                  Total Fare: ₹
                  {Object.entries(seatsToBook).reduce(
                    (sum, [cls, count]) =>
                      sum + count * (train.farePerClass[cls] || 0),
                    0
                  )}
                </Typography>
              </CardContent>
            </Card>
          )}

          {/* Passenger Details Form */}
          <Card sx={{ p: 3 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Passenger Details ({totalPassengers})
              </Typography>
              <Divider sx={{ mb: 3 }} />
              <form onSubmit={handleSubmit}>
                {passengers.map((p, idx) => (
                  <Box key={idx} sx={{ mb: 4 }}>
                    <Typography variant="subtitle1" sx={{ mb: 2 }}>
                      Passenger {idx + 1}
                    </Typography>
                    <Grid container spacing={3}>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          label="Passenger Name"
                          value={p.name}
                          onChange={(e) =>
                            handlePassengerChange(idx, 'name', e.target.value)
                          }
                          fullWidth
                          required
                        />
                      </Grid>
                      <Grid item xs={12} sm={3}>
                        <TextField
                          label="Age"
                          type="number"
                          value={p.age}
                          onChange={(e) =>
                            handlePassengerChange(idx, 'age', e.target.value)
                          }
                          fullWidth
                          required
                        />
                      </Grid>
                      <Grid item xs={12} sm={3}>
                        <TextField
                          label="Gender"
                          value={p.gender}
                          onChange={(e) =>
                            handlePassengerChange(idx, 'gender', e.target.value)
                          }
                          fullWidth
                          required
                        />
                      </Grid>
                    </Grid>
                  </Box>
                ))}

                <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 4 }}>
                  <Button
                    type="submit"
                    variant="contained"
                    disabled={submitting}
                    sx={{ px: 4, py: 1.5 }}
                  >
                    {submitting ? (
                      <>
                        <CircularProgress size={20} sx={{ mr: 1 }} />
                        Confirming...
                      </>
                    ) : (
                      'Confirm Booking'
                    )}
                  </Button>
                </Box>
              </form>
            </CardContent>
          </Card>
        </Box>
        
      </Box>
    </Box>
  );
};

export default BookingForm;