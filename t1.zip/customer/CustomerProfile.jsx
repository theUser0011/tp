import React, { useState, useEffect } from "react";
import { CustomerSidebar } from "../../components/CustomerSidebar";
import { Header } from "../../components/Header";
import { User, Mail, Phone, MapPin } from "lucide-react";
import { toast } from "react-toastify";
import api from "../../api/api";

import {
  InputAdornment,
  Box,
  Card,
  CardContent,
  TextField,
  Typography,
  Avatar,
  Button,
  CircularProgress,
} from "@mui/material";

export default function CustomerProfile() {
  const [formData, setFormData] = useState({
    username: "",
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    address: "",
  });

  const [loading, setLoading] = useState(false);

  // ✅ Fetch customer profile
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        setLoading(true);
        const response = await api.get("customers/profile/");
        const data = response.data;

        setFormData({
          username: data.username || "",
          first_name: data.first_name || "",
          last_name: data.last_name || "",
          email: data.email || "",
          phone: data.phone || "",
          address: data.address || "",
        });

        // ✅ Sync to localStorage
        const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}");
        localStorage.setItem("currentUser", JSON.stringify({ ...currentUser, ...data }));
      } catch (error) {
        console.error("❌ Error fetching profile:", error);
        toast.error("Failed to load profile details.");
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  // ✅ Handle submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}");

      const response = await api.put("customers/profile/", {
        username: formData.username || currentUser.username || "",
        first_name: formData.first_name,
        last_name: formData.last_name,
        email: formData.email,
        phone: formData.phone === "No phone number" ? "" : formData.phone,
        address: formData.address === "No address" ? "" : formData.address,
      });

      const updatedData = response.data;
      localStorage.setItem("currentUser", JSON.stringify({ ...currentUser, ...updatedData }));

      toast.success("✅ Profile updated successfully!");
    } catch (error) {
      console.error("❌ Error updating profile:", error);
      toast.error("Failed to update profile. Please check all fields.");
    } finally {
      setLoading(false);
    }
  };

  // ✅ Common style for thicker bordered TextFields
  const inputStyle = {
    "& .MuiOutlinedInput-root": {
      "& fieldset": {
        borderWidth: "2px",
        borderColor: "#cbd5e1",
      },
      "&:hover fieldset": {
        borderWidth: "2px",
        borderColor: "#6366f1",
      },
      "&.Mui-focused fieldset": {
        borderWidth: "2px",
        borderColor: "#2563eb",
      },
      borderRadius: "10px",
    },
  };

  return (
    <Box sx={{ display: "flex", bgcolor: "background.default", minHeight: "100vh" }}>
      <CustomerSidebar />
      <Box sx={{ flex: 1, ml: "280px" }}>
        <Header title="Customer Profile" />
        <Box sx={{ p: 4 }}>
          {/* Profile Card */}
          <Card
            elevation={0}
            sx={{
              maxWidth: 800,
              mx: "auto",
              p: 3,
              border: "1px solid",
              borderColor: "rgba(37,99,235,0.1)",
              borderRadius: 3,
              background:
                "linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(248,250,252,0.9) 100%)",
              boxShadow: "0 10px 25px -5px rgba(37,99,235,0.05)",
              transition: "all 0.3s ease",
              "&:hover": {
                boxShadow: "0 20px 40px -10px rgba(37,99,235,0.1)",
              },
            }}
          >
            <CardContent>
              {/* Header */}
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: 2,
                  mb: 4,
                }}
              >
                <Avatar
                  sx={{
                    background: "linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)",
                    width: 56,
                    height: 56,
                    boxShadow: "0 6px 15px rgba(37,99,235,0.3)",
                  }}
                >
                  <User color="white" size={28} />
                </Avatar>
                <Box>
                  <Typography variant="h5" fontWeight={600}>
                    Profile Information
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Update your personal details
                  </Typography>
                </Box>
              </Box>

              <Box
                component="form"
                onSubmit={handleSubmit}
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  gap: 3,
                }}
              >
                {/* Username */}
                <TextField
                  label="Username"
                  fullWidth
                  value={formData.username}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <User size={18} />
                      </InputAdornment>
                    ),
                    readOnly: true,
                  }}
                  sx={inputStyle}
                />

                {/* First Name + Last Name (side by side) */}
                <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
                  <TextField
                    label="First Name"
                    fullWidth
                    sx={{ flex: 1, ...inputStyle }}
                    value={formData.first_name}
                    onChange={(e) =>
                      setFormData({ ...formData, first_name: e.target.value })
                    }
                    required
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <User size={18} />
                        </InputAdornment>
                      ),
                    }}
                  />
                  <TextField
                    label="Last Name"
                    fullWidth
                    sx={{ flex: 1, ...inputStyle }}
                    value={formData.last_name}
                    onChange={(e) =>
                      setFormData({ ...formData, last_name: e.target.value })
                    }
                    required
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <User size={18} />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Box>

                {/* Email */}
                <TextField
                  label="Email Address"
                  type="email"
                  fullWidth
                  value={formData.email}
                  onChange={(e) =>
                    setFormData({ ...formData, email: e.target.value })
                  }
                  required
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <Mail size={18} />
                      </InputAdornment>
                    ),
                  }}
                  sx={inputStyle}
                />

                {/* Phone */}
                <TextField
                  label="Phone Number"
                  fullWidth
                  value={formData.phone}
                  onChange={(e) =>
                    setFormData({ ...formData, phone: e.target.value })
                  }
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <Phone size={18} />
                      </InputAdornment>
                    ),
                  }}
                  sx={inputStyle}
                />

                {/* Address */}
                <TextField
                  label="Address"
                  fullWidth
                  multiline
                  rows={3}
                  value={formData.address}
                  onChange={(e) =>
                    setFormData({ ...formData, address: e.target.value })
                  }
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <MapPin size={18} />
                      </InputAdornment>
                    ),
                  }}
                  sx={inputStyle}
                />

                {/* Save Button */}
                <Box sx={{ textAlign: "center", mt: 2 }}>
                  <Button
                    type="submit"
                    variant="contained"
                    disabled={loading}
                    sx={{
                      textTransform: "none",
                      px: 4,
                      py: 1.5,
                      fontWeight: 600,
                      fontSize: "1rem",
                      background: "linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)",
                      "&:hover": {
                        background: "linear-gradient(135deg, #1d4ed8 0%, #7c3aed 100%)",
                        transform: "scale(1.03)",
                        boxShadow: "0 8px 20px rgba(37,99,235,0.25)",
                      },
                      transition: "all 0.2s ease",
                      borderRadius: 2,
                    }}
                  >
                    {loading ? (
                      <CircularProgress size={24} sx={{ color: "white" }} />
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Box>
      </Box>
    </Box>
  );
}
