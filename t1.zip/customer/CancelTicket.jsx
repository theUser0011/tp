// CancelTicket.jsx
import React, { useState } from "react";
import { CustomerSidebar } from "../../components/CustomerSidebar";
import { Header } from "../../components/Header";
import { XCircle, AlertTriangle } from "lucide-react";
import { toast } from "react-toastify";
import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
} from "@mui/material";
import api from "../../api/api"; // ← Your axios instance with token handling

export const CancelTicket = () => {
  const [bookingId, setBookingId] = useState("");
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [bookingToCancel, setBookingToCancel] = useState(null);
  const [loading, setLoading] = useState(false);
  const [searching, setSearching] = useState(false);

  // Step 1: Search booking by ID
  const handleSearch = async (e) => {
    e.preventDefault();

    if (!bookingId.trim()) {
      toast.error("Please enter a booking ID");
      return;
    }

    setSearching(true);

    try {
      const response = await api.get(`bookings/history/`);
      const bookings = response.data;

      const booking = bookings.find((b) => b.id === parseInt(bookingId));

      if (!booking) {
        toast.error("Booking not found or does not belong to you");
        return;
      }

      if (booking.status === "Cancelled") {
        toast.error("This booking is already cancelled");
        return;
      }

      setBookingToCancel({
        id: booking.id,
        trainName: booking.train?.train_name || "N/A",
        trainNumber: booking.train?.train_number || "N/A",
        origin: booking.train?.origin?.name || booking.origin || "N/A",
        destination: booking.train?.destination?.name || booking.destination || "N/A",
        travelDate: booking.travel_date,
        travelClass: booking.travel_class,
        numberOfSeats: booking.number_of_seats,
        totalFare: booking.total_fare,
        status: booking.status,
      });

      setShowConfirmDialog(true);
    } catch (error) {
      console.error("Error fetching booking:", error);
      toast.error("Failed to fetch booking. Please try again.");
    } finally {
      setSearching(false);
    }
  };

  // Step 2: Confirm cancellation → call API
  const confirmCancellation = async () => {
    if (!bookingToCancel?.id) return;

    setLoading(true);

    try {
      await api.post(`bookings/cancel/${bookingToCancel.id}/`);

      toast.success(
        "Ticket cancelled successfully! Refund will be processed within 5-7 business days."
      );

      setShowConfirmDialog(false);
      setBookingToCancel(null);
      setBookingId("");
    } catch (error) {
      console.error("Cancellation failed:", error);
      const msg =
        error.response?.data?.error ||
        "Failed to cancel booking. Please try again.";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ display: "flex", bgcolor: "background.default", minHeight: "100vh" }}>
      <CustomerSidebar />
      <Box sx={{ flex: 1, ml: "280px" }}>
        <Header title="Cancel Ticket" />

        <Box sx={{ p: 4 }}>
          <Card
            elevation={0}
            sx={{
              maxWidth: 700,
              mx: "auto",
              p: 4,
              border: "1px solid rgba(37,99,235,0.1)",
              borderRadius: 3,
              background:
                "linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(248,250,252,0.9) 100%)",
              boxShadow: "0 10px 25px -5px rgba(37,99,235,0.05)",
            }}
          >
            <CardContent>
              {/* Header */}
              <Box sx={{ display: "flex", alignItems: "center", gap: 2, mb: 4 }}>
                <Box
                  sx={{
                    p: 1.5,
                    bgcolor: "rgba(239,68,68,0.1)",
                    borderRadius: "12px",
                  }}
                >
                  <XCircle size={24} color="#dc2626" />
                </Box>
                <Box>
                  <Typography variant="h6" fontWeight={600}>
                    Cancel Your Ticket
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Enter your booking ID to cancel your ticket
                  </Typography>
                </Box>
              </Box>

              {/* Form */}
              <Box
                component="form"
                onSubmit={handleSearch}
                sx={{ display: "flex", flexDirection: "column", gap: 3 }}
              >
                <TextField
                  label="Booking ID"
                  variant="outlined"
                  size="medium"
                  value={bookingId}
                  onChange={(e) => setBookingId(e.target.value.trim())}
                  placeholder="e.g., 123"
                  required
                  fullWidth
                  type="number"
                  inputProps={{ min: 1 }}
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      borderRadius: 2,
                    },
                  }}
                />

                <Button
                  type="submit"
                  variant="contained"
                  disabled={searching}
                  sx={{
                    textTransform: "none",
                    fontWeight: 600,
                    fontSize: "1rem",
                    py: 1.5,
                    borderRadius: 2,
                    background: "linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)",
                    "&:hover": {
                      background: "linear-gradient(135deg, #1d4ed8 0%, #7c3aed 100%)",
                      transform: "scale(1.03)",
                      boxShadow: "0 8px 20px rgba(37,99,235,0.25)",
                    },
                    transition: "all 0.2s ease",
                  }}
                >
                  {searching ? (
                    <CircularProgress size={22} color="inherit" />
                  ) : (
                    "Search Booking"
                  )}
                </Button>
              </Box>

              {/* Cancellation Policy */}
              <Box
                sx={{
                  mt: 4,
                  p: 3,
                  borderRadius: 2,
                  bgcolor: "rgba(253,230,138,0.2)",
                  border: "1px solid rgba(251,191,36,0.4)",
                }}
              >
                <Box sx={{ display: "flex", alignItems: "start", gap: 2 }}>
                  <AlertTriangle size={20} color="#ca8a04" style={{ marginTop: "3px" }} />
                  <Box>
                    <Typography variant="subtitle2" color="text.primary" sx={{ mb: 1 }}>
                      Cancellation Policy:
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      <ul style={{ marginLeft: "1.2rem", listStyle: "disc" }}>
                        <li>Full refund for cancellations made 48+ hours before departure</li>
                        <li>50% refund for 24–48 hours before departure</li>
                        <li>No refund if cancelled less than 24 hours before departure</li>
                        <li>Refunds processed within 5–7 business days</li>
                      </ul>
                    </Typography>
                  </Box>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Box>
      </Box>

      {/* Confirmation Dialog */}
      <Dialog
        open={showConfirmDialog}
        onClose={() => {
          setShowConfirmDialog(false);
          setBookingToCancel(null);
        }}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle sx={{ display: "flex", alignItems: "center", gap: 1.5, fontWeight: 600 }}>
          <Box
            sx={{
              p: 1,
              bgcolor: "rgba(239,68,68,0.1)",
              borderRadius: "50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <XCircle size={20} color="#dc2626" />
          </Box>
          Confirm Cancellation
        </DialogTitle>

        <DialogContent>
          <Box sx={{ p: 2, mb: 2, bgcolor: "rgba(243,244,246,0.6)", borderRadius: 2 }}>
            <Typography variant="caption" color="text.secondary">
              Booking Details:
            </Typography>
            <Typography variant="body1" fontWeight={500}>
              {bookingToCancel?.trainName} ({bookingToCancel?.trainNumber})
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {bookingToCancel?.origin} → {bookingToCancel?.destination}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Date: {bookingToCancel?.travelDate} | Class: {bookingToCancel?.travelClass} | Seats: {bookingToCancel?.numberOfSeats}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Total Fare: ₹{bookingToCancel?.totalFare}
            </Typography>
          </Box>

          <Typography variant="body2" color="text.secondary">
            Are you sure you want to cancel this booking? This action cannot be undone.
          </Typography>
        </DialogContent>

        <DialogActions sx={{ p: 3, gap: 2 }}>
          <Button
            variant="contained"
            onClick={confirmCancellation}
            disabled={loading}
            sx={{
              flex: 1,
              textTransform: "none",
              fontWeight: 600,
              borderRadius: 2,
              background: "linear-gradient(135deg, #dc2626 0%, #ef4444 100%)",
              "&:hover": {
                background: "linear-gradient(135deg, #b91c1c 0%, #dc2626 100%)",
              },
            }}
          >
            {loading ? <CircularProgress size={20} color="inherit" /> : "Yes, Cancel Ticket"}
          </Button>
          <Button
            variant="outlined"
            onClick={() => {
              setShowConfirmDialog(false);
              setBookingToCancel(null);
            }}
            sx={{
              flex: 1,
              textTransform: "none",
              fontWeight: 600,
              borderRadius: 2,
            }}
          >
            No, Keep Booking
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};