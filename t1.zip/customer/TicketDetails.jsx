import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { CustomerSidebar } from "../../components/CustomerSidebar";
import { Header } from "../../components/Header";
import { CheckCircle, Printer, Download, Train } from "lucide-react";
import { Box, Card, CardContent, Typography, Button, Grid } from "@mui/material";
import { consoleTestStage } from "../../utils/consoleTestStage";

const TicketDetails = () => {
  const navigate = useNavigate();
  const { state } = useLocation();

  // -----------------------------------------------------------------
  // 1. Get booking from navigation state (from BookingForm)
  // -----------------------------------------------------------------
  const booking = state?.booking;
  consoleTestStage("TicketDetails → booking from state:", booking);

  // -----------------------------------------------------------------
  // 2. Fallback: No booking passed
  // -----------------------------------------------------------------
  if (!booking) {
    return (
      <Box sx={{ display: "flex", minHeight: "100vh", bgcolor: "background.default" }}>
        <CustomerSidebar />
        <Box sx={{ flex: 1, ml: "280px" }}>
          <Header title="Ticket Details" />
          <Box sx={{ display: "flex", justifyContent: "center", py: 5 }}>
            <Card sx={{ p: 6, maxWidth: 600, textAlign: "center" }}>
              <Typography>No booking details found.</Typography>
              <Button
                variant="contained"
                color="primary"
                sx={{ mt: 3 }}
                onClick={() => navigate("/customer/booking-history")}
              >
                View Booking History
              </Button>
            </Card>
          </Box>
        </Box>
      </Box>
    );
  }

  // -----------------------------------------------------------------
  // 3. Render single booking (UI unchanged)
  // -----------------------------------------------------------------
  return (
    <Box sx={{ display: "flex", minHeight: "100vh", bgcolor: "background.default" }}>
      <CustomerSidebar />
      <Box sx={{ flex: 1, ml: "280px", py: 4 }}>
        <Header title="Ticket Details" />
        <Box sx={{ display: "flex", justifyContent: "center" }}>
          <Box sx={{ width: "100%", maxWidth: 800 }}>

            {/* Success Message */}
            <Card
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 2,
                bgcolor: "success.light",
                color: "white",
                p: 2,
                my: 4,
              }}
            >
              <Box sx={{ p: 1, bgcolor: "success.main", borderRadius: "50%" }}>
                <CheckCircle size={28} color="white" />
              </Box>
              <Box>
                <Typography fontWeight={600}>Booking Confirmed!</Typography>
                <Typography>Your ticket has been booked successfully.</Typography>
              </Box>
            </Card>

            {/* Ticket Card */}
            <Card sx={{ mb: 4, p: 2, border: 1, borderColor: "primary.light" }}>
              {/* Header */}
              <Box sx={{ bgcolor: "primary.main", color: "white", p: 3 }}>
                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                    <Train size={32} />
                    <Box>
                      <Typography fontWeight={600}>{booking.trainName}</Typography>
                      <Typography variant="body2">Train No: {booking.trainNumber}</Typography>
                    </Box>
                  </Box>
                  <Box textAlign="right">
                    <Typography variant="body2">Booking ID</Typography>
                    <Typography fontWeight={600}>{booking.bookingId || booking.id}</Typography>
                  </Box>
                </Box>
              </Box>

              {/* Journey Details */}
              <CardContent>
                <Typography fontWeight={600} mb={2}>
                  Journey Details
                </Typography>
                <Grid container spacing={12}>
                  <Grid item xs={6}>
                    <Typography variant="caption">From</Typography>
                    <Typography>{booking.origin}</Typography>
                    <Typography variant="body2">{booking.departureTime}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="caption">To</Typography>
                    <Typography>{booking.destination}</Typography>
                    <Typography variant="body2">{booking.arrivalTime}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="caption">Travel Date</Typography>
                    <Typography>{booking.travel_date}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="caption">Class</Typography>
                    <Typography>{booking.travel_class}</Typography>
                  </Grid>
                </Grid>
              </CardContent>

              {/* Passenger Details
              <CardContent>
                <Typography fontWeight={600} mb={2}>
                  Passenger Details
                </Typography>
                <Grid container spacing={2}>
                  {booking.passengers?.map((p, index) => (
                    <React.Fragment key={index}>
                      <Grid sx={{ width: "10%" }}>
                        <Typography variant="caption">Name</Typography>
                        <Typography>{p.name}</Typography>
                      </Grid>
                      <Grid sx={{ width: "10%" }}>
                        <Typography variant="caption">Age</Typography>
                        <Typography>{p.age}</Typography>
                      </Grid>
                      <Grid sx={{ width: "10%" }}>
                        <Typography variant="caption">Gender</Typography>
                        <Typography>{p.gender}</Typography>
                      </Grid>
                    </React.Fragment>
                  ))}
                </Grid>
              </CardContent> */}

              {/* Fare Details */}
              <CardContent sx={{ bgcolor: "grey.100" }}>
                <Typography fontWeight={600} mb={1}>
                  Fare Details
                </Typography>
                <Box sx={{ display: "flex", justifyContent: "space-between", mb: 1 }}>
                  <Typography>Total Fare</Typography>
                  <Typography>₹{Number(booking.total_fare)?.toFixed(2) ?? "0.00"}</Typography>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    borderTop: 1,
                    borderColor: "grey.300",
                    pt: 1,
                  }}
                >
                  <Typography fontWeight={600}>Amount Paid</Typography>
                  <Typography color="primary.main">
                    ₹{Number(booking.total_fare)?.toFixed(2) ?? "0.00"}
                  </Typography>
                </Box>
              </CardContent>

              {/* Action Buttons */}
              <Box sx={{ display: "flex", gap: 2, mb: 3, p: 2 }}>
                <Button
                  variant="outlined"
                  sx={{ flex: 1 }}
                  startIcon={<Printer />}
                  onClick={() => window.print()}
                >
                  Print Ticket
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  sx={{ flex: 1 }}
                  startIcon={<Download />}
                  onClick={() => window.print()}
                >
                  Download
                </Button>
              </Box>
            </Card>

            {/* Back to Dashboard */}
            <Box textAlign="center">
              <Button
                variant="text"
                color="primary"
                onClick={() => navigate("/customer/dashboard")}
              >
                ← Back to Dashboard
              </Button>
            </Box>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default TicketDetails;