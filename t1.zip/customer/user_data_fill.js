(() => {
const data = {
  username: "maria_smith",
  firstName: "Maria",
  lastName: "Smith",
  email: "maria.smith@example.com",
  phone: "+14165551234",
  address: "789 Pine Lane",
  password: "Maria@2025",
  confirmPassword: "Maria@2025"
};


  const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype,
    "value"
  ).set;

  const inputs = document.querySelectorAll("form input");

  inputs.forEach((input) => {
    const label = input.closest("div").querySelector("label")?.innerText?.toLowerCase();
    let newValue = "";

    if (label?.includes("username")) newValue = data.username;
    else if (label?.includes("first name")) newValue = data.firstName;
    else if (label?.includes("last name")) newValue = data.lastName;
    else if (label?.includes("email")) newValue = data.email;
    else if (label?.includes("phone")) newValue = data.phone;
    else if (label?.includes("address")) newValue = data.address;
    else if (label?.includes("password") && !label?.includes("confirm"))
      newValue = data.password;
    else if (label?.includes("confirm")) newValue = data.confirmPassword;

    if (newValue) {
      // ✅ Set value via native setter
      nativeInputValueSetter.call(input, newValue);

      // ✅ Trigger React's internal onChange listener
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    }
  });

  // cosnole.log("✅ React form autofilled successfully with:", data);
})();
