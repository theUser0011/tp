import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { CustomerSidebar } from "../../components/CustomerSidebar";
import { Header } from "../../components/Header";
import { Calendar, Filter, Eye } from "lucide-react";
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Select,
  MenuItem,
  FormControl,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  CircularProgress,
} from "@mui/material";
import { consoleTestStage } from "../../utils/consoleTestStage";
import api from "../../api/api"; // <-- API helper (axios instance)
import { toast } from "react-toastify"; // optional – for error toast

export const BookingHistory = () => {
  const navigate = useNavigate();
  const [bookings, setBookings] = useState([]);
  const [filterStatus, setFilterStatus] = useState("all");
  const [loading, setLoading] = useState(true);

  // --------------------------------------------------------------
  // 1. Load bookings from API (instead of localStorage)
  // --------------------------------------------------------------
  useEffect(() => {
    const loadBookings = async () => {
      try {
        setLoading(true);
        const response = await api.get("/bookings/history/"); // <-- REAL API
        consoleTestStage("API response:", response.data);

        const transformed = response.data.map((b) => ({
          ...b,
          bookingId: b.id,
          trainName: b.train_details?.train_name || "N/A",
          trainNumber: b.train_details?.train_number || "N/A",
          origin: b.train_details?.origin || "N/A",
          destination: b.train_details?.destination || "N/A",
          departureTime: b.train_details?.departure_time || "N/A",
          arrivalTime: b.train_details?.arrival_time || "N/A",
          travelDate: b.travel_date,
          class: b.travel_class,
          fare: Number(b.total_fare) || 0,
          status: b.status === "Booked" ? "confirmed" : "cancelled",
          passengers: b.passengers || []
        }));

        setBookings(transformed);
      } catch (err) {
        console.error("Failed to fetch bookings:", err);
        toast.error("Failed to load booking history");
      } finally {
        setLoading(false);
      }
    };

    loadBookings();
  }, []);

  // --------------------------------------------------------------
  // 2. Filter logic (unchanged)
  // --------------------------------------------------------------
  const filteredBookings = bookings.filter((booking) => {
    if (filterStatus === "all") return true;
    return booking.status === filterStatus;
  });

  consoleTestStage(filteredBookings);

  // --------------------------------------------------------------
  // 3. View details (unchanged)
  // --------------------------------------------------------------
  const handleViewDetails = (booking) => {
    navigate("/customer/ticket-details", { state: { booking } });
  };

  // --------------------------------------------------------------
  // 4. Render (100% unchanged UI)
  // --------------------------------------------------------------
  return (
    <Box sx={{ display: "flex", bgcolor: "background.default", minHeight: "100vh" }}>
      <CustomerSidebar />
      <Box sx={{ flex: 1, ml: "280px" }}>
        <Header title="Booking History" />
        <Box sx={{ p: 4 }}>
          <Card
            elevation={0}
            sx={{
              maxWidth: 1100,
              mx: "auto",
              p: 3,
              border: "1px solid rgba(37,99,235,0.1)",
              borderRadius: 3,
              background:
                "linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(248,250,252,0.9) 100%)",
              boxShadow: "0 10px 25px -5px rgba(37,99,235,0.05)",
              transition: "all 0.3s ease",
              "&:hover": {
                boxShadow: "0 20px 40px -10px rgba(37,99,235,0.1)",
              },
            }}
          >
            <CardContent>
              {/* Header */}
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  mb: 4,
                }}
              >
                <Typography variant="h5" fontWeight={600}>
                  My Bookings
                </Typography>
                <FormControl size="small" sx={{ minWidth: 180 }}>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Filter size={18} className="text-gray-400" />
                    <Select
                      value={filterStatus}
                      onChange={(e) => setFilterStatus(e.target.value)}
                      sx={{
                        "& .MuiOutlinedInput-notchedOutline": {
                          borderWidth: "2px",
                          borderColor: "rgba(37,99,235,0.3)",
                        },
                        "&:hover .MuiOutlinedInput-notchedOutline": {
                          borderColor: "rgba(37,99,235,0.5)",
                        },
                        "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                          borderColor: "#2563eb",
                        },
                        fontSize: "0.9rem",
                      }}
                    >
                      <MenuItem value="all">All Bookings</MenuItem>
                      <MenuItem value="confirmed">Confirmed</MenuItem>
                      <MenuItem value="cancelled">Cancelled</MenuItem>
                    </Select>
                  </Box>
                </FormControl>
              </Box>

              {loading ? (
                <Box sx={{ textAlign: "center", py: 10 }}>
                  <CircularProgress />
                </Box>
              ) : filteredBookings.length === 0 ? (
                <Box
                  sx={{
                    textAlign: "center",
                    py: 10,
                    color: "text.secondary",
                  }}
                >
                  <Calendar size={56} style={{ marginBottom: 16, opacity: 0.4 }} />
                  <Typography variant="body1" sx={{ mb: 3 }}>
                    No bookings found
                  </Typography>
                  <Button
                    variant="contained"
                    onClick={() => navigate("/customer/search-trains")}
                    sx={{
                      textTransform: "none",
                      px: 4,
                      py: 1.5,
                      fontWeight: 600,
                      fontSize: "1rem",
                      background:
                        "linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)",
                      "&:hover": {
                        background:
                          "linear-gradient(135deg, #1d4ed8 0%, #7c3aed 100%)",
                        transform: "scale(1.03)",
                        boxShadow: "0 8px 20px rgba(37,99,235,0.25)",
                      },
                      transition: "all 0.2s ease",
                      borderRadius: 2,
                    }}
                  >
                    Book Your First Ticket
                  </Button>
                </Box>
              ) : (
                <Box sx={{ overflowX: "auto" }}>
                  <Table>
                    <TableHead>
                      <TableRow sx={{ backgroundColor: "rgba(37,99,235,0.05)" }}>
                        <TableCell sx={{ fontWeight: 600 }}>Booking ID</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Train</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Route</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Travel Date</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Class</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Fare</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Actions</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {filteredBookings.map((booking) => (
                        <TableRow
                          key={booking.id}
                          sx={{
                            "&:hover": {
                              backgroundColor: "rgba(37,99,235,0.04)",
                            },
                          }}
                        >
                          <TableCell>{booking.bookingId}</TableCell>
                          <TableCell>
                            <Typography fontWeight={500}>{booking.trainName}</Typography>
                            <Typography variant="body2" color="text.secondary">
                              {booking.trainNumber}
                            </Typography>
                          </TableCell>
                          <TableCell color="text.secondary">
                            {booking.origin} to {booking.destination}
                          </TableCell>
                          <TableCell>{booking.travelDate}</TableCell>
                          <TableCell>{booking.class}</TableCell>
                          <TableCell>${booking.fare.toFixed(2)}</TableCell>
                          <TableCell>
                            <Box
                              sx={{
                                display: "inline-block",
                                px: 2,
                                py: 0.5,
                                borderRadius: "999px",
                                fontSize: "0.75rem",
                                fontWeight: 600,
                                color:
                                  booking.status === "confirmed"
                                    ? "#16a34a"
                                    : "#dc2626",
                                backgroundColor:
                                  booking.status === "confirmed"
                                    ? "rgba(16,185,129,0.1)"
                                    : "rgba(220,38,38,0.1)",
                              }}
                            >
                              {booking.status}
                            </Box>
                          </TableCell>
                          <TableCell>
                            <Button
                              onClick={() => handleViewDetails(booking)}
                              sx={{
                                minWidth: 0,
                                p: 1,
                                borderRadius: 2,
                                color: "#2563eb",
                                "&:hover": {
                                  backgroundColor: "rgba(37,99,235,0.1)",
                                },
                              }}
                            >
                              <Eye size={18} />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </Box>
              )}
            </CardContent>
          </Card>
        </Box>
      </Box>
    </Box>
  );
};