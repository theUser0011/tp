import { CustomerSidebar } from '../../components/CustomerSidebar';
import { Header } from '../../components/Header';
import { Ticket, Clock, CheckCircle, XCircle, Calendar, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Box, Grid, Card, CardContent, Typography, Avatar, Button, Chip } from '@mui/material';
import { consoleTestStage } from '../../utils/consoleTestStage';

export const CustomerDashboard = () => {
  const navigate = useNavigate();

  // Fetch current user and bookings from localStorage
  const user = JSON.parse(localStorage.getItem('currentUser') || '{}');
  const bookingsData = localStorage.getItem('bookings') || '[]';
  const bookings = JSON.parse(bookingsData);

  // Filter bookings for current user
  const userBookings = bookings.filter(b => b.userId === user.username || b.userId === user.id);

  // Optional: log localStorage for debugging
  consoleTestStage(localStorage);

  // Stats cards with dynamic counts
  const stats = [
    {
      title: 'Total Bookings',
      value: userBookings.length.toString(),
      icon: Ticket,
      color: '#2563eb',
      gradient: 'linear-gradient(135deg, #2563eb 0%, #4f46e5 100%)',
    },
    {
      title: 'Upcoming Trips',
      value: userBookings.filter(b => b.status === 'confirmed').length.toString(),
      icon: Calendar,
      color: '#10b981',
      gradient: 'linear-gradient(135deg, #10b981 0%, #14b8a6 100%)',
    },
    {
      title: 'Completed',
      value: userBookings.filter(b => b.status === 'completed').length.toString(),
      icon: CheckCircle,
      color: '#8b5cf6',
      gradient: 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)',
    },
    {
      title: 'Cancelled',
      value: userBookings.filter(b => b.status === 'cancelled').length.toString(),
      icon: XCircle,
      color: '#ef4444',
      gradient: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
    },
  ];

  // Get last 5 bookings
  const recentBookings = userBookings.slice(-5).reverse();

  // Quick actions remain unchanged
  const quickActions = [
    {
      title: 'Search & Book Trains',
      description: 'Find trains for your journey',
      icon: Ticket,
      color: '#2563eb',
      gradient: 'linear-gradient(135deg, #2563eb 0%, #4f46e5 100%)',
      path: '/customer/search-trains',
    },
    {
      title: 'View Booking History',
      description: 'Check all your bookings',
      icon: Clock,
      color: '#8b5cf6',
      gradient: 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)',
      path: '/customer/booking-history',
    },
    {
      title: 'Cancel Ticket',
      description: 'Cancel your booking',
      icon: XCircle,
      color: '#ef4444',
      gradient: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
      path: '/customer/cancel-ticket',
    },
  ];

  return (
    <Box sx={{ display: 'flex', bgcolor: 'background.default', minHeight: '100vh' }}>
      <CustomerSidebar />
      <Box sx={{ flex: 1, ml: '280px' }}>
        <Header title="Customer Dashboard" />

        <Box sx={{ p: 4 }}>
          {/* Welcome Banner */}
          <Card
            elevation={0}
            sx={{
              mb: 4,
              background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
              color: 'white',
              border: 'none',
              position: 'relative',
              overflow: 'hidden',
              '&::before': {
                content: '""',
                position: 'absolute',
                top: '-50%',
                right: '-10%',
                width: '400px',
                height: '400px',
                borderRadius: '50%',
                background: 'rgba(255, 255, 255, 0.1)',
              },
              '&::after': {
                content: '""',
                position: 'absolute',
                bottom: '-30%',
                left: '-5%',
                width: '300px',
                height: '300px',
                borderRadius: '50%',
                background: 'rgba(255, 255, 255, 0.08)',
              }
            }}
          >
            <CardContent sx={{ p: 4, position: 'relative', zIndex: 1 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <Sparkles size={24} />
                <Typography variant="h4" sx={{ color: 'white' }}>
                  Welcome back, {user.first_name || user.name || user.username}!
                </Typography>
              </Box>
              <Typography sx={{ mb: 3, color: 'rgba(255,255,255,0.9)' }}>
                Ready to plan your next journey?
              </Typography>
              <Button
                variant="contained"
                onClick={() => navigate('/customer/search-trains')}
                sx={{
                  bgcolor: 'white',
                  color: 'primary.main',
                  '&:hover': {
                    bgcolor: 'grey.100',
                    transform: 'scale(1.05)',
                    boxShadow: '0 8px 20px rgba(0, 0, 0, 0.2)',
                  },
                  textTransform: 'none',
                  px: 3,
                  py: 1.5,
                  transition: 'all 0.2s',
                }}
              >
                Book a Ticket
              </Button>
            </CardContent>
          </Card>

          {/* Stats Section */}
          <Grid container spacing={3} justifyContent="center" sx={{ m: 6, mt: -4 }}>
            {stats.map((stat, i) => (
              <Grid key={i} size={{ xs: 12, sm: 6, md: 3 }}>
                <Card
                  elevation={0}
                  sx={{
                    borderRadius: "28px",
                    mt:3,
                    p: 3,
                    textAlign: "center",
                    background: "rgba(255, 255, 255, 0.8)",
                    backdropFilter: "blur(12px)",
                    border: "1px solid rgba(255,255,255,0.5)",
                    boxShadow: `
                      inset 4px 4px 8px rgba(255,255,255,0.6),
                      6px 6px 20px rgba(0,0,0,0.05)
                    `,
                    transition: "all 0.3s ease",
                    "&:hover": {
                      transform: "translateY(-6px)",
                      boxShadow: `0 10px 25px ${stat.shadow}`,
                    },
                  }}
                >
                  <Box
                    sx={{
                      mx: "auto",
                      width: 60,
                      height: 60,
                      borderRadius: "50%",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      mb: 2,
                      background: stat.gradient,
                      color: "white",
                      boxShadow: `0 6px 14px ${stat.shadow}`,
                    }}
                  >
                    <stat.icon size={28} color="white" />
                  </Box>
                  <Typography
                    variant="h4"
                    sx={{
                      fontWeight: 700,
                      color: stat.color,
                      mb: 0.5,
                    }}
                  >
                    {stat.value}
                  </Typography>
                  <Typography
                    variant="subtitle2"
                    sx={{ color: "text.secondary", fontWeight: 500 }}
                  >
                    {stat.title}
                  </Typography>
                </Card>
              </Grid>
            ))}
          </Grid>

          <Grid container spacing={3}>
            {/* Recent Bookings */}
            <Grid size={{ xs: 12, lg: 6 }}>
              <Card
                elevation={0}
                sx={{
                  border: '1px solid',
                  borderColor: 'rgba(37, 99, 235, 0.1)',
                  background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
                  transition: 'all 0.3s',
                  '&:hover': {
                    boxShadow: '0 10px 25px -5px rgba(37, 99, 235, 0.15)',
                  }
                }}
              >
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                    <Typography
                      variant="h6"
                      sx={{
                        background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                        backgroundClip: 'text',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                      }}
                    >
                      Recent Bookings
                    </Typography>
                    <Button
                      size="small"
                      onClick={() => navigate('/customer/booking-history')}
                      sx={{
                        textTransform: 'none',
                        background: 'linear-gradient(135deg, rgba(37, 99, 235, 0.1) 0%, rgba(139, 92, 246, 0.1) 100%)',
                        '&:hover': {
                          background: 'linear-gradient(135deg, rgba(37, 99, 235, 0.2) 0%, rgba(139, 92, 246, 0.2) 100%)',
                        }
                      }}
                    >
                      View All
                    </Button>
                  </Box>
                  {recentBookings.length === 0 ? (
                    <Box sx={{ textAlign: 'center', py: 4 }}>
                      <Ticket size={48} color="#d1d5db" />
                      <Typography color="text.secondary" sx={{ mt: 2, mb: 2 }}>
                        No bookings yet
                      </Typography>
                      <Button
                        variant="contained"
                        size="small"
                        onClick={() => navigate('/customer/search-trains')}
                        sx={{
                          textTransform: 'none',
                          background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                          '&:hover': {
                            background: 'linear-gradient(135deg, #1d4ed8 0%, #7c3aed 100%)',
                          }
                        }}
                      >
                        Book Your First Ticket
                      </Button>
                    </Box>
                  ) : (
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                      {recentBookings.map((booking, idx) => (
                        <Box
                          key={booking.id}
                          sx={{
                            p: 2,
                            bgcolor: 'grey.50',
                            borderRadius: 2,
                            borderLeft: '3px solid',
                            borderLeftColor: booking.status === 'confirmed' ? '#10b981' : '#ef4444',
                            transition: 'all 0.2s',
                            animation: `fadeIn 0.3s ease-out ${idx * 0.1}s both`,
                            '&:hover': {
                              bgcolor: 'white',
                              transform: 'translateX(4px)',
                              boxShadow: '0 4px 12px rgba(37, 99, 235, 0.1)',
                            },
                            '@keyframes fadeIn': {
                              from: { opacity: 0 },
                              to: { opacity: 1 },
                            },
                          }}
                        >
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                            <Typography sx={{ fontWeight: 600 }}>
                              {booking.trainName}
                            </Typography>
                            <Chip
                              label={booking.status}
                              size="small"
                              sx={{
                                background: booking.status === 'confirmed'
                                  ? 'linear-gradient(135deg, #10b981 0%, #14b8a6 100%)'
                                  : 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
                                color: 'white',
                              }}
                            />
                          </Box>
                          <Typography variant="caption" color="text.secondary">
                            {booking.origin} → {booking.destination}
                          </Typography>
                          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                            Date: {booking.travelDate} • Class: {booking.class}
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                  )}
                </CardContent>
              </Card>
            </Grid>

            {/* Quick Actions */}
            <Grid item xs={12} lg={6}>
              <Card
                elevation={0}
                sx={{
                  border: '1px solid',
                  borderColor: 'rgba(37, 99, 235, 0.1)',
                  background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
                  transition: 'all 0.3s',
                  '&:hover': {
                    boxShadow: '0 10px 25px -5px rgba(37, 99, 235, 0.15)',
                  }
                }}
              >
                <CardContent>
                  <Typography
                    variant="h6"
                    sx={{
                      mb: 3,
                      background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                      backgroundClip: 'text',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                    }}
                  >
                    Quick Actions
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    {quickActions.map((action, index) => {
                      const Icon = action.icon;
                      return (
                        <Card
                          key={index}
                          elevation={0}
                          sx={{
                            cursor: 'pointer',
                            background: `linear-gradient(135deg, ${action.color}10 0%, ${action.color}05 100%)`,
                            border: '1px solid',
                            borderColor: `${action.color}30`,
                            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                            animation: `fadeIn 0.3s ease-out ${index * 0.15}s both`,
                            '&:hover': {
                              transform: 'translateX(8px)',
                              boxShadow: `0 8px 20px ${action.color}30`,
                              borderColor: action.color,
                            },
                            '@keyframes fadeIn': {
                              from: { opacity: 0 },
                              to: { opacity: 1 },
                            },
                          }}
                          onClick={() => navigate(action.path)}
                        >
                          <CardContent sx={{ p: 2.5, display: 'flex', gap: 2, alignItems: 'center' }}>
                            <Avatar
                              sx={{
                                background: action.gradient,
                                width: 48,
                                height: 48,
                                boxShadow: `0 4px 12px ${action.color}40`,
                              }}
                            >
                              <Icon size={24} color="white" />
                            </Avatar>
                            <Box>
                              <Typography
                                sx={{
                                  fontWeight: 600,
                                  color: action.color
                                }}
                              >
                                {action.title}
                              </Typography>
                              <Typography variant="caption" sx={{ color: 'text.secondary' }}>
                                {action.description}
                              </Typography>
                            </Box>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </Box>
  );
};
