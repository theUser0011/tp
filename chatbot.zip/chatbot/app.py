from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from langchain_ollama.chat_models import ChatOllama
import logging

app = Flask(__name__)

# Configure CORS to allow requests from any origin to the /chat endpoint
CORS(app, resources={r"/chat": {"origins": "*"}})

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Log application startup
logger.info("Starting Flask application")

# Initialize ChatOllama with gpt-oss:20b model
MODEL_BASE_URL = "http://172.20.203.198:7777"
MODEL_ID = "gpt-oss:20b"
logger.info("Initializing ChatOllama with model: %s at %s", MODEL_ID, MODEL_BASE_URL)
ollama_model = ChatOllama(base_url=MODEL_BASE_URL, model=MODEL_ID, temperature=0.7)
logger.info("ChatOllama initialization completed")

@app.route('/')
def index():
    """Render the main index page."""
    logger.info("Handling request for index page")
    response = render_template('index.html')
    logger.info("Index page rendering completed")
    return response

@app.route('/chat', methods=['GET', 'POST'])
def chat():
    """Handle chat interactions."""
    logger.info("Starting chat endpoint request processing")
    if request.method == 'POST':
        try:
            user_message = request.form.get('message')
            if not user_message:
                logger.warning("No message provided in request")
                return jsonify({'error': 'No message provided'}), 400

            logger.info("Received user message: %s", user_message)

            # Prepare message for Ollama
            logger.info("Preparing message for Ollama model")
            messages = [{"role": "user", "content": user_message}]

            # Invoke the model
            logger.info("Invoking Ollama model for response")
            response = ollama_model.invoke(messages)
            bot_response = response.content
            logger.info("Model response received: %s", bot_response)
            logger.info("Chat response generation completed")

            return jsonify({'response': bot_response})

        except Exception as e:
            logger.error("Error invoking model: %s", str(e))
            return jsonify({'error': 'Failed to get response from model'}), 500

    logger.info("Rendering chat page")
    response = render_template('chat.html')
    logger.info("Chat page rendering completed")
    return response

if __name__ == '__main__':
    logger.info("Starting Flask server on host 0.0.0.0, port 5000")
    app.run(debug=True, host='0.0.0.0', port=5000)
    logger.info("Flask server startup completed")