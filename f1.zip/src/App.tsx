import { useState } from 'react';
import LandingPage from './components/LandingPage.jsx';
import LoginPage from './components/LoginPage.jsx';
import CustomerRegistration from './components/CustomerRegistration.jsx';
import AdminRegistration from './components/AdminRegistration.jsx';
import CustomerDashboard from './components/CustomerDashboard.jsx';
import AdminDashboard from './components/AdminDashboard.jsx';
import './styles/App.css';

export default function App() {
  const [currentPage, setCurrentPage] = useState('landing');
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([
    {
      id: 1,
      username: 'customer1',
      password: 'password123',
      role: 'customer',
      name: 'John Doe',
      email: 'john@example.com',
      phone: '123-456-7890',
      address: '123 Main St, City, State',
      meterNumber: 'MTR001',
      isActive: true
    },
    {
      id: 2,
      username: 'admin1',
      password: 'admin123',
      role: 'admin',
      name: 'Admin User',
      email: 'admin@example.com'
    }
  ]);

  const [bills, setBills] = useState<any[]>([
    {
      id: 1,
      customerId: 1,
      billNumber: 'BILL001',
      month: 'October 2024',
      unitsConsumed: 450,
      amount: 2250,
      dueDate: '2024-11-15',
      status: 'unpaid'
    },
    {
      id: 2,
      customerId: 1,
      billNumber: 'BILL002',
      month: 'September 2024',
      unitsConsumed: 420,
      amount: 2100,
      dueDate: '2024-10-15',
      status: 'paid',
      paidDate: '2024-10-12'
    }
  ]);

  const [complaints, setComplaints] = useState<any[]>([
    {
      id: 1,
      customerId: 1,
      complaintNumber: 'CMP001',
      subject: 'High Bill Amount',
      description: 'My bill is unusually high this month',
      date: '2024-10-20',
      status: 'pending'
    }
  ]);

  const handleLogin = (username: string, password: string) => {
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
      if (user.role === 'customer' && !user.isActive) {
        return { success: false, message: 'Your account is deactivated. Please contact support.' };
      }
      setCurrentUser(user);
      setCurrentPage(user.role === 'admin' ? 'admin-dashboard' : 'customer-dashboard');
      return { success: true };
    }
    return { success: false, message: 'Invalid username or password' };
  };

  const handleCustomerRegistration = (customerData: any) => {
    const newCustomer = {
      id: users.length + 1,
      ...customerData,
      role: 'customer',
      isActive: true
    };
    setUsers([...users, newCustomer]);
    return { success: true };
  };

  const handleAdminRegistration = (adminData: any) => {
    const newAdmin = {
      id: users.length + 1,
      ...adminData,
      role: 'admin'
    };
    setUsers([...users, newAdmin]);
    return { success: true };
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentPage('landing');
  };

  const handlePayBill = (billId: number) => {
    setBills(bills.map(bill => 
      bill.id === billId 
        ? { ...bill, status: 'paid', paidDate: new Date().toISOString().split('T')[0] }
        : bill
    ));
  };

  const handleRegisterComplaint = (complaintData: any) => {
    const newComplaint = {
      id: complaints.length + 1,
      customerId: currentUser.id,
      complaintNumber: `CMP${String(complaints.length + 1).padStart(3, '0')}`,
      ...complaintData,
      date: new Date().toISOString().split('T')[0],
      status: 'pending'
    };
    setComplaints([...complaints, newComplaint]);
    return { success: true };
  };

  const handleUpdateCustomer = (updatedData: any) => {
    setUsers(users.map(user => 
      user.id === currentUser.id 
        ? { ...user, ...updatedData }
        : user
    ));
    setCurrentUser({ ...currentUser, ...updatedData });
    return { success: true };
  };

  const handleToggleActivation = () => {
    const newActiveStatus = !currentUser.isActive;
    setUsers(users.map(user => 
      user.id === currentUser.id 
        ? { ...user, isActive: newActiveStatus }
        : user
    ));
    setCurrentUser({ ...currentUser, isActive: newActiveStatus });
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'landing':
        return <LandingPage onNavigate={setCurrentPage} />;
      case 'login':
        return <LoginPage onLogin={handleLogin} onNavigate={setCurrentPage} />;
      case 'customer-registration':
        return <CustomerRegistration onRegister={handleCustomerRegistration} onNavigate={setCurrentPage} />;
      case 'admin-registration':
        return <AdminRegistration onRegister={handleAdminRegistration} onNavigate={setCurrentPage} />;
      case 'customer-dashboard':
        return (
          <CustomerDashboard 
            user={currentUser}
            bills={bills.filter(b => b.customerId === currentUser.id)}
            complaints={complaints.filter(c => c.customerId === currentUser.id)}
            onLogout={handleLogout}
            onPayBill={handlePayBill}
            onRegisterComplaint={handleRegisterComplaint}
            onUpdateCustomer={handleUpdateCustomer}
            onToggleActivation={handleToggleActivation}
          />
        );
      case 'admin-dashboard':
        return (
          <AdminDashboard 
            users={users}
            bills={bills}
            complaints={complaints}
            onLogout={handleLogout}
            onUpdateComplaintStatus={(complaintId, status) => {
              setComplaints(complaints.map(c => 
                c.id === complaintId ? { ...c, status } : c
              ));
            }}
            onToggleCustomerStatus={(customerId) => {
              setUsers(users.map(u => 
                u.id === customerId ? { ...u, isActive: !u.isActive } : u
              ));
            }}
          />
        );
      default:
        return <LandingPage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="app">
      {renderPage()}
    </div>
  );
}
