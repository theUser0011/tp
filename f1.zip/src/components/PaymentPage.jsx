import { useState } from 'react';
import '../styles/PaymentPage.css';

export default function PaymentPage({ bill, user, onPaymentComplete, onCancel }) {
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [upiId, setUpiId] = useState('');
  const [processing, setProcessing] = useState(false);

  const handlePayment = (e) => {
    e.preventDefault();
    setProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setProcessing(false);
      onPaymentComplete(bill.id);
    }, 2000);
  };

  return (
    <div className="payment-page">
      <div className="payment-container">
        <div className="payment-header">
          <h2>Payment</h2>
          <button className="close-btn" onClick={onCancel}>×</button>
        </div>

        <div className="payment-content">
          <div className="bill-summary">
            <h3>Bill Summary</h3>
            <div className="summary-row">
              <span>Bill Number:</span>
              <span>{bill.billNumber}</span>
            </div>
            <div className="summary-row">
              <span>Month:</span>
              <span>{bill.month}</span>
            </div>
            <div className="summary-row">
              <span>Units Consumed:</span>
              <span>{bill.unitsConsumed} kWh</span>
            </div>
            <div className="summary-row">
              <span>Customer Name:</span>
              <span>{user.name}</span>
            </div>
            <div className="summary-row">
              <span>Meter Number:</span>
              <span>{user.meterNumber}</span>
            </div>
            <div className="summary-row total">
              <span>Total Amount:</span>
              <span>${bill.amount}</span>
            </div>
          </div>

          <div className="payment-form-container">
            <h3>Payment Method</h3>
            
            <div className="payment-methods">
              <button
                className={`payment-method-btn ${paymentMethod === 'card' ? 'active' : ''}`}
                onClick={() => setPaymentMethod('card')}
              >
                💳 Credit/Debit Card
              </button>
              <button
                className={`payment-method-btn ${paymentMethod === 'upi' ? 'active' : ''}`}
                onClick={() => setPaymentMethod('upi')}
              >
                📱 UPI
              </button>
              <button
                className={`payment-method-btn ${paymentMethod === 'netbanking' ? 'active' : ''}`}
                onClick={() => setPaymentMethod('netbanking')}
              >
                🏦 Net Banking
              </button>
            </div>

            <form onSubmit={handlePayment}>
              {paymentMethod === 'card' && (
                <>
                  <div className="input-group">
                    <label htmlFor="cardNumber">Card Number</label>
                    <input
                      type="text"
                      id="cardNumber"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      placeholder="1234 5678 9012 3456"
                      maxLength="19"
                      required
                    />
                  </div>
                  <div className="input-group">
                    <label htmlFor="cardName">Cardholder Name</label>
                    <input
                      type="text"
                      id="cardName"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                      placeholder="John Doe"
                      required
                    />
                  </div>
                  <div className="form-row">
                    <div className="input-group">
                      <label htmlFor="expiryDate">Expiry Date</label>
                      <input
                        type="text"
                        id="expiryDate"
                        value={expiryDate}
                        onChange={(e) => setExpiryDate(e.target.value)}
                        placeholder="MM/YY"
                        maxLength="5"
                        required
                      />
                    </div>
                    <div className="input-group">
                      <label htmlFor="cvv">CVV</label>
                      <input
                        type="text"
                        id="cvv"
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value)}
                        placeholder="123"
                        maxLength="3"
                        required
                      />
                    </div>
                  </div>
                </>
              )}

              {paymentMethod === 'upi' && (
                <div className="input-group">
                  <label htmlFor="upiId">UPI ID</label>
                  <input
                    type="text"
                    id="upiId"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    placeholder="yourname@upi"
                    required
                  />
                </div>
              )}

              {paymentMethod === 'netbanking' && (
                <div className="input-group">
                  <label htmlFor="bank">Select Bank</label>
                  <select id="bank" required>
                    <option value="">Choose your bank</option>
                    <option value="hdfc">HDFC Bank</option>
                    <option value="icici">ICICI Bank</option>
                    <option value="sbi">State Bank of India</option>
                    <option value="axis">Axis Bank</option>
                    <option value="kotak">Kotak Mahindra Bank</option>
                  </select>
                </div>
              )}

              <div className="payment-actions">
                <button
                  type="submit"
                  className="btn btn-primary btn-full"
                  disabled={processing}
                >
                  {processing ? 'Processing...' : `Pay $${bill.amount}`}
                </button>
                <button
                  type="button"
                  className="btn btn-secondary btn-full"
                  onClick={onCancel}
                  disabled={processing}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
