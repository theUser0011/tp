import { useState } from 'react';
import '../styles/Dashboard.css';

export default function AdminDashboard({ users, bills, complaints, onLogout, onUpdateComplaintStatus, onToggleCustomerStatus }) {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [searchQuery, setSearchQuery] = useState('');

  const customers = users.filter(u => u.role === 'customer');
  const activeCustomers = customers.filter(c => c.isActive);
  const pendingComplaints = complaints.filter(c => c.status === 'pending');
  const totalRevenue = bills.filter(b => b.status === 'paid').reduce((sum, b) => sum + b.amount, 0);

  const filteredComplaints = complaints.filter(c => {
    const customer = users.find(u => u.id === c.customerId);
    return (c.subject && c.subject.toLowerCase().includes(searchQuery.toLowerCase())) ||
           (c.complaintType && c.complaintType.toLowerCase().includes(searchQuery.toLowerCase())) ||
           c.complaintNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
           (customer && customer.name.toLowerCase().includes(searchQuery.toLowerCase()));
  });

  const renderDashboard = () => (
    <div className="dashboard-content">
      <h2>Admin Dashboard</h2>
      <p>System overview and statistics</p>
      
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon">👥</div>
          <div className="stat-info">
            <div className="stat-value">{customers.length}</div>
            <div className="stat-label">Total Customers</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">✅</div>
          <div className="stat-info">
            <div className="stat-value">{activeCustomers.length}</div>
            <div className="stat-label">Active Customers</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">📝</div>
          <div className="stat-info">
            <div className="stat-value">{pendingComplaints.length}</div>
            <div className="stat-label">Pending Complaints</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">💰</div>
          <div className="stat-info">
            <div className="stat-value">${totalRevenue}</div>
            <div className="stat-label">Total Revenue</div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCustomers = () => (
    <div className="dashboard-content">
      <h2>Manage Customers</h2>
      {customers.length === 0 ? (
        <div className="empty-state">No customers registered</div>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Meter Number</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {customers.map(customer => (
              <tr key={customer.id}>
                <td>{customer.name}</td>
                <td>{customer.email}</td>
                <td>{customer.phone || 'N/A'}</td>
                <td>{customer.meterNumber || 'N/A'}</td>
                <td>
                  <span className={`badge ${customer.isActive ? 'badge-success' : 'badge-danger'}`}>
                    {customer.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td>
                  <button 
                    className={`btn ${customer.isActive ? 'btn-danger' : 'btn-success'}`}
                    onClick={() => onToggleCustomerStatus(customer.id)}
                  >
                    {customer.isActive ? 'Deactivate' : 'Activate'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );

  const renderBills = () => (
    <div className="dashboard-content">
      <h2>All Bills</h2>
      {bills.length === 0 ? (
        <div className="empty-state">No bills found</div>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>Bill Number</th>
              <th>Customer</th>
              <th>Month</th>
              <th>Units</th>
              <th>Amount</th>
              <th>Due Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {bills.map(bill => {
              const customer = users.find(u => u.id === bill.customerId);
              return (
                <tr key={bill.id}>
                  <td>{bill.billNumber}</td>
                  <td>{customer?.name || 'Unknown'}</td>
                  <td>{bill.month}</td>
                  <td>{bill.unitsConsumed} kWh</td>
                  <td>${bill.amount}</td>
                  <td>{bill.dueDate}</td>
                  <td>
                    <span className={`badge ${bill.status === 'paid' ? 'badge-success' : 'badge-warning'}`}>
                      {bill.status}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );

  const renderComplaints = () => (
    <div className="dashboard-content">
      <h2>Manage Complaints</h2>
      <div className="input-group" style={{ maxWidth: '400px', marginBottom: '20px' }}>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search complaints..."
        />
      </div>
      {filteredComplaints.length === 0 ? (
        <div className="empty-state">No complaints found</div>
      ) : (
        <div className="complaints-grid">
          {filteredComplaints.map(complaint => {
            const customer = users.find(u => u.id === complaint.customerId);
            return (
              <div key={complaint.id} className="card">
                <div className="complaint-header">
                  <h3>{complaint.complaintNumber}</h3>
                  <span className={`badge ${complaint.status === 'pending' ? 'badge-warning' : complaint.status === 'resolved' ? 'badge-success' : 'badge-info'}`}>
                    {complaint.status}
                  </span>
                </div>
                {complaint.complaintType && (
                  <>
                    <div style={{ marginBottom: '10px' }}>
                      <strong>Type:</strong> {complaint.complaintType} | <strong>Category:</strong> {complaint.category}
                    </div>
                    {complaint.billId && (
                      <div style={{ marginBottom: '10px' }}>
                        <strong>Bill ID:</strong> {complaint.billId}
                      </div>
                    )}
                  </>
                )}
                {complaint.subject && <h4>{complaint.subject}</h4>}
                {complaint.description && <p>{complaint.description}</p>}
                <div className="complaint-footer">
                  <span>Customer: {customer?.name || 'Unknown'}</span>
                  <span>Date: {complaint.date}</span>
                </div>
                {complaint.status === 'pending' && (
                  <div style={{ marginTop: '10px', display: 'flex', gap: '10px' }}>
                    <button 
                      className="btn btn-success"
                      onClick={() => onUpdateComplaintStatus(complaint.id, 'resolved')}
                    >
                      Mark Resolved
                    </button>
                    <button 
                      className="btn btn-secondary"
                      onClick={() => onUpdateComplaintStatus(complaint.id, 'in-progress')}
                    >
                      In Progress
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return renderDashboard();
      case 'customers':
        return renderCustomers();
      case 'bills':
        return renderBills();
      case 'complaints':
        return renderComplaints();
      default:
        return renderDashboard();
    }
  };

  return (
    <div className="dashboard-layout">
      <aside className="sidebar">
        <div className="sidebar-header">
          <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
            <path d="M22 3L12 18H20L18 35L30 18H22L24 3Z" fill="#38bdf8" stroke="#0ea5e9" strokeWidth="2" strokeLinejoin="round"/>
          </svg>
          <span>PowerBill Pro</span>
        </div>

        <nav className="sidebar-nav">
          <button
            className={`nav-item ${activeSection === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveSection('dashboard')}
          >
            <span className="nav-icon">🏠</span>
            <span>Dashboard</span>
          </button>
          <button
            className={`nav-item ${activeSection === 'customers' ? 'active' : ''}`}
            onClick={() => setActiveSection('customers')}
          >
            <span className="nav-icon">👥</span>
            <span>Customers</span>
          </button>
          <button
            className={`nav-item ${activeSection === 'bills' ? 'active' : ''}`}
            onClick={() => setActiveSection('bills')}
          >
            <span className="nav-icon">📊</span>
            <span>Bills</span>
          </button>
          <button
            className={`nav-item ${activeSection === 'complaints' ? 'active' : ''}`}
            onClick={() => setActiveSection('complaints')}
          >
            <span className="nav-icon">📝</span>
            <span>Complaints</span>
          </button>
        </nav>

        <div className="sidebar-footer">
          <button className="btn btn-danger btn-full" onClick={onLogout}>
            Logout
          </button>
        </div>
      </aside>

      <main className="dashboard-main">
        <div className="dashboard-header">
          <h1>Administrator Portal</h1>
        </div>

        {renderContent()}
      </main>
    </div>
  );
}
