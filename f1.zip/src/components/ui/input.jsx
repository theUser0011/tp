import React from "react";
import { cn } from "./utils.js";
import './input.css';

const Input = React.forwardRef(({ 
  className = '', 
  type = 'text', 
  ...props 
}, ref) => {
  return (
    <input
      ref={ref}
      type={type}
      className={cn('input', className)}
      {...props}
    />
  );
});

Input.displayName = "Input";

export { Input };