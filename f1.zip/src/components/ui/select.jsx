import React from "react";
import { cn } from "./utils.js";
import './select.css';

const Select = React.forwardRef(({ 
  className = '', 
  children,
  ...props 
}, ref) => {
  return (
    <select
      ref={ref}
      className={cn('select', className)}
      {...props}
    >
      {children}
    </select>
  );
});

Select.displayName = "Select";

const SelectOption = React.forwardRef(({ 
  className = '', 
  children,
  ...props 
}, ref) => {
  return (
    <option
      ref={ref}
      className={cn('select-option', className)}
      {...props}
    >
      {children}
    </option>
  );
});

SelectOption.displayName = "SelectOption";

const SelectGroup = React.forwardRef(({ 
  className = '', 
  children,
  ...props 
}, ref) => {
  return (
    <optgroup
      ref={ref}
      className={cn('select-group', className)}
      {...props}
    >
      {children}
    </optgroup>
  );
});

SelectGroup.displayName = "SelectGroup";

export {
  Select,
  SelectOption,
  SelectGroup,
};