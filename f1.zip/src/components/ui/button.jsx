import React from "react";
import { cn } from "./utils.js";
import './button.css';

const Button = React.forwardRef(({ 
  className = '',
  variant = 'default',
  size = 'default', 
  children,
  ...props 
}, ref) => {
  const baseClass = 'btn';
  const variantClass = `btn-${variant}`;
  const sizeClass = `btn-${size}`;
  
  return (
    <button
      ref={ref}
      className={cn(baseClass, variantClass, sizeClass, className)}
      {...props}
    >
      {children}
    </button>
  );
});

Button.displayName = "Button";

export { Button };