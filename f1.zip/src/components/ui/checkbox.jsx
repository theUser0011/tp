import React from "react";
import { Check } from "lucide-react";
import { cn } from "./utils.js";
import './checkbox.css';

const Checkbox = React.forwardRef(({ 
  className = '', 
  children,
  ...props 
}, ref) => {
  return (
    <div className="checkbox-wrapper">
      <input
        ref={ref}
        type="checkbox"
        className={cn('checkbox', className)}
        {...props}
      />
      <div className="checkbox-indicator">
        <Check className="checkbox-icon" />
      </div>
      {children}
    </div>
  );
});

Checkbox.displayName = "Checkbox";

export { Checkbox };