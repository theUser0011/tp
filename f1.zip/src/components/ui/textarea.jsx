import React from "react";
import { cn } from "./utils.js";
import './textarea.css';

const Textarea = React.forwardRef(({ className = '', ...props }, ref) => {
  return (
    <textarea
      ref={ref}
      className={cn('textarea', className)}
      {...props}
    />
  );
});

Textarea.displayName = "Textarea";

export { Textarea };