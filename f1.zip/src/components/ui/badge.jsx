import React from "react";
import { cn } from "./utils.js";
import './badge.css';

const Badge = React.forwardRef(({ 
  className = '', 
  variant = 'default', 
  children,
  ...props 
}, ref) => {
  const baseClass = 'badge';
  const variantClass = `badge-${variant}`;
  
  return (
    <span
      ref={ref}
      className={cn(baseClass, variantClass, className)}
      {...props}
    >
      {children}
    </span>
  );
});

Badge.displayName = "Badge";

export { Badge };