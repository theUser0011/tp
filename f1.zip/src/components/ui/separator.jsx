import React from "react";
import { cn } from "./utils.js";
import './separator.css';

const Separator = React.forwardRef(({ 
  className = '', 
  orientation = 'horizontal',
  ...props 
}, ref) => {
  return (
    <div
      ref={ref}
      className={cn('separator', `separator-${orientation}`, className)}
      role="separator"
      aria-orientation={orientation}
      {...props}
    />
  );
});

Separator.displayName = "Separator";

export { Separator };