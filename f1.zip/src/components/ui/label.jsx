import React from "react";
import { cn } from "./utils.js";
import './label.css';

const Label = React.forwardRef(({ className = '', ...props }, ref) => {
  return (
    <label
      ref={ref}
      className={cn('label', className)}
      {...props}
    />
  );
});

Label.displayName = "Label";

export { Label };