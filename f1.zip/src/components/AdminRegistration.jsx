import { useState } from 'react';
import '../styles/Registration.css';

export default function AdminRegistration({ onRegister, onNavigate }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    username: '',
    password: '',
    confirmPassword: '',
    adminCode: ''
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    // Validation
    if (!formData.name || !formData.email || !formData.username || !formData.password || !formData.adminCode) {
      setError('Please fill in all required fields');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters long');
      return;
    }

    // Simple admin code validation (in real app, this would be server-side)
    if (formData.adminCode !== 'ADMIN2024') {
      setError('Invalid admin code');
      return;
    }

    const result = onRegister(formData);
    if (result.success) {
      setSuccess(true);
      setTimeout(() => {
        onNavigate('login');
      }, 2000);
    }
  };

  return (
    <div className="registration-page">
      <div className="registration-container">
        <div className="registration-card">
          <div className="registration-header">
            <h1>Administrator Registration</h1>
            <p>Create admin account to manage the system</p>
          </div>

          {error && (
            <div className="alert alert-error">
              {error}
            </div>
          )}

          {success && (
            <div className="alert alert-success">
              Registration successful! Redirecting to login...
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="input-group">
                <label htmlFor="name">Full Name *</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Enter your full name"
                />
              </div>

              <div className="input-group">
                <label htmlFor="email">Email *</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Enter your email"
                />
              </div>
            </div>

            <div className="form-row">
              <div className="input-group">
                <label htmlFor="username">Username *</label>
                <input
                  type="text"
                  id="username"
                  name="username"
                  value={formData.username}
                  onChange={handleChange}
                  placeholder="Choose a username"
                />
              </div>

              <div className="input-group">
                <label htmlFor="adminCode">Admin Code *</label>
                <input
                  type="text"
                  id="adminCode"
                  name="adminCode"
                  value={formData.adminCode}
                  onChange={handleChange}
                  placeholder="Enter admin code"
                />
              </div>
            </div>

            <div className="form-row">
              <div className="input-group">
                <label htmlFor="password">Password *</label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="Choose a password"
                />
              </div>

              <div className="input-group">
                <label htmlFor="confirmPassword">Confirm Password *</label>
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  placeholder="Confirm your password"
                />
              </div>
            </div>

            <div className="alert alert-info" style={{ fontSize: '12px', padding: '8px' }}>
              Note: Demo admin code is "ADMIN2024"
            </div>

            <div className="form-actions">
              <button type="submit" className="btn btn-primary btn-full">
                Register as Admin
              </button>
              <button type="button" className="btn btn-secondary btn-full" onClick={() => onNavigate('login')}>
                Already have an account? Login
              </button>
            </div>
          </form>

          <div className="registration-footer">
            <button className="link-btn" onClick={() => onNavigate('landing')}>
              Back to Home
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
