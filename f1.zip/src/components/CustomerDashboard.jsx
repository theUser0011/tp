import { useState } from 'react';
import PaymentPage from './PaymentPage';
import '../styles/Dashboard.css';

export default function CustomerDashboard({ 
  user, 
  bills, 
  complaints, 
  onLogout, 
  onPayBill, 
  onRegisterComplaint,
  onUpdateCustomer,
  onToggleActivation
}) {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [complaintForm, setComplaintForm] = useState({ 
    complaintType: '', 
    category: '', 
    customerId: user.id, 
    billId: '', 
    description: '' 
  });
  const [selectedBill, setSelectedBill] = useState(null);
  const [profileForm, setProfileForm] = useState({ ...user });
  const [searchQuery, setSearchQuery] = useState('');
  const [message, setMessage] = useState({ type: '', text: '' });

  const showMessage = (type, text) => {
    setMessage({ type, text });
    setTimeout(() => setMessage({ type: '', text: '' }), 3000);
  };

  const handlePayBill = (billId) => {
    onPayBill(billId);
    setSelectedBill(null);
    showMessage('success', 'Payment successful!');
  };

  const handleComplaintSubmit = (e) => {
    e.preventDefault();
    if (!complaintForm.complaintType || !complaintForm.category || !complaintForm.billId) {
      showMessage('error', 'Please fill in all required fields');
      return;
    }
    onRegisterComplaint(complaintForm);
    setComplaintForm({ 
      complaintType: '', 
      category: '', 
      customerId: user.id, 
      billId: '', 
      description: '' 
    });
    showMessage('success', 'Complaint registered successfully!');
  };

  const handleProfileUpdate = (e) => {
    e.preventDefault();
    onUpdateCustomer(profileForm);
    showMessage('success', 'Profile updated successfully!');
  };

  const handleToggleActivation = () => {
    onToggleActivation();
    showMessage('success', user.isActive ? 'Account deactivated' : 'Account activated');
  };

  const unpaidBills = bills.filter(b => b.status === 'unpaid');
  const paidBills = bills.filter(b => b.status === 'paid');
  const filteredComplaints = complaints.filter(c => 
    (c.subject && c.subject.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (c.complaintType && c.complaintType.toLowerCase().includes(searchQuery.toLowerCase())) ||
    c.complaintNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const renderDashboard = () => (
    <div className="dashboard-content">
      <h2>Welcome, {user.name}!</h2>
      <p>Manage your electricity bills and account</p>
      
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon">💳</div>
          <div className="stat-info">
            <div className="stat-value">{unpaidBills.length}</div>
            <div className="stat-label">Pending Bills</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">✅</div>
          <div className="stat-info">
            <div className="stat-value">{paidBills.length}</div>
            <div className="stat-label">Paid Bills</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">📝</div>
          <div className="stat-info">
            <div className="stat-value">{complaints.length}</div>
            <div className="stat-label">Total Complaints</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">⚡</div>
          <div className="stat-info">
            <div className="stat-value">{user.meterNumber || 'N/A'}</div>
            <div className="stat-label">Meter Number</div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderViewBills = () => (
    <div className="dashboard-content">
      <h2>View Bills</h2>
      {unpaidBills.length === 0 ? (
        <div className="empty-state">No pending bills</div>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>Bill Number</th>
              <th>Month</th>
              <th>Units Consumed</th>
              <th>Amount</th>
              <th>Due Date</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {unpaidBills.map(bill => (
              <tr key={bill.id}>
                <td>{bill.billNumber}</td>
                <td>{bill.month}</td>
                <td>{bill.unitsConsumed} kWh</td>
                <td>${bill.amount}</td>
                <td>{bill.dueDate}</td>
                <td>
                  <span className="badge badge-warning">{bill.status}</span>
                </td>
                <td>
                  <button className="btn btn-success" onClick={() => setSelectedBill(bill)}>
                    Pay Now
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );

  const renderBillHistory = () => (
    <div className="dashboard-content">
      <h2>Bill History</h2>
      {bills.length === 0 ? (
        <div className="empty-state">No bill history</div>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>Bill Number</th>
              <th>Month</th>
              <th>Units Consumed</th>
              <th>Amount</th>
              <th>Due Date</th>
              <th>Status</th>
              <th>Paid Date</th>
            </tr>
          </thead>
          <tbody>
            {bills.map(bill => (
              <tr key={bill.id}>
                <td>{bill.billNumber}</td>
                <td>{bill.month}</td>
                <td>{bill.unitsConsumed} kWh</td>
                <td>${bill.amount}</td>
                <td>{bill.dueDate}</td>
                <td>
                  <span className={`badge ${bill.status === 'paid' ? 'badge-success' : 'badge-warning'}`}>
                    {bill.status}
                  </span>
                </td>
                <td>{bill.paidDate || '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );

  const renderRegisterComplaint = () => (
    <div className="dashboard-content">
      <h2>Register Complaint</h2>
      <div className="card" style={{ maxWidth: '600px' }}>
        <form onSubmit={handleComplaintSubmit}>
          <div className="input-group">
            <label htmlFor="complaintType">Complaint Type *</label>
            <select
              id="complaintType"
              value={complaintForm.complaintType}
              onChange={(e) => setComplaintForm({ ...complaintForm, complaintType: e.target.value })}
              required
            >
              <option value="">Select complaint type</option>
              <option value="billing">Billing Issue</option>
              <option value="meter">Meter Problem</option>
              <option value="power">Power Outage</option>
              <option value="service">Service Request</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div className="input-group">
            <label htmlFor="category">Category *</label>
            <select
              id="category"
              value={complaintForm.category}
              onChange={(e) => setComplaintForm({ ...complaintForm, category: e.target.value })}
              required
            >
              <option value="">Select category</option>
              <option value="urgent">Urgent</option>
              <option value="high">High Priority</option>
              <option value="medium">Medium Priority</option>
              <option value="low">Low Priority</option>
            </select>
          </div>
          <div className="input-group">
            <label htmlFor="customerId">Customer ID</label>
            <input
              type="text"
              id="customerId"
              value={user.id}
              disabled
            />
          </div>
          <div className="input-group">
            <label htmlFor="billId">Bill ID *</label>
            <select
              id="billId"
              value={complaintForm.billId}
              onChange={(e) => setComplaintForm({ ...complaintForm, billId: e.target.value })}
              required
            >
              <option value="">Select bill</option>
              {bills.map(bill => (
                <option key={bill.id} value={bill.id}>
                  {bill.billNumber} - {bill.month}
                </option>
              ))}
            </select>
          </div>
          <div className="input-group">
            <label htmlFor="description">Description (Optional)</label>
            <textarea
              id="description"
              value={complaintForm.description}
              onChange={(e) => setComplaintForm({ ...complaintForm, description: e.target.value })}
              placeholder="Describe your complaint (optional)"
              rows="5"
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Submit Complaint
          </button>
        </form>
      </div>
    </div>
  );

  const renderSearchComplaint = () => (
    <div className="dashboard-content">
      <h2>Search Complaints</h2>
      <div className="input-group" style={{ maxWidth: '400px', marginBottom: '20px' }}>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by subject or complaint number"
        />
      </div>
      {filteredComplaints.length === 0 ? (
        <div className="empty-state">No complaints found</div>
      ) : (
        <div className="complaints-grid">
          {filteredComplaints.map(complaint => (
            <div key={complaint.id} className="card">
              <div className="complaint-header">
                <h3>{complaint.complaintNumber}</h3>
                <span className={`badge ${complaint.status === 'pending' ? 'badge-warning' : complaint.status === 'resolved' ? 'badge-success' : 'badge-info'}`}>
                  {complaint.status}
                </span>
              </div>
              {complaint.complaintType && (
                <div style={{ marginBottom: '10px' }}>
                  <strong>Type:</strong> {complaint.complaintType} | <strong>Category:</strong> {complaint.category}
                </div>
              )}
              {complaint.subject && <h4>{complaint.subject}</h4>}
              {complaint.description && <p>{complaint.description}</p>}
              <div className="complaint-footer">
                <span>Date: {complaint.date}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const renderComplaintHistory = () => (
    <div className="dashboard-content">
      <h2>Complaint History</h2>
      {complaints.length === 0 ? (
        <div className="empty-state">No complaints registered</div>
      ) : (
        <div className="complaints-grid">
          {complaints.map(complaint => (
            <div key={complaint.id} className="card">
              <div className="complaint-header">
                <h3>{complaint.complaintNumber}</h3>
                <span className={`badge ${complaint.status === 'pending' ? 'badge-warning' : complaint.status === 'resolved' ? 'badge-success' : 'badge-info'}`}>
                  {complaint.status}
                </span>
              </div>
              {complaint.complaintType && (
                <div style={{ marginBottom: '10px' }}>
                  <strong>Type:</strong> {complaint.complaintType} | <strong>Category:</strong> {complaint.category}
                </div>
              )}
              {complaint.subject && <h4>{complaint.subject}</h4>}
              {complaint.description && <p>{complaint.description}</p>}
              <div className="complaint-footer">
                <span>Date: {complaint.date}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const renderUpdateProfile = () => (
    <div className="dashboard-content">
      <h2>Update Profile</h2>
      <div className="card" style={{ maxWidth: '600px' }}>
        <form onSubmit={handleProfileUpdate}>
          <div className="input-group">
            <label htmlFor="name">Full Name</label>
            <input
              type="text"
              id="name"
              value={profileForm.name}
              onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
            />
          </div>
          <div className="input-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              value={profileForm.email}
              onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
            />
          </div>
          <div className="input-group">
            <label htmlFor="phone">Phone</label>
            <input
              type="tel"
              id="phone"
              value={profileForm.phone}
              onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
            />
          </div>
          <div className="input-group">
            <label htmlFor="address">Address</label>
            <textarea
              id="address"
              value={profileForm.address}
              onChange={(e) => setProfileForm({ ...profileForm, address: e.target.value })}
              rows="3"
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Update Profile
          </button>
        </form>
      </div>
    </div>
  );

  const renderAccountStatus = () => (
    <div className="dashboard-content">
      <h2>Account Status</h2>
      <div className="card" style={{ maxWidth: '600px' }}>
        <div className="account-status-info">
          <div className="status-row">
            <span>Current Status:</span>
            <span className={`badge ${user.isActive ? 'badge-success' : 'badge-danger'}`}>
              {user.isActive ? 'Active' : 'Deactivated'}
            </span>
          </div>
          <div className="status-row">
            <span>Username:</span>
            <span>{user.username}</span>
          </div>
          <div className="status-row">
            <span>Email:</span>
            <span>{user.email}</span>
          </div>
        </div>
        <div style={{ marginTop: '20px' }}>
          <button 
            className={`btn ${user.isActive ? 'btn-danger' : 'btn-success'} btn-full`}
            onClick={handleToggleActivation}
          >
            {user.isActive ? 'Deactivate Account' : 'Activate Account'}
          </button>
          <p style={{ marginTop: '10px', fontSize: '12px', color: '#6b7280' }}>
            {user.isActive 
              ? 'Deactivating your account will prevent you from logging in until reactivated.'
              : 'Activating your account will allow you to access all features.'}
          </p>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return renderDashboard();
      case 'view-bills':
        return renderViewBills();
      case 'bill-history':
        return renderBillHistory();
      case 'register-complaint':
        return renderRegisterComplaint();
      case 'search-complaint':
        return renderSearchComplaint();
      case 'complaint-history':
        return renderComplaintHistory();
      case 'update-profile':
        return renderUpdateProfile();
      case 'account-status':
        return renderAccountStatus();
      default:
        return renderDashboard();
    }
  };

  return (
    <div className="dashboard-layout">
      <aside className="sidebar">
        <div className="sidebar-header">
          <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
            <path d="M22 3L12 18H20L18 35L30 18H22L24 3Z" fill="#38bdf8" stroke="#0ea5e9" strokeWidth="2" strokeLinejoin="round"/>
          </svg>
          <span>PowerBill Pro</span>
        </div>

        <nav className="sidebar-nav">
          <button
            className={`nav-item ${activeSection === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveSection('dashboard')}
          >
            <span className="nav-icon">🏠</span>
            <span>Dashboard</span>
          </button>
          <button
            className={`nav-item ${activeSection === 'view-bills' ? 'active' : ''}`}
            onClick={() => setActiveSection('view-bills')}
          >
            <span className="nav-icon">📊</span>
            <span>View Bills</span>
          </button>
          <button
            className={`nav-item ${activeSection === 'bill-history' ? 'active' : ''}`}
            onClick={() => setActiveSection('bill-history')}
          >
            <span className="nav-icon">📈</span>
            <span>Bill History</span>
          </button>
          <button
            className={`nav-item ${activeSection === 'register-complaint' ? 'active' : ''}`}
            onClick={() => setActiveSection('register-complaint')}
          >
            <span className="nav-icon">📝</span>
            <span>Register Complaint</span>
          </button>
          <button
            className={`nav-item ${activeSection === 'search-complaint' ? 'active' : ''}`}
            onClick={() => setActiveSection('search-complaint')}
          >
            <span className="nav-icon">🔍</span>
            <span>Search Complaint</span>
          </button>
          <button
            className={`nav-item ${activeSection === 'complaint-history' ? 'active' : ''}`}
            onClick={() => setActiveSection('complaint-history')}
          >
            <span className="nav-icon">📋</span>
            <span>Complaint History</span>
          </button>
          <button
            className={`nav-item ${activeSection === 'update-profile' ? 'active' : ''}`}
            onClick={() => setActiveSection('update-profile')}
          >
            <span className="nav-icon">👤</span>
            <span>Update Profile</span>
          </button>
          <button
            className={`nav-item ${activeSection === 'account-status' ? 'active' : ''}`}
            onClick={() => setActiveSection('account-status')}
          >
            <span className="nav-icon">⚙️</span>
            <span>Account Status</span>
          </button>
        </nav>

        <div className="sidebar-footer">
          <button className="btn btn-danger btn-full" onClick={onLogout}>
            Logout
          </button>
        </div>
      </aside>

      <main className="dashboard-main">
        <div className="dashboard-header">
          <h1>Customer Portal</h1>
          <div className="user-info">
            <span>{user.name}</span>
            <span className={`badge ${user.isActive ? 'badge-success' : 'badge-danger'}`}>
              {user.isActive ? 'Active' : 'Inactive'}
            </span>
          </div>
        </div>

        {message.text && (
          <div className={`alert alert-${message.type}`}>
            {message.text}
          </div>
        )}

        {renderContent()}
      </main>

      {selectedBill && (
        <PaymentPage
          bill={selectedBill}
          user={user}
          onPaymentComplete={handlePayBill}
          onCancel={() => setSelectedBill(null)}
        />
      )}
    </div>
  );
}
