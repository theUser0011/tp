import '../styles/LandingPage.css';

export default function LandingPage({ onNavigate }) {
  return (
    <div className="landing-page">
      <header className="landing-header">
        <div className="container">
          <div className="logo">
            <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
              <path d="M22 3L12 18H20L18 35L30 18H22L24 3Z" fill="#38bdf8" stroke="#0ea5e9" strokeWidth="2" strokeLinejoin="round"/>
            </svg>
            <span>PowerBill Pro</span>
          </div>
          <nav>
            <button className="btn btn-secondary" onClick={() => onNavigate('login')}>Login</button>
          </nav>
        </div>
      </header>

      <section className="hero">
        <div className="container">
          <h1>Manage Your Electricity Bills with Ease</h1>
          <p>View bills, make payments, and track your electricity usage all in one place</p>
          <div className="cta-buttons">
            <button className="btn btn-primary btn-large" onClick={() => onNavigate('customer-registration')}>
              Register as Customer
            </button>
          </div>
        </div>
      </section>

      <section className="features">
        <div className="container">
          <h2>Features</h2>
          <div className="feature-grid">
            <div className="feature-card">
              <div className="feature-icon">📊</div>
              <h3>View Bills</h3>
              <p>Access your current and past electricity bills anytime</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">💳</div>
              <h3>Easy Payments</h3>
              <p>Pay your bills securely with just a few clicks</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">📝</div>
              <h3>Register Complaints</h3>
              <p>Submit and track your service complaints</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">📈</div>
              <h3>Usage History</h3>
              <p>Monitor your electricity consumption over time</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">🔧</div>
              <h3>Update Profile</h3>
              <p>Keep your account information up to date</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">⚙️</div>
              <h3>Account Control</h3>
              <p>Activate or deactivate your account as needed</p>
            </div>
          </div>
        </div>
      </section>

      <footer className="landing-footer">
        <div className="container">
          <p>&copy; 2024 PowerBill Pro. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
