import { useState } from 'react';
import { 
  Shield, 
  Users, 
  UserPlus, 
  UserMinus, 
  Activity, 
  LogOut,
  Crown,
  CheckCircle,
  XCircle,
  Edit,
  Trash2,
  Settings,
  Home,
  BarChart3,
  User
} from 'lucide-react';
import './SuperAdminDashboard.css';

export function SuperAdminDashboard({ onLogout, currentUser }) {
  const [activeSection, setActiveSection] = useState('overview');
  const [showAddUserForm, setShowAddUserForm] = useState(false);
  const [newUserData, setNewUserData] = useState({
    name: '',
    email: '',
    role: 'admin'
  });

  // Mock data
  const [stats] = useState({
    totalAdmins: 245,
    activeAdmins: 189,
    inactiveAdmins: 56,
    superAdmins: 3,
    totalScans: 5427,
    todayScans: 89
  });

  const [adminUsers, setAdminUsers] = useState([
    {
      id: '1',
      name: 'John Smith',
      email: 'john.smith@vulnsense.ai',
      role: 'admin',
      status: 'active',
      lastLogin: '2024-01-15T14:30:00Z',
      createdAt: '2024-01-01T00:00:00Z',
      scansCount: 156
    },
    {
      id: '2',
      name: 'Sarah Johnson',
      email: 'sarah.johnson@vulnsense.ai',
      role: 'admin',
      status: 'active',
      lastLogin: '2024-01-15T12:15:00Z',
      createdAt: '2023-12-15T00:00:00Z',
      scansCount: 203
    },
    {
      id: '3',
      name: 'Mike Wilson',
      email: 'mike.wilson@vulnsense.ai',
      role: 'admin',
      status: 'inactive',
      lastLogin: '2024-01-10T16:45:00Z',
      createdAt: '2023-11-20T00:00:00Z',
      scansCount: 87
    }
  ]);

  // Sidebar items for SuperAdmin
  const sidebarItems = [
    { id: 'overview', icon: Home, label: 'Overview' },
    { id: 'admins', icon: Users, label: 'Admin Management' },
    { id: 'activity', icon: BarChart3, label: 'System Activity' }
  ];

  const handleAddUser = () => {
    if (!newUserData.name || !newUserData.email) return;

    const newUser = {
      id: Date.now().toString(),
      name: newUserData.name,
      email: newUserData.email,
      role: newUserData.role,
      status: 'active',
      lastLogin: 'Never',
      createdAt: new Date().toISOString(),
      scansCount: 0
    };

    setAdminUsers([...adminUsers, newUser]);
    setNewUserData({ name: '', email: '', role: 'admin' });
    setShowAddUserForm(false);
  };

  const handleToggleUserStatus = (userId) => {
    setAdminUsers(adminUsers.map(user => 
      user.id === userId 
        ? { ...user, status: user.status === 'active' ? 'inactive' : 'active' }
        : user
    ));
  };

  const handleDeleteUser = (userId) => {
    setAdminUsers(adminUsers.filter(user => user.id !== userId));
  };

  const getStatusBadge = (status) => {
    return status === 'active' ? (
      <span className="badge badge-success">Active</span>
    ) : (
      <span className="badge badge-danger">Inactive</span>
    );
  };

  const getRoleBadge = (role) => {
    return role === 'superAdmin' ? (
      <span className="badge badge-purple">Super Admin</span>
    ) : (
      <span className="badge badge-primary">Admin</span>
    );
  };

  const renderContent = () => {
    switch (activeSection) {
      case 'overview':
        return (

          <div className="admin-content">
            <div className="section-header">
              <div>
                <h2>System Overview</h2>
                <p>Monitor administrators and system-wide security operations</p>
              </div>
            </div>

            <div className="stats-grid">
                {/* Total Admins */}
                <div className="stat-card">
                  <div className="stat-header">
                    <span className="stat-title">Total Admins</span>
                    <Shield className="stat-icon" />
                  </div>
                  <div className="stat-content">
                    <div className="stat-number">{stats.totalAdmins}</div>
                    <p className="stat-description">+12 from last month</p>
                  </div>
                </div>

                {/* Active Admins */}
                <div className="stat-card">
                  <div className="stat-header">
                    <span className="stat-title">Active Admins</span>
                    <Activity className="stat-icon" />
                  </div>
                  <div className="stat-content">
                    <div className="stat-number">{stats.activeAdmins}</div>
                    <p className="stat-description">{Math.round((stats.activeAdmins / stats.totalAdmins) * 100)}% active rate</p>
                  </div>
                </div>

                {/* Super Admins */}
                <div className="stat-card">
                  <div className="stat-header">
                    <span className="stat-title">Super Admins</span>
                    <Crown className="stat-icon" />
                  </div>
                  <div className="stat-content">
                    <div className="stat-number">{stats.superAdmins}</div>
                    <p className="stat-description">System administrators</p>
                  </div>
                </div>

                {/* Today's Scans */}
                <div className="stat-card">
                  <div className="stat-header">
                    <span className="stat-title">Today's Scans</span>
                    <Activity className="stat-icon" />
                  </div>
                  <div className="stat-content">
                    <div className="stat-number">{stats.todayScans}</div>
                    <p className="stat-description">Total: {stats.totalScans.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              {/* Recent System Activity */}
              <div className="activity-card">
                <div className="card-header">
                  <h3>Recent System Activity</h3>
                  <p>Latest administrative actions and system events</p>
                </div>
                <div className="activity-list">
                  <div className="activity-item activity-success">
                    <UserPlus className="activity-icon" />
                    <div className="activity-content">
                      <p>New admin added: sarah.johnson@vulnsense.ai</p>
                      <span className="activity-time">2 hours ago</span>
                    </div>
                  </div>
                  
                  <div className="activity-item activity-info">
                    <Shield className="activity-icon" />
                    <div className="activity-content">
                      <p>Admin completed 15 vulnerability scans</p>
                      <span className="activity-time">3 hours ago</span>
                    </div>
                  </div>
                  
                  <div className="activity-item activity-warning">
                    <Activity className="activity-icon" />
                    <div className="activity-content">
                      <p>System processed 89 scans today from active admins</p>
                      <span className="activity-time">5 hours ago</span>
                    </div>
                  </div>
                  
                  <div className="activity-item activity-danger">
                    <UserMinus className="activity-icon" />
                    <div className="activity-content">
                      <p>Admin deactivated: mike.wilson@vulnsense.ai</p>
                      <span className="activity-time">1 day ago</span>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        );

      case 'admins':
        return (
          <div className="admin-content">
            {/* Add New Admin Button */}
              <div className="section-header">
                <div>
                  <h3>Admin Users</h3>
                  <p>Manage administrator accounts and permissions</p>
                </div>
                <button
                  onClick={() => setShowAddUserForm(!showAddUserForm)}
                  className="btn btn-primary"
                >
                  <UserPlus className="btn-icon" />
                  Add Admin
                </button>
              </div>

              {/* Add User Form */}
              {showAddUserForm && (
                <div className="add-user-card">
                  <div className="card-header">
                    <h3>Add New Administrator</h3>
                  </div>
                  <div className="add-user-form">
                    <div className="form-grid">
                      <div className="form-group">
                        <label htmlFor="name">Full Name</label>
                        <input
                          id="name"
                          type="text"
                          value={newUserData.name}
                          onChange={(e) => setNewUserData({ ...newUserData, name: e.target.value })}
                          placeholder="Enter full name"
                          className="form-input"
                        />
                      </div>
                      <div className="form-group">
                        <label htmlFor="email">Email Address</label>
                        <input
                          id="email"
                          type="email"
                          value={newUserData.email}
                          onChange={(e) => setNewUserData({ ...newUserData, email: e.target.value })}
                          placeholder="Enter email address"
                          className="form-input"
                        />
                      </div>
                    </div>
                    <div className="form-group">
                      <label htmlFor="role">Role</label>
                      <select 
                        id="role"
                        value={newUserData.role} 
                        onChange={(e) => setNewUserData({ ...newUserData, role: e.target.value })}
                        className="form-select"
                      >
                        <option value="admin">Administrator</option>
                        <option value="superAdmin">Super Administrator</option>
                      </select>
                    </div>
                    <div className="form-buttons">
                      <button onClick={handleAddUser} className="btn btn-primary">
                        Add Administrator
                      </button>
                      <button onClick={() => setShowAddUserForm(false)} className="btn btn-outline">
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Admin Users List */}
              <div className="users-list">
                {adminUsers.map((user) => (
                  <div key={user.id} className="user-card">
                    <div className="user-content">
                      <div className="user-info">
                        <div className="user-avatar">
                          <Users className="avatar-icon" />
                        </div>
                        <div className="user-details">
                          <h4>{user.name}</h4>
                          <p>{user.email}</p>
                          <div className="user-badges">
                            {getRoleBadge(user.role)}
                            {getStatusBadge(user.status)}
                          </div>
                        </div>
                      </div>
                      
                      <div className="user-meta">
                        <div className="user-stats">
                          <p>Last login: {user.lastLogin === 'Never' ? 'Never' : new Date(user.lastLogin).toLocaleDateString()}</p>
                          <p>Scans: {user.scansCount}</p>
                        </div>
                        
                        <div className="user-actions">
                          <button
                            onClick={() => handleToggleUserStatus(user.id)}
                            className={`btn btn-outline btn-sm ${user.status === 'active' ? 'btn-danger' : 'btn-success'}`}
                          >
                            {user.status === 'active' ? (
                              <>
                                <XCircle className="btn-icon" />
                                Deactivate
                              </>
                            ) : (
                              <>
                                <CheckCircle className="btn-icon" />
                                Activate
                              </>
                            )}
                          </button>
                          
                          <button
                            onClick={() => handleDeleteUser(user.id)}
                            className="btn btn-outline btn-sm btn-danger"
                          >
                            <Trash2 className="btn-icon" />
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
          </div>
        );

      case 'activity':
        return (
          <div className="admin-content">
            <div className="section-header">
              <div>
                <h2>System Activity Monitor</h2>
                <p>Real-time monitoring of system-wide activities and performance</p>
              </div>
            </div>

            <div className="activity-monitor-card">
                <div className="card-header">
                  <h3>System Activity Monitor</h3>
                  <p>Real-time monitoring of system-wide activities</p>
                </div>
                <div className="monitor-content">
                  <div className="monitor-stats">
                    <div className="monitor-stat monitor-stat-blue">
                      <div className="monitor-number">{stats.todayScans}</div>
                      <div className="monitor-label">Scans Today</div>
                    </div>
                    <div className="monitor-stat monitor-stat-green">
                      <div className="monitor-number">{stats.activeAdmins}</div>
                      <div className="monitor-label">Active Admins</div>
                    </div>
                    <div className="monitor-stat monitor-stat-purple">
                      <div className="monitor-number">{stats.superAdmins}</div>
                      <div className="monitor-label">Super Admins</div>
                    </div>
                  </div>
                  
                  <div className="activity-log">
                    <h4>Recent Activity Log</h4>
                    <div className="log-entries">
                      <div className="log-entry">
                        <span>Admin scan completed: https://example.com</span>
                        <span className="log-time">2 min ago</span>
                      </div>
                      <div className="log-entry">
                        <span>Admin login: john.smith@vulnsense.ai</span>
                        <span className="log-time">15 min ago</span>
                      </div>
                      <div className="log-entry">
                        <span>Critical vulnerability escalated for admin review</span>
                        <span className="log-time">23 min ago</span>
                      </div>
                      <div className="log-entry">
                        <span>AI auto-resolved SQL injection vulnerability</span>
                        <span className="log-time">1 hour ago</span>
                      </div>
                      <div className="log-entry">
                        <span>New admin account created: sarah.johnson@vulnsense.ai</span>
                        <span className="log-time">2 hours ago</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="superadmin-dashboard">
      {/* Sidebar */}
      <div className="sidebar">
        {/* Logo */}
        <div className="sidebar-header">
          <div className="logo">
            <div className="logo-icon">
              <Shield className="icon" />
            </div>
            <div className="logo-text">
              <h1>VulnSense AI</h1>
              <p>Super Admin</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="sidebar-nav">
          <ul className="nav-list">
            {sidebarItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => setActiveSection(item.id)}
                  className={`nav-item ${activeSection === item.id ? 'nav-item-active' : ''}`}
                >
                  <item.icon className="nav-icon" />
                  <span className="nav-label">{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* User Info & Logout - Fixed at bottom */}
        <div className="sidebar-footer">
          <div className="user-info">
            <div className="user-avatar">
              <User className="icon" />
            </div>
            <div className="user-details">
              <p className="user-name">{currentUser.name}</p>
              <p className="user-email">{currentUser.email}</p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="logout-btn"
          >
            <LogOut className="btn-icon" />
            Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content">
        {/* Header */}
        <header className="content-header">
          <div className="header-info">
            <h2 className="section-title">{activeSection}</h2>
            <p className="section-subtitle">System administration panel</p>
          </div>
          <div className="header-user">
            <div className="user-avatar">
              <User className="icon" />
            </div>
            <div className="user-details">
              <p className="user-name">{currentUser.name}</p>
              <p className="user-role">Super Administrator</p>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="page-content">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}