import { useState } from 'react';
import '../styles/LoginPage.css';

export default function LoginPage({ onLogin, onNavigate }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    if (!username || !password) {
      setError('Please enter both username and password');
      return;
    }

    const result = onLogin(username, password);
    if (!result.success) {
      setError(result.message);
    }
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <div className="login-card">
          <div className="login-header">
            <svg width="60" height="60" viewBox="0 0 40 40" fill="none">
              <path d="M22 3L12 18H20L18 35L30 18H22L24 3Z" fill="#38bdf8" stroke="#0ea5e9" strokeWidth="2" strokeLinejoin="round"/>
            </svg>
            <h1>PowerBill Pro</h1>
            <p>Login to your account</p>
          </div>

          {error && (
            <div className="alert alert-error">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="input-group">
              <label htmlFor="username">Username</label>
              <input
                type="text"
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
              />
            </div>

            <div className="input-group">
              <label htmlFor="password">Password</label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
              />
            </div>

            <button type="submit" className="btn btn-primary btn-full">
              Submit
            </button>
          </form>

          <div className="login-footer">
            <p>Don't have an account?</p>
            <div className="register-links">
              <button className="link-btn" onClick={() => onNavigate('customer-registration')}>
                Register as Customer
              </button>
            </div>
            <button className="link-btn" onClick={() => onNavigate('landing')}>
              Back to Home
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
