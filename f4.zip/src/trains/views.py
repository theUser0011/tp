import logging
import traceback
from rest_framework import generics, status, serializers
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, BasePermission
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django.contrib.auth.models import User
from .models import Train
from .serializers import TrainSerializer

# ------------------------------------------------------------------
# LOGGING CONFIGURATION
# ------------------------------------------------------------------
import os
LOG_DIR = os.path.join(os.path.dirname(__file__), "logs")
os.makedirs(LOG_DIR, exist_ok=True)

LOG_FILE = os.path.join(LOG_DIR, "app.log")

logging.basicConfig(
    level=logging.DEBUG,
    format="[%(asctime)s] [%(levelname)s] [%(filename)s:%(lineno)d] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8"),
        logging.StreamHandler(),  # also print to console
    ],
)
logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Custom permission – works with JWT
# ------------------------------------------------------------------
class IsAdminUser(BasePermission):
    def has_permission(self, request, view):
        allowed = request.user.is_authenticated and request.user.is_staff
        if not allowed:
            logger.warning(
                f"Unauthorized access attempt by user={request.user} at view={view.__class__.__name__}"
            )
        return allowed


# ------------------------------------------------------------------
#  TRAIN CRUD – WITH LOGGING + ERROR HANDLING
# ------------------------------------------------------------------
# This module defines two main class-based API views:
#   1. TrainListCreateView → For listing and creating trains
#   2. TrainDetailView → For retrieving, updating, and deleting a specific train
#
# Both use Django REST Framework's generic views and include:
#   - Logging for every key action
#   - Error handling with tracebacks
#   - Admin-only access control
# ------------------------------------------------------------------

from rest_framework import generics, status, serializers
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response
import traceback
import logging

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
#  LIST + CREATE TRAINS (GET, POST)
# ------------------------------------------------------------------
class TrainListCreateView(generics.ListCreateAPIView):
    """
    Handles:
      ➤ GET  → Fetch list of all trains
      ➤ POST → Create a new train record
    """

    queryset = Train.objects.all()                     # Fetch all Train records
    serializer_class = TrainSerializer                 # Use TrainSerializer for validation & formatting
    permission_classes = [IsAuthenticated, IsAdminUser]  # Only authenticated admins allowed

    # --------------------------------------------------------------
    # When a new train is created (POST request)
    # --------------------------------------------------------------
    def perform_create(self, serializer):
        try:
            # Save the new train object to the database
            serializer.save()
            logger.info(" Train created successfully.")
        except Exception as e:
            # Capture and log detailed traceback for debugging
            tb = traceback.format_exc()
            logger.error(f"Error while creating Train: {e}\n{tb}")

            # Return a readable error response to the client
            raise serializers.ValidationError(
                {"detail": f"Error while creating Train: {str(e)}"}
            )

    # --------------------------------------------------------------
    # When fetching list of trains (GET request)
    # --------------------------------------------------------------
    def list(self, request, *args, **kwargs):
        try:
            # Log who requested the train list
            logger.debug(f"Fetching train list requested by {request.user}")
            return super().list(request, *args, **kwargs)  # Default DRF logic (returns serialized data)
        except Exception as e:
            tb = traceback.format_exc()
            logger.error(f"Error listing trains: {e}\n{tb}")

            # Return JSON error message to the frontend
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


# ------------------------------------------------------------------
#  TRAIN DETAIL VIEW (GET, PUT, PATCH, DELETE)
# ------------------------------------------------------------------
class TrainDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    Handles:
      ➤ GET    → Retrieve details of a specific train (by ID)
      ➤ PUT    → Update the entire train record
      ➤ PATCH  → Update part of the train record
      ➤ DELETE → Delete a train
    """

    queryset = Train.objects.all()
    serializer_class = TrainSerializer
    permission_classes = [IsAuthenticated, IsAdminUser]  # Only admin can modify/delete trains

    # --------------------------------------------------------------
    # When deleting a train (DELETE request)
    # --------------------------------------------------------------
    def destroy(self, request, *args, **kwargs):
        try:
            # Get the train object from the database using the <pk> from the URL
            instance = self.get_object()
            train_num = instance.train_number  # Store for logging before deletion

            # Delete the record
            self.perform_destroy(instance)

            logger.info(f" Train {train_num} deleted successfully.")

            # Respond to client confirming successful deletion
            return Response(
                {"message": f"Train {train_num} deleted successfully."},
                status=status.HTTP_200_OK,
            )
        except Exception as e:
            # Log unexpected errors with traceback
            tb = traceback.format_exc()
            logger.error(f"Error deleting train: {e}\n{tb}")

            # Send JSON error back to frontend
            return Response(
                {"error": f"Error deleting train: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


# ------------------------------------------------------------------
# CUSTOM JWT LOGIN (accepts username or email as identifier)
# ------------------------------------------------------------------
# This serializer extends the default TokenObtainPairSerializer from
# Django REST Framework SimpleJWT to allow users to log in using either
# their username OR their email address.
#
# Flow summary:
# 1. Extract the identifier (username or email) and password from request.
# 2. Try to find the matching user in the database.
# 3. Verify the user's password using Django's built-in secure hash check.
# 4. If valid → issue JWT tokens via parent class.
# 5. If invalid → raise appropriate validation errors.
# ------------------------------------------------------------------

class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        # Extract the identifier (can be username or email) and password from request data
        identifier = attrs.get("username")
        password = attrs.get("password")

        try:
            # ---------------------------------------------------------------
            # Step 1: Attempt to find the user by username or, if not found, by email.
            # ---------------------------------------------------------------
            user = None
            try:
                user = User.objects.get(username=identifier)
            except User.DoesNotExist:
                # If no user found by username, try finding by email
                user = User.objects.get(email=identifier)

            # ---------------------------------------------------------------
            # Step 2: Verify the provided password.
            # ---------------------------------------------------------------
            # Django stores passwords in a hashed form. The method below:
            #   - Takes the raw password entered by the user
            #   - Hashes it using the same salt and algorithm as the stored one
            #   - Compares both hashes securely (constant-time comparison)
            #
            # Returns True if the password matches, otherwise False.
            # ---------------------------------------------------------------
            if not user.check_password(password):
                logger.warning(f" Incorrect password attempt for user={identifier}")
                raise serializers.ValidationError({"detail": "Incorrect password"})

            # ---------------------------------------------------------------
            # Step 3: Password verified successfully.
            #         Now call the parent class’s validate() method.
            # ---------------------------------------------------------------
            # This step revalidates credentials (for consistency) and
            # issues a new JWT access + refresh token pair for the user.
            # ---------------------------------------------------------------
            data = super().validate({"username": user.username, "password": password})

            logger.info(f" Token issued successfully for user={user.username}")
            return data

        except User.DoesNotExist:
            # ---------------------------------------------------------------
            # Triggered when neither username nor email matches any record.
            # ---------------------------------------------------------------
            logger.error(f" Invalid login identifier: {identifier}")
            raise serializers.ValidationError({"detail": "Invalid username or email"})

        except Exception as e:
            # ---------------------------------------------------------------
            # Handles any unexpected errors (e.g., DB connection issue).
            # Includes traceback logging for debugging in development.
            # ---------------------------------------------------------------
            tb = traceback.format_exc()
            logger.error(f"- Unexpected error in login: {e}\n{tb}")
            raise serializers.ValidationError({"detail": f"Unexpected error: {str(e)}"})


# ------------------------------------------------------------------
# CUSTOM VIEW CLASS
# ------------------------------------------------------------------
# The view below binds our custom serializer to the /api/token/ endpoint.
# When a POST request is made to /api/token/, DRF automatically:
#   1. Initializes the serializer with request data.
#   2. Calls serializer.is_valid() → which internally calls validate().
#   3. Returns the JWT tokens as response if successful.
# ------------------------------------------------------------------
class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer
