# trains/models.py
from django.db import models
from django.core.exceptions import ValidationError
from datetime import datetime, timedelta


class Station(models.Model):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name

class Train(models.Model):
    CLASS_CHOICES = [
        ('SL', 'Sleeper'),
        ('3A', 'AC 3 Tier'),
        ('2A', 'AC 2 Tier'),
        ('1A', 'AC First Class'),
    ]

    train_number = models.CharField(max_length=10, unique=True)
    train_name = models.CharField(max_length=100)
    origin = models.ForeignKey('Station', on_delete=models.CASCADE, related_name='trains_origin')
    destination = models.ForeignKey('Station', on_delete=models.CASCADE, related_name='trains_destination')
    intermediate_stops = models.ManyToManyField('Station', through='Stop', related_name='stopping_trains')
    departure_time = models.TimeField()  # at origin
    arrival_time = models.TimeField()    # at destination
    travel_duration = models.DurationField(null=True, blank=True)
    total_seats = models.JSONField(default=dict)  # e.g., {"SL": 100, "3A": 60, ...}

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def clean(self):
        if self.origin == self.destination:
            raise ValidationError("Origin and destination cannot be the same.")

        # Prevent schedule conflict
        conflicts = Train.objects.filter(
            origin=self.origin,
            destination=self.destination,
            departure_time=self.departure_time,
            arrival_time=self.arrival_time
        ).exclude(pk=self.pk)

        if conflicts.exists():
            raise ValidationError("Another train already runs on this schedule between these stations.")

    def save(self, *args, **kwargs):
        # ✅ Calculate travel duration before saving
        if self.departure_time and self.arrival_time:
            fmt = "%H:%M:%S"
            dep = datetime.strptime(str(self.departure_time), fmt)
            arr = datetime.strptime(str(self.arrival_time), fmt)

            # Handle next-day arrival (e.g., departure 22:00 → arrival 06:00)
            if arr < dep:
                arr += timedelta(days=1)

            self.travel_duration = arr - dep

        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.train_number} - {self.train_name}"

class Stop(models.Model):
    train = models.ForeignKey(Train, on_delete=models.CASCADE)
    station = models.ForeignKey(Station, on_delete=models.CASCADE)
    arrival_time = models.TimeField()
    departure_time = models.TimeField()
    stop_order = models.PositiveIntegerField()

    class Meta:
        unique_together = ('train', 'station')
        ordering = ['stop_order']

    def __str__(self):
        return f"{self.train} @ {self.station} ({self.arrival_time} - {self.departure_time})"