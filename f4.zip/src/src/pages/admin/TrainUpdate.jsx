import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { AdminSidebar } from '../../components/AdminSidebar';
import { Header } from '../../components/Header';
import { Train } from 'lucide-react';
import { toast } from 'react-toastify';
import api from '../../api/api'; // your axios instance

export default function TrainUpdate() {
  const { id } = useParams(); // Train ID from URL
  const navigate = useNavigate(); // ✅ Must be declared before useEffect

  const [formData, setFormData] = useState({
    trainNumber: '',
    trainName: '',
    origin: '',
    destination: '',
    departureTime: '',
    arrivalTime: '',
    duration: '',
  });

  useEffect(() => {
    const fetchTrain = async () => {
      try {
        const response = await api.get(`/trains/${id}/`); // Fetch train data

        setFormData({
          trainNumber: response.data.train_number || '',
          trainName: response.data.train_name || '',
          // ✅ Show existing station names from `origin_detail` and `destination_detail`
          origin: response.data.origin_detail?.name || '',
          destination: response.data.destination_detail?.name || '',
          departureTime: response.data.departure_time || '',
          arrivalTime: response.data.arrival_time || '',
          // ✅ Fix: Use travel_duration from backend, not duration
          duration: response.data.travel_duration || '',
        });
      } catch (error) {
        console.error('Error fetching train:', error);
        toast.error('Train not found');
        navigate('/admin/train-list');
      }
    };
    fetchTrain();
  }, [id, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        train_number: formData.trainNumber,
        train_name: formData.trainName,
        origin: { name: formData.origin },
        destination: { name: formData.destination },
        departure_time: formData.departureTime,
        arrival_time: formData.arrivalTime,
        travel_duration: formData.duration, // ✅ use correct field name for backend
      };

      await api.put(`/trains/${id}/`, payload);
      toast.success('Train updated successfully!');
      navigate('/admin/train-list');
    } catch (error) {
      console.error('Error updating train:', error.response?.data || error);
      toast.error('Failed to update train');
    }
  };

  return (
    <div className="d-flex bg-light min-vh-100">
      <AdminSidebar />
      <div className="flex-grow-1" style={{ marginLeft: '280px' }}>
        <Header title="Update Train" />

        <div className="p-4">
          <div className="card shadow-sm border-0 mx-auto" style={{ maxWidth: '800px' }}>
            <div className="card-body">
              <div className="d-flex align-items-center mb-4">
                <div className="bg-primary text-white p-3 rounded me-3">
                  <Train size={24} />
                </div>
                <div>
                  <h5 className="card-title mb-0">Update Train Information</h5>
                  <small className="text-muted">Modify train details</small>
                </div>
              </div>

              <form onSubmit={handleSubmit}>
                <div className="row g-3">
                  <div className="col-md-6">
                    <label className="form-label">Train Number</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.trainNumber}
                      onChange={(e) =>
                        setFormData({ ...formData, trainNumber: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <label className="form-label">Train Name</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.trainName}
                      onChange={(e) =>
                        setFormData({ ...formData, trainName: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <label className="form-label">Origin Station</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.origin}
                      onChange={(e) =>
                        setFormData({ ...formData, origin: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <label className="form-label">Destination Station</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.destination}
                      onChange={(e) =>
                        setFormData({ ...formData, destination: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <label className="form-label">Departure Time</label>
                    <input
                      type="time"
                      className="form-control"
                      value={formData.departureTime}
                      onChange={(e) =>
                        setFormData({ ...formData, departureTime: e.target.value })
                      }
                    />
                  </div>

                  <div className="col-md-6">
                    <label className="form-label">Arrival Time</label>
                    <input
                      type="time"
                      className="form-control"
                      value={formData.arrivalTime}
                      onChange={(e) =>
                        setFormData({ ...formData, arrivalTime: e.target.value })
                      }
                    />
                  </div>

                  <div className="col-12">
                    <label className="form-label">Duration</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.duration}
                      onChange={(e) =>
                        setFormData({ ...formData, duration: e.target.value })
                      }
                      placeholder="e.g., 11h 00m"
                    />
                  </div>
                </div>

                <div className="d-flex gap-2 mt-4">
                  <button type="submit" className="btn btn-primary flex-grow-1">
                    Save Changes
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => navigate('/admin/train-list')}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
