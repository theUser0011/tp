import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CustomerSidebar } from '../../components/CustomerSidebar';
import { Header } from '../../components/Header';
import { AlertTriangle } from 'lucide-react';
import { toast } from 'react-toastify';

function DeactivateAccount() {
  const navigate = useNavigate();
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [confirmText, setConfirmText] = useState('');

  const handleDeactivate = () => {
    if (confirmText !== 'DEACTIVATE') {
      toast.error('Please type DEACTIVATE to confirm');
      return;
    }

    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const updatedUsers = users.filter((u) => u.id !== currentUser.id);
    localStorage.setItem('users', JSON.stringify(updatedUsers));
    localStorage.removeItem('currentUser');

    toast.success('Account deactivated successfully');
    navigate('/');
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <CustomerSidebar />
      <div className="flex-1 ml-64">
        <Header title="Deactivate Account" />

        <div className="p-8">
          <div className="bg-white rounded-xl border border-red-200 p-8 max-w-2xl mx-auto">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-red-100 rounded-lg">
                <AlertTriangle className="text-red-600" size={24} />
              </div>
              <div>
                <h2 className="text-red-900 font-semibold">Deactivate Account</h2>
                <p className="text-red-600">
                  This action is permanent and cannot be undone
                </p>
              </div>
            </div>

            <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-6">
              <h3 className="text-red-900 mb-3 font-semibold">
                What happens when you deactivate:
              </h3>
              <ul className="space-y-2 text-red-700">
                <li className="flex items-start gap-2">• Your account will be permanently deleted</li>
                <li className="flex items-start gap-2">• All your booking history will be removed</li>
                <li className="flex items-start gap-2">• You will lose access to all active bookings</li>
                <li className="flex items-start gap-2">• This action cannot be reversed</li>
              </ul>
            </div>

            <div className="space-y-4">
              <p className="text-gray-700">
                If you're sure you want to proceed, click the button below to deactivate your account.
              </p>

              <button
                onClick={() => setShowConfirmDialog(true)}
                className="w-full px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                Deactivate My Account
              </button>

              <button
                onClick={() => navigate('/customer/dashboard')}
                className="w-full px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>

      {showConfirmDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-red-100 rounded-full">
                <AlertTriangle className="text-red-600" size={24} />
              </div>
              <h3 className="text-gray-900 font-semibold">Final Confirmation</h3>
            </div>
            <p className="text-gray-600 mb-4">
              This will permanently delete your account and all associated data.
            </p>
            <div className="mb-6">
              <label className="block text-gray-700 mb-2">
                Type <strong>DEACTIVATE</strong> to confirm:
              </label>
              <input
                type="text"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                placeholder="DEACTIVATE"
              />
            </div>
            <div className="flex gap-3">
              <button
                onClick={handleDeactivate}
                className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                Deactivate
              </button>
              <button
                onClick={() => {
                  setShowConfirmDialog(false);
                  setConfirmText('');
                }}
                className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default DeactivateAccount;
