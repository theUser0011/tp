import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { CustomerSidebar } from '../../components/CustomerSidebar';
import { Header } from '../../components/Header';
import { Users } from 'lucide-react';
import { toast } from 'react-toastify';

export const BookingForm = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { train, travelDate } = location.state || {};

  const [formData, setFormData] = useState({
    class: '',
    seats: 1,
    passengerName: '',
    passengerAge: '',
    passengerGender: '',
  });

  const [fare, setFare] = useState(0);

  const handleClassChange = (selectedClass) => {
    setFormData({ ...formData, class: selectedClass });

    if (train.classes[selectedClass]) {
      const basePrice = parseFloat(train.classes[selectedClass].price);
      setFare(basePrice * formData.seats);
    }
  };

  const handleSeatsChange = (seats) => {
    setFormData({ ...formData, seats });
    if (formData.class && train.classes[formData.class]) {
      const basePrice = parseFloat(train.classes[formData.class].price);
      setFare(basePrice * seats);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.class) {
      toast.error('Please select a class');
      return;
    }

    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    const booking = {
      id: Date.now(),
      userId: currentUser.id,
      bookingId: `BK${Date.now()}`,
      trainId: train.id,
      trainNumber: train.trainNumber,
      trainName: train.trainName,
      origin: train.origin,
      destination: train.destination,
      departureTime: train.departureTime,
      arrivalTime: train.arrivalTime,
      travelDate,
      class: formData.class,
      seats: formData.seats,
      passengerName: formData.passengerName,
      passengerAge: formData.passengerAge,
      passengerGender: formData.passengerGender,
      fare,
      status: 'confirmed',
      bookedAt: new Date().toISOString(),
    };

    const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
    bookings.push(booking);
    localStorage.setItem('bookings', JSON.stringify(bookings));

    toast.success('Booking confirmed successfully!');
    navigate('/customer/ticket-details', { state: { booking } });
  };

  if (!train) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <CustomerSidebar />
        <div className="flex-1 ml-64">
          <Header title="Book Ticket" />
          <div className="p-8">
            <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
              <p className="text-gray-600">No train selected. Please search for trains first.</p>
              <button
                onClick={() => navigate('/customer/search-trains')}
                className="mt-4 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Search Trains
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <CustomerSidebar />
      <div className="flex-1 ml-64">
        <Header title="Book Ticket" />
        <div className="p-8">
          <div className="max-w-4xl mx-auto">
            {/* Train Details */}
            <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
              <h2 className="mb-4">Train Details</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-gray-500">Train Name</p>
                  <p className="text-gray-900">{train.trainName}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Train Number</p>
                  <p className="text-gray-900">{train.trainNumber}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Route</p>
                  <p className="text-gray-900">{train.origin} → {train.destination}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Travel Date</p>
                  <p className="text-gray-900">{travelDate}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Departure</p>
                  <p className="text-gray-900">{train.departureTime}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Arrival</p>
                  <p className="text-gray-900">{train.arrivalTime}</p>
                </div>
              </div>
            </div>

            {/* Booking Form */}
            <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
              <h2 className="mb-6">Booking Details</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Class Selection */}
                <div>
                  <label className="block text-gray-700 mb-3">Select Class *</label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {train.classes?.sleeper?.available && (
                      <button
                        type="button"
                        onClick={() => handleClassChange('sleeper')}
                        className={`p-4 border-2 rounded-lg transition-colors ${
                          formData.class === 'sleeper'
                            ? 'border-blue-600 bg-blue-50'
                            : 'border-gray-300 hover:border-blue-300'
                        }`}
                      >
                        <p className="text-gray-900 mb-1">Sleeper</p>
                        <p className="text-blue-600">${train.classes.sleeper.price}</p>
                      </button>
                    )}
                    {train.classes?.ac3Tier?.available && (
                      <button
                        type="button"
                        onClick={() => handleClassChange('ac3Tier')}
                        className={`p-4 border-2 rounded-lg transition-colors ${
                          formData.class === 'ac3Tier'
                            ? 'border-blue-600 bg-blue-50'
                            : 'border-gray-300 hover:border-blue-300'
                        }`}
                      >
                        <p className="text-gray-900 mb-1">AC 3-Tier</p>
                        <p className="text-blue-600">${train.classes.ac3Tier.price}</p>
                      </button>
                    )}
                    {train.classes?.ac2Tier?.available && (
                      <button
                        type="button"
                        onClick={() => handleClassChange('ac2Tier')}
                        className={`p-4 border-2 rounded-lg transition-colors ${
                          formData.class === 'ac2Tier'
                            ? 'border-blue-600 bg-blue-50'
                            : 'border-gray-300 hover:border-blue-300'
                        }`}
                      >
                        <p className="text-gray-900 mb-1">AC 2-Tier</p>
                        <p className="text-blue-600">${train.classes.ac2Tier.price}</p>
                      </button>
                    )}
                    {train.classes?.ac1Tier?.available && (
                      <button
                        type="button"
                        onClick={() => handleClassChange('ac1Tier')}
                        className={`p-4 border-2 rounded-lg transition-colors ${
                          formData.class === 'ac1Tier'
                            ? 'border-blue-600 bg-blue-50'
                            : 'border-gray-300 hover:border-blue-300'
                        }`}
                      >
                        <p className="text-gray-900 mb-1">AC 1st</p>
                        <p className="text-blue-600">${train.classes.ac1Tier.price}</p>
                      </button>
                    )}
                  </div>
                </div>

                {/* Seats */}
                <div>
                  <label className="block text-gray-700 mb-2">Number of Seats (1-6) *</label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                    <select
                      value={formData.seats}
                      onChange={(e) => handleSeatsChange(parseInt(e.target.value))}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      {[1, 2, 3, 4, 5, 6].map((num) => (
                        <option key={num} value={num}>
                          {num} {num === 1 ? 'Seat' : 'Seats'}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Passenger Details */}
                <div className="border-t border-gray-200 pt-6">
                  <h3 className="mb-4">Passenger Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="md:col-span-2">
                      <label className="block text-gray-700 mb-2">Passenger Name *</label>
                      <input
                        type="text"
                        value={formData.passengerName}
                        onChange={(e) => setFormData({ ...formData, passengerName: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Full name"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 mb-2">Age *</label>
                      <input
                        type="number"
                        value={formData.passengerAge}
                        onChange={(e) => setFormData({ ...formData, passengerAge: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Age"
                        min="1"
                        max="120"
                        required
                      />
                    </div>
                    <div className="md:col-span-3">
                      <label className="block text-gray-700 mb-2">Gender *</label>
                      <div className="flex gap-4">
                        {['Male', 'Female', 'Other'].map((g) => (
                          <label key={g} className="flex items-center gap-2 cursor-pointer">
                            <input
                              type="radio"
                              name="gender"
                              value={g}
                              checked={formData.passengerGender === g}
                              onChange={(e) => setFormData({ ...formData, passengerGender: e.target.value })}
                              className="w-4 h-4"
                              required
                            />
                            <span>{g}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Confirm Booking
                </button>
              </form>
            </div>

            {/* Fare Summary */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <h2 className="mb-4">Fare Summary</h2>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">
                    Base Fare ({formData.seats} seat{formData.seats > 1 ? 's' : ''})
                  </span>
                  <span className="text-gray-900">${fare.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Taxes & Fees</span>
                  <span className="text-gray-900">$0.00</span>
                </div>
                <div className="border-t border-gray-200 pt-3 flex items-center justify-between">
                  <span className="text-gray-900">Total Amount</span>
                  <span className="text-blue-600">${fare.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
