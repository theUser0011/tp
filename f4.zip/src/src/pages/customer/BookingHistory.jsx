import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CustomerSidebar } from '../../components/CustomerSidebar';
import { Header } from '../../components/Header';
import { Calendar, Filter, Eye } from 'lucide-react';

export const BookingHistory = () => {
  const navigate = useNavigate();
  const [bookings, setBookings] = useState([]);
  const [filterStatus, setFilterStatus] = useState('all');

  useEffect(() => {
    loadBookings();
  }, []);

  const loadBookings = () => {
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    const allBookings = JSON.parse(localStorage.getItem('bookings') || '[]');
    const userBookings = allBookings.filter((b) => b.userId === currentUser.id);
    setBookings(userBookings);
  };

  const filteredBookings = bookings.filter((booking) => {
    if (filterStatus === 'all') return true;
    return booking.status === filterStatus;
  });

  const handleViewDetails = (booking) => {
    navigate('/customer/ticket-details', { state: { booking } });
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <CustomerSidebar />
      <div className="flex-1 ml-64">
        <Header title="Booking History" />
        
        <div className="p-8">
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2>My Bookings</h2>
              <div className="flex items-center gap-2">
                <Filter size={20} className="text-gray-400" />
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">All Bookings</option>
                  <option value="confirmed">Confirmed</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>
            </div>

            {filteredBookings.length === 0 ? (
              <div className="text-center py-12">
                <Calendar size={48} className="mx-auto mb-4 text-gray-300" />
                <p className="text-gray-600 mb-4">No bookings found</p>
                <button
                  onClick={() => navigate('/customer/search-trains')}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Book Your First Ticket
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-3 text-left text-gray-700">Booking ID</th>
                      <th className="px-6 py-3 text-left text-gray-700">Train</th>
                      <th className="px-6 py-3 text-left text-gray-700">Route</th>
                      <th className="px-6 py-3 text-left text-gray-700">Travel Date</th>
                      <th className="px-6 py-3 text-left text-gray-700">Class</th>
                      <th className="px-6 py-3 text-left text-gray-700">Fare</th>
                      <th className="px-6 py-3 text-left text-gray-700">Status</th>
                      <th className="px-6 py-3 text-left text-gray-700">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {filteredBookings.map((booking) => (
                      <tr key={booking.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 text-gray-900">{booking.bookingId}</td>
                        <td className="px-6 py-4">
                          <div>
                            <p className="text-gray-900">{booking.trainName}</p>
                            <p className="text-xs text-gray-500">{booking.trainNumber}</p>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-gray-600">
                          {booking.origin} → {booking.destination}
                        </td>
                        <td className="px-6 py-4 text-gray-600">{booking.travelDate}</td>
                        <td className="px-6 py-4 text-gray-600">{booking.class}</td>
                        <td className="px-6 py-4 text-gray-900">${booking.fare.toFixed(2)}</td>
                        <td className="px-6 py-4">
                          <span
                            className={`px-3 py-1 rounded-full text-xs ${
                              booking.status === 'confirmed'
                                ? 'bg-green-100 text-green-600'
                                : 'bg-red-100 text-red-600'
                            }`}
                          >
                            {booking.status}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <button
                            onClick={() => handleViewDetails(booking)}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="View Details"
                          >
                            <Eye size={18} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
