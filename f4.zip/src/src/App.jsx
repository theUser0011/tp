import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import CssBaseline from '@mui/material/CssBaseline';
import 'react-toastify/dist/ReactToastify.css';

 //Pages
import { LandingPage } from './pages/LandingPage';
import { Login } from './pages/Login';
import { Register } from './pages/Register';

 // Admin Pages
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { TrainRegistration } from './pages/admin/TrainRegistration';
import { TrainList } from './pages/admin/TrainList';
import  TrainUpdate from './pages/admin/TrainUpdate';

 // Customer Pages
import { CustomerDashboard } from './pages/CustomerDashboard';
import CustomerProfile from './pages/customer/CustomerProfile';
import DeactivateAccount  from './pages/customer/DeactivateAccount';
import { TrainSearch } from './pages/customer/TrainSearch';
import { BookingForm } from './pages/customer/BookingForm';
import { TicketDetails } from './pages/customer/TicketDetails';
import { BookingHistory } from './pages/customer/BookingHistory';
import { CancelTicket } from './pages/customer/CancelTicket';

// Components
import { ProtectedRoute } from './components/ProtectedRoute';
import { getAppTheme } from './components/common/theme';
import { ThemeProvider } from '@emotion/react';

//common


export default function App() {

  const theme = getAppTheme();

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          {/* Admin Routes */}
 {/* -----------------------------------------------------------------------------
  ADMIN DASHBOARD ROUTE (Protected by Role-Based Access)
 -----------------------------------------------------------------------------
 Explanation of Flow:

 - When a user tries to visit "/admin/dashboard", React Router checks this route.

 = Instead of rendering <AdminDashboard /> directly, it first renders the
     <ProtectedRoute> component.

     Why? Because <AdminDashboard /> is wrapped inside <ProtectedRoute>,
     so React must process the outer component first.

 - Inside <ProtectedRoute>, we perform authentication and authorization checks:
     - Step 1: Check if the user is logged in (via localStorage "currentUser").
     - Step 2: If logged in, check if their role === "admin".
     - Step 3: Based on results:
         • Not logged in → redirect to "/login" (with toast message)
         • Logged in but wrong role → redirect to "/" (Unauthorized access toast)
         • Logged in with correct "admin" role → ✅ render <AdminDashboard />

- So even though <AdminDashboard /> is written *inside* this route, it only
     actually renders after <ProtectedRoute> confirms the user’s access rights.

 In short: the <ProtectedRoute> acts as a "gatekeeper" that decides whether
 the nested component (<AdminDashboard />) should be shown or not.

 ----------------------------------------------------------------------------- */}


<Route
  path="/admin/dashboard"
  element={
    <ProtectedRoute requiredRole="admin">
      {/* ✅ This child component will only render if the user is logged in AND has admin role */}
      <AdminDashboard />
    </ProtectedRoute>
  }
/>


          <Route
            path="/admin/dashboard"
            element={
              <ProtectedRoute requiredRole="admin">
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/train-register"
            element={
              <ProtectedRoute requiredRole="admin">
                <TrainRegistration />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/train-list"
            element={
              <ProtectedRoute requiredRole="admin">
                <TrainList />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/train-update/:id"
            element={
              <ProtectedRoute requiredRole="admin">
                <TrainUpdate />
              </ProtectedRoute>
            }
          />

          {/* Customer Routes */}
          <Route
            path="/customer/dashboard"
            element={
              <ProtectedRoute requiredRole="customer">
                <CustomerDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/customer/profile"
            element={
              <ProtectedRoute requiredRole="customer">
                <CustomerProfile />
              </ProtectedRoute>
            }
          />
          <Route
            path="/customer/deactivate"
            element={
              <ProtectedRoute requiredRole="customer">
                <DeactivateAccount />
              </ProtectedRoute>
            }
          />
          <Route
            path="/customer/search-trains"
            element={
              <ProtectedRoute requiredRole="customer">
                <TrainSearch />
              </ProtectedRoute>
            }
          />
          <Route
            path="/customer/book-ticket"
            element={
              <ProtectedRoute requiredRole="customer">
                <BookingForm />
              </ProtectedRoute>
            }
          />
          <Route
            path="/customer/ticket-details"
            element={
              <ProtectedRoute requiredRole="customer">
                <TicketDetails />
              </ProtectedRoute>
            }
          />
          <Route
            path="/customer/booking-history"
            element={
              <ProtectedRoute requiredRole="customer">
                <BookingHistory />
              </ProtectedRoute>
            }
          />
          <Route
            path="/customer/cancel-ticket"
            element={
              <ProtectedRoute requiredRole="customer">
                <CancelTicket />
              </ProtectedRoute>
            }
          />

          {/* Fallback Route */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>

        {/* Toast Container with custom styling */}
        <ToastContainer
          position="top-right"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="light"
          toastStyle={{
            borderRadius: '12px',
            boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)',
          }}
        />
      </Router>
    </ThemeProvider>
  );
}
