import Cookies from 'js-cookie';
import axios from 'axios';

// -----------------------------------------------------------------------------
// BASE CONFIGURATION
// -----------------------------------------------------------------------------
// Define the base URL for all API calls in your app.
// This means any relative path you pass to axios (like '/trains/')
// will automatically be prefixed with this base URL.
//
// Example:
//    api.get('/trains/') → actually requests → http://127.0.0.1:8000/api/trains/
// -----------------------------------------------------------------------------
const API_BASE_URL = 'http://127.0.0.1:8000/api';

// -----------------------------------------------------------------------------
// CREATE AXIOS INSTANCE
// -----------------------------------------------------------------------------
// Instead of using axios directly everywhere (axios.get, axios.post, etc.),
// we create a *custom instance* that already knows:
//   • The base URL for your Django backend
//   • Common headers like 'Content-Type: application/json'
//   • Interceptors that will automatically attach the JWT access token
//     before every request.
//
// Now, any API call using this instance automatically includes authentication.
// -----------------------------------------------------------------------------
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json', // default for JSON APIs
  },
});

// -----------------------------------------------------------------------------
// REQUEST INTERCEPTOR
// -----------------------------------------------------------------------------
// Interceptors let you modify requests *before* they are sent.
//
// This function runs automatically before every axios call made through `api`.
// It checks if an access token exists in the browser cookies.
// If found, it appends it to the `Authorization` header as a Bearer token.
//
// Django REST Framework (with SimpleJWT) expects headers like:
//    Authorization: Bearer <access_token>
//
// So this ensures that all requests (GET, POST, PUT, PATCH, DELETE)
// automatically include the token — no need to manually attach it each time.

// Why This Is Important

// You no longer need to manually attach tokens for every request.
// All authenticated requests are handled automatically.
// Works for all HTTP methods (GET, POST, PATCH, PUT, DELETE).
// -----------------------------------------------------------------------------

// ---------------------------------------------------------------
//  AXIOS REQUEST INTERCEPTOR
// ---------------------------------------------------------------
//  What it does:
// Before *any* HTTP request (GET, POST, PATCH, DELETE) is sent to the backend,
// this interceptor automatically runs.
//
//  Purpose:
// - To read the user's access token from cookies
// - To attach it to every outgoing request header as `Authorization: Bearer <token>`
//   so that protected API endpoints can identify the logged-in user.
//
//  Example:
// When we call:
//     api.get('/trains/')
// The interceptor runs *first*, adds the header:
//     Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
// Then the modified request goes to the server.
//
//  Benefit:
// No need to manually attach tokens in every API call — this single block
// handles it globally and keeps your code cleaner and more secure.


api.interceptors.request.use((config) => {
  const token = Cookies.get('accessToken'); // read the token stored in cookies
  if (token) {
    // Attach token to every outgoing HTTP request header
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config; // must return config so the request can proceed
});


// Export the configured axios instance for use throughout your app
export default api;
