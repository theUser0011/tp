// -----------------------------------------------------------------------------
// PROTECTED ROUTE COMPONENT
// -----------------------------------------------------------------------------
// Purpose:
// This component acts as a gatekeeper for your React routes. It ensures that
// only authenticated users (and optionally, users with specific roles) can
// access certain pages in your app.
//
// For example:
//   <ProtectedRoute requiredRole="admin">
//       <AdminDashboard />
//   </ProtectedRoute>
//
// If the user is not logged in or doesn’t have the required role, they will be
// redirected accordingly, and a toast notification will be shown.
//
// -----------------------------------------------------------------------------


import { Navigate } from 'react-router-dom';   // For redirecting users to a different route
import { toast } from 'react-toastify';        // For displaying toast notifications

/**
 * ProtectedRoute
 *
 * @param {ReactNode} children - The protected component(s) to render if access is granted.
 * @param {string} requiredRole - (Optional) The role required to access this route.
 *
 * @example
 * // Example 1: Protect route for all authenticated users
 * <ProtectedRoute>
 *    <UserDashboard />
 * </ProtectedRoute>
 *
 * // Example 2: Protect route for admin users only
 * <ProtectedRoute requiredRole="admin">
 *    <AdminPanel />
 * </ProtectedRoute>
 */
export const ProtectedRoute = ({ children, requiredRole }) => {
  // ---------------------------------------------------------------------------
  // Step 1: Retrieve current user info from localStorage.
  // ---------------------------------------------------------------------------
  // The app stores user details in localStorage (after successful login),
  // typically something like:
  //   localStorage.setItem("currentUser", JSON.stringify({ username, role, token }));
  //
  // If no user is stored, this means the user is not logged in.
  // JSON.parse(null) would throw an error, so we use 'null' as a fallback string.
  // ---------------------------------------------------------------------------
  const user = JSON.parse(localStorage.getItem('currentUser') || 'null');

  // ---------------------------------------------------------------------------
  // Step 2: Check if the user is authenticated.
  // ---------------------------------------------------------------------------
  // If there is no user data in localStorage, we assume the user is not logged in.
  // Show an informational toast message, and redirect them to the login page.
  // The `replace` prop prevents the user from navigating back to the protected
  // route using the browser’s Back button.
  // ---------------------------------------------------------------------------
  if (!user) {
    toast.info('Please login to continue');
    return <Navigate to="/login" replace />;
  }

  // ---------------------------------------------------------------------------
  // Step 3: Check role-based authorization (if applicable).
  // ---------------------------------------------------------------------------
  // If a requiredRole prop was passed, we compare it with the user's role.
  // If they don’t match, this means the user is logged in but doesn’t have
  // the correct permissions to access this page.
  //
  // Example:
  //   requiredRole = "admin"
  //   user.role = "user"
  // → Unauthorized → redirect to home page.
  // ---------------------------------------------------------------------------
  if (requiredRole && user.role !== requiredRole) {
    toast.error('Unauthorized access');
    return <Navigate to="/" replace />;
  }

  // ---------------------------------------------------------------------------
  // Step 4: Access granted 
  // ---------------------------------------------------------------------------
  // If all checks pass, we simply render the child component(s) passed to
  // this wrapper.
  // ---------------------------------------------------------------------------
  return children;
};
