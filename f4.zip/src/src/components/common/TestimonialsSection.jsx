import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { FaStar } from "react-icons/fa";

export const TestimonialsSection = () => {
  const testimonials = [
    {
      name: "Sarah Johnson",
      review: "Easy to use and reliable. Booked my tickets in just 2 minutes!",
      rating: 5,
      avatar: "SJ",
    },
    {
      name: "Mike Chen",
      review: "Best railway booking platform. The live tracking feature is amazing.",
      rating: 5,
      avatar: "MC",
    },
    {
      name: "Priya Sharma",
      review: "Great customer service and hassle-free cancellations.",
      rating: 5,
      avatar: "PS",
    },
  ];

  return (
    <section className="testimonials-section py-5">
      <div className="container">
        {/* Heading */}
        <div className="text-center mb-5">
          <h2 className="fw-bold mb-3">What Our Users Say</h2>
          <p className="text-muted mx-auto" style={{ maxWidth: "600px" }}>
            Join thousands of satisfied travelers
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="row g-4">
          {testimonials.map((testimonial, index) => (
            <div className="col-12 col-md-4" key={index}>
              <div className="testimonial-card h-100 p-4 text-center d-flex flex-column justify-content-between">
                {/* Rating Stars */}
                <div className="mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <FaStar key={i} color="#fbbf24" size={18} className="me-1" />
                  ))}
                </div>

                {/* Review Text */}
                <p className="fst-italic text-muted mb-4">
                  “{testimonial.review}”
                </p>

                {/* Avatar + Name */}
                <div className="d-flex align-items-center justify-content-center">
                  <div
                    className="avatar-circle d-flex align-items-center justify-content-center me-3"
                    style={{ backgroundColor: "#2563eb" }}
                  >
                    <span>{testimonial.avatar}</span>
                  </div>
                  <div className="text-start">
                    <h6 className="fw-semibold mb-0">{testimonial.name}</h6>
                    <small className="text-muted">Verified Traveler</small>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
