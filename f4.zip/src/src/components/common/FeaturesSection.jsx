import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { FaClock, FaCreditCard, FaCheckCircle, FaShieldAlt } from "react-icons/fa";

export const FeaturesSection = () => {
  const features = [
    {
      icon: <FaCheckCircle size={30} color="#2563eb" />,
      title: "Instant Booking Confirmation",
      description: "Get your tickets confirmed instantly with real-time seat availability",
      color: "#2563eb",
    },
    {
      icon: <FaClock size={30} color="#10b981" />,
      title: "Live Train Status",
      description: "Track your train in real-time and get updates on delays and arrivals",
      color: "#10b981",
    },
    {
      icon: <FaShieldAlt size={30} color="#f59e0b" />,
      title: "Easy Cancellations",
      description: "Cancel your tickets hassle-free with quick refund processing",
      color: "#f59e0b",
    },
    {
      icon: <FaCreditCard size={30} color="#8b5cf6" />,
      title: "Secure Payments",
      description: "Multiple payment options with bank-grade security",
      color: "#8b5cf6",
    },
  ];

  return (
    <section className="features-section py-5 bg-light">
      <div className="container">
        <div className="text-center mb-5">
          <h2 className="fw-bold mb-3">Why Choose Us</h2>
          <p className="text-muted mx-auto" style={{ maxWidth: "600px" }}>
            We provide the best railway booking experience with cutting-edge features
          </p>
        </div>

        <div className="row g-4">
          {features.map((feature, index) => (
            <div className="col-12 col-sm-6 col-lg-3" key={index}>
              <div className="feature-card h-100 text-center p-4 border rounded shadow-sm">
                <div
                  className="feature-icon mx-auto mb-3 d-flex align-items-center justify-content-center rounded-circle"
                  style={{
                    backgroundColor: `${feature.color}15`,
                    width: "64px",
                    height: "64px",
                  }}
                >
                  {feature.icon}
                </div>
                <h5 className="fw-semibold mb-2">{feature.title}</h5>
                <p className="text-muted mb-0">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
