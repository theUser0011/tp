import { AppBar, Toolbar, Typography, Box, Button } from '@mui/material';
import { Train } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const NavigationBar = () => {
  const navigate = useNavigate();
  return (
    <AppBar position="sticky" color="default" elevation={1} sx={{ bgcolor: 'background.paper' }}>
      <Toolbar>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flex: 1 }}>
          <Train size={32} color="#2563eb" />
          <Typography variant="h6" sx={{ color: 'primary.main', fontWeight: 700 }}>
            RailwayBooking
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button onClick={() => navigate('/login')} color="inherit">Login</Button>
          <Button onClick={() => navigate('/register')} variant="contained" color="primary">
            Sign Up
          </Button>
        </Box>
      </Toolbar>
    </AppBar>
  );
};
