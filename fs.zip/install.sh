#!/bin/sh

sudo rm feedback.py
sudo apt-get update
sudo apt install -y libxml2-utils
mvn install
