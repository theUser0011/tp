package com.example.warehouse.controller;

import com.example.warehouse.model.Product;
import com.example.warehouse.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductService productService;

    // 🟢 Add new product
    @PostMapping("/add")
    public ResponseEntity<Object> postProduct(@RequestBody Product product) {
        return (ResponseEntity<Object>) productService.postProduct(product);
    }

    // 🟢 Get all products
    @GetMapping("/get")
    public ResponseEntity<Object> getProduct() {
        return (ResponseEntity<Object>) productService.getProduct();
    }

    // 🟢 Update product (price & stock)
    @PutMapping("/{id}")
    public ResponseEntity<Object> updateProduct(@PathVariable int id, @RequestBody Product product) {
        return productService.updateProduct(id, product);
    }

    // 🟢 Delete product by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteProductById(@PathVariable int id) {
        return productService.deleteProductById(id);
    }

    // 🟢 Get products by vendor
    @GetMapping("/vendor")
    public ResponseEntity<Object> getSimilarVendor(@RequestParam("value") String value) {
        return productService.getSimilarVendor(value);
    }
}
