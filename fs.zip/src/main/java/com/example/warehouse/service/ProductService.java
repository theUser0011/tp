package com.example.warehouse.service;

import com.example.warehouse.model.Product;
import com.example.warehouse.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    // 🟢 Add a new product
    public ResponseEntity<Object> postProduct(Product product) {
        try {
            if (product.getSku() == null || product.getSku().isEmpty()) {
                return new ResponseEntity<>("SKU cannot be empty", HttpStatus.BAD_REQUEST);
            }

            Product savedProduct = productRepository.save(product);
            return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);

        } catch (DataIntegrityViolationException e) {
            // Unique constraint failure (duplicate SKU)
            return new ResponseEntity<>("SKU must be unique", HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to add product", HttpStatus.BAD_REQUEST);
        }
    }

    // 🟢 Get all products
    public ResponseEntity<Object> getProduct() {
        List<Product> products = productRepository.findAll();
        if (products.isEmpty()) {
            return new ResponseEntity<>("No products found", HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    // 🟢 Get products by vendor name
    public ResponseEntity<Object> getSimilarVendor(String value) {
        List<Product> products = productRepository.findByVendor(value);
        if (products.isEmpty()) {
            return new ResponseEntity<>("No products found for vendor: " + value, HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    // 🟢 Update product (price and stock only)
    public ResponseEntity<Object> updateProduct(int id, Product product) {
        Optional<Product> existingProduct = productRepository.findById(id);

        if (existingProduct.isEmpty()) {
            return new ResponseEntity<>("Invalid Product ID", HttpStatus.BAD_REQUEST);
        }

        Product p = existingProduct.get();
        p.setPrice(product.getPrice());
        p.setStock(product.getStock());

        productRepository.save(p);
        return new ResponseEntity<>(p, HttpStatus.OK);
    }

    // 🟢 Delete product by ID
    public ResponseEntity<Object> deleteProductById(int id) {
        Optional<Product> existingProduct = productRepository.findById(id);

        if (existingProduct.isEmpty()) {
            return new ResponseEntity<>("Invalid Product ID", HttpStatus.BAD_REQUEST);
        }

        productRepository.deleteById(id);
        return new ResponseEntity<>("Product deleted successfully", HttpStatus.OK);
    }
}
