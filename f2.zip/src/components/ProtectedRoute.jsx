import { Navigate } from 'react-router-dom';
import { toast } from 'react-toastify';

export const ProtectedRoute = ({ children, requiredRole }) => {
  const user = JSON.parse(localStorage.getItem('currentUser') || 'null');

  if (!user) {
    toast.info('Please login to continue');
    return <Navigate to="/login" replace />;
  }

  if (requiredRole && user.role !== requiredRole) {
    toast.error('Unauthorized access');
    return <Navigate to="/" replace />;
  }

  return children;
};
