import { Link, useLocation, useNavigate } from 'react-router-dom';
import { User, UserX, Search, XCircle, History, LogOut, LayoutDashboard, Ticket } from 'lucide-react';
import { 
  List, 
  ListItem, 
  ListItemButton, 
  ListItemIcon, 
  ListItemText, 
  Box, 
  Typography, 
  Divider,
  Tooltip
} from '@mui/material';
import { toast } from 'react-toastify';

export const CustomerSidebar = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const menuItems = [
    { path: '/customer/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/customer/profile', label: 'Update Profile', icon: User },
    { path: '/customer/search-trains', label: 'Search Trains', icon: Search },
    { path: '/customer/booking-history', label: 'Booking History', icon: History },
    { path: '/customer/cancel-ticket', label: 'Cancel Ticket', icon: XCircle },
    { path: '/customer/deactivate', label: 'Deactivate Account', icon: UserX },
  ];

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    toast.success('Logged out successfully');
    navigate('/login');
  };

  return (
    <Box
      sx={{
        width: 280,
        height: '100vh',
        position: 'fixed',
        left: 0,
        top: 0,
        background: 'linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%)',
        borderRight: '1px solid',
        borderColor: 'rgba(37, 99, 235, 0.1)',
        display: 'flex',
        flexDirection: 'column',
        boxShadow: '4px 0 24px -8px rgba(37, 99, 235, 0.15)',
        animation: 'slideIn 0.3s ease-out',
        '@keyframes slideIn': {
          from: {
            transform: 'translateX(-100%)',
            opacity: 0,
          },
          to: {
            transform: 'translateX(0)',
            opacity: 1,
          },
        },
      }}
    >
      {/* Sidebar Header */}
      <Box 
        sx={{ 
          p: 3, 
          borderBottom: '2px solid',
          borderImage: 'linear-gradient(90deg, #2563eb 0%, #8b5cf6 100%) 1',
          background: 'linear-gradient(135deg, rgba(37, 99, 235, 0.05) 0%, rgba(139, 92, 246, 0.05) 100%)',
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
          <Box
            sx={{
              width: 40,
              height: 40,
              borderRadius: 2,
              background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 4px 12px rgba(37, 99, 235, 0.3)',
            }}
          >
            <Ticket size={24} color="white" />
          </Box>
          <Box>
            <Typography 
              variant="h6" 
              sx={{ 
                background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              Railway Portal
            </Typography>
            <Typography variant="caption" color="text.secondary">
              Customer Dashboard
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* Menu Items */}
      <List sx={{ flex: 1, p: 2, overflowY: 'auto' }}>
        {menuItems.map((item, index) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <ListItem 
              key={item.path} 
              disablePadding 
              sx={{ 
                mb: 1,
                animation: `fadeInUp 0.3s ease-out ${index * 0.1}s both`,
                '@keyframes fadeInUp': {
                  from: {
                    opacity: 0,
                    transform: 'translateY(10px)',
                  },
                  to: {
                    opacity: 1,
                    transform: 'translateY(0)',
                  },
                },
              }}
            >
              <Tooltip title={item.label} placement="right" arrow>
                <ListItemButton
                  component={Link}
                  to={item.path}
                  sx={{
                    borderRadius: 2,
                    background: isActive 
                      ? 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)'
                      : 'transparent',
                    color: isActive ? 'white' : 'text.primary',
                    position: 'relative',
                    overflow: 'hidden',
                    '&::before': isActive ? {
                      content: '""',
                      position: 'absolute',
                      left: 0,
                      top: 0,
                      width: '4px',
                      height: '100%',
                      background: 'white',
                      borderRadius: '0 4px 4px 0',
                    } : {},
                    '&:hover': {
                      background: isActive 
                        ? 'linear-gradient(135deg, #1d4ed8 0%, #7c3aed 100%)'
                        : 'linear-gradient(135deg, rgba(37, 99, 235, 0.08) 0%, rgba(139, 92, 246, 0.08) 100%)',
                      transform: 'translateX(4px)',
                      boxShadow: isActive ? '0 4px 12px rgba(37, 99, 235, 0.3)' : 'none',
                    },
                    transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
                  }}
                >
                  <ListItemIcon 
                    sx={{ 
                      color: isActive ? 'white' : 'primary.main', 
                      minWidth: 40,
                      transition: 'transform 0.2s',
                      '&:hover': {
                        transform: 'scale(1.1)',
                      }
                    }}
                  >
                    <Icon size={20} />
                  </ListItemIcon>
                  <ListItemText 
                    primary={item.label}
                    primaryTypographyProps={{
                      fontSize: '0.9rem',
                    }}
                  />
                  {isActive && (
                    <Box
                      sx={{
                        width: 8,
                        height: 8,
                        borderRadius: '50%',
                        bgcolor: 'white',
                        boxShadow: '0 0 8px rgba(255, 255, 255, 0.8)',
                      }}
                    />
                  )}
                </ListItemButton>
              </Tooltip>
            </ListItem>
          );
        })}
      </List>

      {/* Logout Section */}
      <Divider sx={{ borderColor: 'rgba(37, 99, 235, 0.1)' }} />
      <Box sx={{ p: 2 }}>
        <ListItemButton
          onClick={handleLogout}
          sx={{
            borderRadius: 2,
            color: 'error.main',
            border: '1px solid',
            borderColor: 'error.light',
            '&:hover': {
              background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.08) 0%, rgba(220, 38, 38, 0.08) 100%)',
              borderColor: 'error.main',
              transform: 'translateX(4px)',
            },
            transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
          }}
        >
          <ListItemIcon sx={{ color: 'error.main', minWidth: 40 }}>
            <LogOut size={20} />
          </ListItemIcon>
          <ListItemText primary="Logout" />
        </ListItemButton>
      </Box>
    </Box>
  );
};
