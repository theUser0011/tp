import { useState, useEffect } from 'react';
import { Bell, Settings, User, ChevronDown } from 'lucide-react';
import { 
  AppBar, 
  Toolbar, 
  Typography, 
  IconButton, 
  Avatar, 
  Box, 
  Badge,
  Menu,
  MenuItem,
  Divider
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

export const Header = ({ title }) => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('currentUser') || '{}');
  const [scrolled, setScrolled] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    toast.success('Logged out successfully');
    navigate('/login');
    handleMenuClose();
  };

  return (
    <AppBar
      position="sticky"
      elevation={0}
      sx={{
        background: scrolled 
          ? 'linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(248, 250, 252, 0.95) 100%)'
          : 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
        backdropFilter: scrolled ? 'blur(10px)' : 'none',
        borderBottom: '1px solid',
        borderColor: scrolled ? 'rgba(37, 99, 235, 0.1)' : 'divider',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        boxShadow: scrolled ? '0 4px 6px -1px rgba(37, 99, 235, 0.1)' : 'none',
      }}
    >
      <Toolbar 
        sx={{ 
          py: scrolled ? 1 : 1.5,
          transition: 'padding 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
        }}
      >
        <Typography 
          variant="h5" 
          sx={{ 
            flex: 1,
            background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
            backgroundClip: 'text',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            transition: 'all 0.3s',
          }}
        >
          {title}
        </Typography>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <IconButton 
            sx={{
              transition: 'all 0.2s',
              '&:hover': {
                transform: 'scale(1.1)',
                bgcolor: 'rgba(37, 99, 235, 0.08)',
              }
            }}
          >
            <Badge 
              badgeContent={3} 
              color="error"
              sx={{
                '& .MuiBadge-badge': {
                  animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                  '@keyframes pulse': {
                    '0%, 100%': {
                      opacity: 1,
                    },
                    '50%': {
                      opacity: 0.5,
                    },
                  },
                },
              }}
            >
              <Bell size={20} />
            </Badge>
          </IconButton>
          
          <IconButton
            sx={{
              transition: 'all 0.2s',
              '&:hover': {
                transform: 'rotate(45deg) scale(1.1)',
                bgcolor: 'rgba(37, 99, 235, 0.08)',
              }
            }}
          >
            <Settings size={20} />
          </IconButton>
          
          <Box
            onClick={handleMenuOpen}
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 1.5,
              ml: 2,
              pl: 2,
              borderLeft: '2px solid',
              borderImage: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%) 1',
              cursor: 'pointer',
              transition: 'all 0.2s',
              '&:hover': {
                transform: 'translateX(2px)',
              }
            }}
          >
            <Avatar 
              sx={{ 
                background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                width: 40, 
                height: 40,
                transition: 'all 0.2s',
                '&:hover': {
                  transform: 'scale(1.05)',
                  boxShadow: '0 0 20px rgba(37, 99, 235, 0.4)',
                },
              }}
            >
              <User size={20} />
            </Avatar>
            <Box>
              <Typography 
                variant="body2" 
                sx={{ 
                  display: 'flex',
                  alignItems: 'center',
                  gap: 0.5,
                }}
              >
                {user.name || 'User'}
                <ChevronDown size={16} />
              </Typography>
              <Typography 
                variant="caption" 
                sx={{
                  background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                  backgroundClip: 'text',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                {user.role || 'Guest'}
              </Typography>
            </Box>
          </Box>
        </Box>
      </Toolbar>

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
        PaperProps={{
          sx: {
            mt: 1,
            minWidth: 200,
            borderRadius: 2,
            boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)',
          }
        }}
      >
        <MenuItem 
          onClick={() => {
            navigate(user.role === 'admin' ? '/admin/dashboard' : '/customer/profile');
            handleMenuClose();
          }}
          sx={{
            '&:hover': {
              background: 'linear-gradient(135deg, rgba(37, 99, 235, 0.1) 0%, rgba(139, 92, 246, 0.1) 100%)',
            }
          }}
        >
          <User size={18} style={{ marginRight: 8 }} />
          Profile
        </MenuItem>
        <MenuItem 
          onClick={handleMenuClose}
          sx={{
            '&:hover': {
              background: 'linear-gradient(135deg, rgba(37, 99, 235, 0.1) 0%, rgba(139, 92, 246, 0.1) 100%)',
            }
          }}
        >
          <Settings size={18} style={{ marginRight: 8 }} />
          Settings
        </MenuItem>
        <Divider />
        <MenuItem 
          onClick={handleLogout}
          sx={{
            color: 'error.main',
            '&:hover': {
              bgcolor: 'rgba(239, 68, 68, 0.08)',
            }
          }}
        >
          Logout
        </MenuItem>
      </Menu>
    </AppBar>
  );
};
