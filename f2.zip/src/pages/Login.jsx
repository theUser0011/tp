import { useState } from 'react';
import { useNavigate, Link as RouterLink } from 'react-router-dom';
import { LogIn, Train } from 'lucide-react';
import { Box, Card, CardContent, TextField, Button, Typography, Link, InputAdornment, Avatar, Divider, Chip } from '@mui/material';
import { toast } from 'react-toastify';

export const Login = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const handleSubmit = (e) => {
    e.preventDefault();

    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(
      (u) => u.email === formData.email && u.password === formData.password
    );

    if (user) {
      localStorage.setItem('currentUser', JSON.stringify(user));
      toast.success('Login successful!');
      
      if (user.role === 'admin') {
        navigate('/admin/dashboard');
      } else {
        navigate('/customer/dashboard');
      }
    } else {
      toast.error('Invalid credentials. Please try again.');
    }
  };

  const loginAsDemo = (role) => {
    const demoUser = {
      admin: { email: 'admin@railway.com', password: 'admin123', name: 'Admin User', role: 'admin' },
      customer: { email: 'customer@railway.com', password: 'customer123', name: 'John Doe', role: 'customer' }
    };

    const user = demoUser[role];
    localStorage.setItem('currentUser', JSON.stringify(user));
    toast.success(`Logged in as ${role}!`);
    
    if (role === 'admin') {
      navigate('/admin/dashboard');
    } else {
      navigate('/customer/dashboard');
    }
  };

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
        p: 2,
      }}
    >
      <Card
        elevation={8}
        sx={{
          maxWidth: 480,
          width: '100%',
          borderRadius: 3,
        }}
      >
        <CardContent sx={{ p: 5 }}>
          <Box sx={{ textAlign: 'center', mb: 4 }}>
            <Avatar
              sx={{
                bgcolor: 'primary.lighter',
                width: 72,
                height: 72,
                mx: 'auto',
                mb: 2,
              }}
            >
              <Train size={40} color="#2563eb" />
            </Avatar>
            <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
              Welcome Back
            </Typography>
            <Typography color="text.secondary">
              Login to your railway account
            </Typography>
          </Box>

          <Box component="form" onSubmit={handleSubmit} sx={{ mb: 3 }}>
            <TextField
              fullWidth
              label="Email Address"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
              sx={{ mb: 3 }}
            />

            <TextField
              fullWidth
              label="Password"
              type="password"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
              sx={{ mb: 4 }}
            />

            <Button
              fullWidth
              size="large"
              type="submit"
              variant="contained"
              startIcon={<LogIn size={20} />}
              sx={{
                py: 1.5,
                fontSize: '1rem',
                textTransform: 'none',
                boxShadow: 2,
                '&:hover': {
                  boxShadow: 4,
                  transform: 'translateY(-2px)',
                },
                transition: 'all 0.3s',
              }}
            >
              Login
            </Button>
          </Box>

          <Box sx={{ textAlign: 'center', mb: 3 }}>
            <Typography color="text.secondary" sx={{ mb: 1 }}>
              Don't have an account?{' '}
              <Link component={RouterLink} to="/register" sx={{ fontWeight: 600 }}>
                Create Account
              </Link>
            </Typography>
          </Box>

          <Divider sx={{ my: 3 }}>
            <Chip label="OR" size="small" />
          </Divider>

          <Box sx={{ mb: 3 }}>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', textAlign: 'center', mb: 2 }}>
              Demo Accounts (Quick Login):
            </Typography>
            <Box sx={{ display: 'flex', gap: 2 }}>
              <Button
                fullWidth
                variant="outlined"
                color="secondary"
                onClick={() => loginAsDemo('admin')}
                sx={{
                  textTransform: 'none',
                  borderWidth: 2,
                  '&:hover': { borderWidth: 2 },
                }}
              >
                Login as Admin
              </Button>
              <Button
                fullWidth
                variant="outlined"
                color="success"
                onClick={() => loginAsDemo('customer')}
                sx={{
                  textTransform: 'none',
                  borderWidth: 2,
                  '&:hover': { borderWidth: 2 },
                }}
              >
                Login as Customer
              </Button>
            </Box>
          </Box>

          <Box sx={{ textAlign: 'center' }}>
            <Link component={RouterLink} to="/" color="text.secondary" sx={{ textDecoration: 'none' }}>
              ← Back to Home
            </Link>
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
};
