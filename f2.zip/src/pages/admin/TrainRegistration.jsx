import { useState } from 'react';
import { AdminSidebar } from '../../components/AdminSidebar';
import { Header } from '../../components/Header';
import { Train, Plus, Trash2, Clock, MapPin, DollarSign } from 'lucide-react';
import { toast } from 'react-toastify';
import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Grid,
  Checkbox,
  FormControlLabel,
  IconButton,
  Divider,
  Avatar,
} from '@mui/material';

export const TrainRegistration = () => {
  const [formData, setFormData] = useState({
    trainNumber: '',
    trainName: '',
    origin: '',
    destination: '',
    departureTime: '',
    arrivalTime: '',
    duration: '',
    classes: {
      sleeper: { available: true, price: '' },
      ac3Tier: { available: true, price: '' },
      ac2Tier: { available: true, price: '' },
      ac1Tier: { available: true, price: '' },
    },
  });

  const [stops, setStops] = useState([
    { station: '', arrivalTime: '', departureTime: '' },
  ]);

  const handleAddStop = () => {
    setStops([...stops, { station: '', arrivalTime: '', departureTime: '' }]);
  };

  const handleRemoveStop = (index) => {
    if (stops.length > 1) {
      setStops(stops.filter((_, i) => i !== index));
    }
  };

  const handleStopChange = (index, field, value) => {
    const newStops = [...stops];
    newStops[index][field] = value;
    setStops(newStops);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.trainNumber || !formData.trainName || !formData.origin || !formData.destination) {
      toast.error('Please fill all required fields');
      return;
    }

    const trains = JSON.parse(localStorage.getItem('trains') || '[]');
    
    const newTrain = {
      id: Date.now(),
      ...formData,
      stops: stops.filter(stop => stop.station),
      createdAt: new Date().toISOString(),
    };

    trains.push(newTrain);
    localStorage.setItem('trains', JSON.stringify(trains));

    toast.success('Train registered successfully!');
    
    setFormData({
      trainNumber: '',
      trainName: '',
      origin: '',
      destination: '',
      departureTime: '',
      arrivalTime: '',
      duration: '',
      classes: {
        sleeper: { available: true, price: '' },
        ac3Tier: { available: true, price: '' },
        ac2Tier: { available: true, price: '' },
        ac1Tier: { available: true, price: '' },
      },
    });
    setStops([{ station: '', arrivalTime: '', departureTime: '' }]);
  };

  return (
    <Box sx={{ display: 'flex', bgcolor: 'background.default', minHeight: '100vh' }}>
      <AdminSidebar />
      <Box sx={{ flex: 1, ml: '280px' }}>
        <Header title="Train Registration" />
        
        <Box sx={{ p: 4 }}>
          <Card
            elevation={0}
            sx={{
              maxWidth: 1000,
              mx: 'auto',
              border: '1px solid',
              borderColor: 'rgba(37, 99, 235, 0.2)',
              background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
              transition: 'all 0.3s',
              animation: 'fadeIn 0.5s ease-out',
              '@keyframes fadeIn': {
                from: { opacity: 0, transform: 'translateY(20px)' },
                to: { opacity: 1, transform: 'translateY(0)' },
              },
            }}
          >
            <CardContent sx={{ p: 4 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 4 }}>
                <Avatar
                  sx={{
                    background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                    width: 56,
                    height: 56,
                    boxShadow: '0 4px 12px rgba(37, 99, 235, 0.3)',
                  }}
                >
                  <Train size={28} />
                </Avatar>
                <Box>
                  <Typography variant="h5">Register New Train</Typography>
                  <Typography variant="body2" color="text.secondary">
                    Add a new train to the system
                  </Typography>
                </Box>
              </Box>

              <Box component="form" onSubmit={handleSubmit}>
                {/* Basic Information */}
                <Box sx={{ mb: 4 }}>
                  <Typography 
                    variant="h6" 
                    sx={{ 
                      mb: 3,
                      background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                      backgroundClip: 'text',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                    }}
                  >
                    Basic Information
                  </Typography>
                  <Grid container spacing={3}>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="Train Number"
                        value={formData.trainNumber}
                        onChange={(e) => setFormData({ ...formData, trainNumber: e.target.value })}
                        placeholder="e.g., 12345"
                        required
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="Train Name"
                        value={formData.trainName}
                        onChange={(e) => setFormData({ ...formData, trainName: e.target.value })}
                        placeholder="e.g., Rajdhani Express"
                        required
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="Origin Station"
                        value={formData.origin}
                        onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
                        placeholder="e.g., New Delhi"
                        required
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="Destination Station"
                        value={formData.destination}
                        onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                        placeholder="e.g., Mumbai"
                        required
                      />
                    </Grid>
                  </Grid>
                </Box>

                <Divider sx={{ my: 4 }} />

                {/* Schedule Information */}
                <Box sx={{ mb: 4 }}>
                  <Typography 
                    variant="h6" 
                    sx={{ 
                      mb: 3,
                      background: 'linear-gradient(135deg, #06b6d4 0%, #3b82f6 100%)',
                      backgroundClip: 'text',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                    }}
                  >
                    Schedule Information
                  </Typography>
                  <Grid container spacing={3}>
                    <Grid item xs={12} sm={4}>
                      <TextField
                        fullWidth
                        label="Departure Time"
                        type="time"
                        value={formData.departureTime}
                        onChange={(e) => setFormData({ ...formData, departureTime: e.target.value })}
                        InputLabelProps={{ shrink: true }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={4}>
                      <TextField
                        fullWidth
                        label="Arrival Time"
                        type="time"
                        value={formData.arrivalTime}
                        onChange={(e) => setFormData({ ...formData, arrivalTime: e.target.value })}
                        InputLabelProps={{ shrink: true }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={4}>
                      <TextField
                        fullWidth
                        label="Duration"
                        value={formData.duration}
                        onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                        placeholder="e.g., 16h 30m"
                      />
                    </Grid>
                  </Grid>
                </Box>

                <Divider sx={{ my: 4 }} />

                {/* Intermediate Stops */}
                <Box sx={{ mb: 4 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                    <Typography 
                      variant="h6"
                      sx={{ 
                        background: 'linear-gradient(135deg, #10b981 0%, #14b8a6 100%)',
                        backgroundClip: 'text',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                      }}
                    >
                      Intermediate Stops
                    </Typography>
                    <Button
                      variant="contained"
                      startIcon={<Plus size={18} />}
                      onClick={handleAddStop}
                      sx={{
                        background: 'linear-gradient(135deg, #10b981 0%, #14b8a6 100%)',
                        '&:hover': {
                          background: 'linear-gradient(135deg, #059669 0%, #0d9488 100%)',
                        }
                      }}
                    >
                      Add Stop
                    </Button>
                  </Box>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    {stops.map((stop, index) => (
                      <Card
                        key={index}
                        elevation={0}
                        sx={{
                          border: '1px solid',
                          borderColor: 'rgba(16, 185, 129, 0.2)',
                          bgcolor: 'rgba(16, 185, 129, 0.02)',
                        }}
                      >
                        <CardContent>
                          <Grid container spacing={2} alignItems="center">
                            <Grid item xs={12} sm={4}>
                              <TextField
                                fullWidth
                                size="small"
                                label="Station Name"
                                value={stop.station}
                                onChange={(e) => handleStopChange(index, 'station', e.target.value)}
                                placeholder="Station"
                              />
                            </Grid>
                            <Grid item xs={12} sm={3}>
                              <TextField
                                fullWidth
                                size="small"
                                label="Arrival"
                                type="time"
                                value={stop.arrivalTime}
                                onChange={(e) => handleStopChange(index, 'arrivalTime', e.target.value)}
                                InputLabelProps={{ shrink: true }}
                              />
                            </Grid>
                            <Grid item xs={12} sm={3}>
                              <TextField
                                fullWidth
                                size="small"
                                label="Departure"
                                type="time"
                                value={stop.departureTime}
                                onChange={(e) => handleStopChange(index, 'departureTime', e.target.value)}
                                InputLabelProps={{ shrink: true }}
                              />
                            </Grid>
                            <Grid item xs={12} sm={2}>
                              <IconButton
                                onClick={() => handleRemoveStop(index)}
                                disabled={stops.length === 1}
                                sx={{
                                  color: 'error.main',
                                  '&:hover': { bgcolor: 'rgba(239, 68, 68, 0.1)' }
                                }}
                              >
                                <Trash2 size={18} />
                              </IconButton>
                            </Grid>
                          </Grid>
                        </CardContent>
                      </Card>
                    ))}
                  </Box>
                </Box>

                <Divider sx={{ my: 4 }} />

                {/* Class Pricing */}
                <Box sx={{ mb: 4 }}>
                  <Typography 
                    variant="h6" 
                    sx={{ 
                      mb: 3,
                      background: 'linear-gradient(135deg, #f59e0b 0%, #f97316 100%)',
                      backgroundClip: 'text',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                    }}
                  >
                    Class & Pricing
                  </Typography>
                  <Grid container spacing={3}>
                    {Object.entries(formData.classes).map(([key, value]) => {
                      const labels = {
                        sleeper: 'Sleeper Class',
                        ac3Tier: 'AC 3-Tier',
                        ac2Tier: 'AC 2-Tier',
                        ac1Tier: 'AC 1st Class'
                      };
                      return (
                        <Grid item xs={12} sm={6} key={key}>
                          <Card
                            elevation={0}
                            sx={{
                              border: '1px solid',
                              borderColor: 'rgba(245, 158, 11, 0.3)',
                              bgcolor: 'rgba(245, 158, 11, 0.05)',
                            }}
                          >
                            <CardContent>
                              <FormControlLabel
                                control={
                                  <Checkbox
                                    checked={value.available}
                                    onChange={(e) => setFormData({
                                      ...formData,
                                      classes: {
                                        ...formData.classes,
                                        [key]: { ...value, available: e.target.checked }
                                      }
                                    })}
                                  />
                                }
                                label={labels[key]}
                                sx={{ mb: 1 }}
                              />
                              <TextField
                                fullWidth
                                type="number"
                                label="Price ($)"
                                value={value.price}
                                onChange={(e) => setFormData({
                                  ...formData,
                                  classes: {
                                    ...formData.classes,
                                    [key]: { ...value, price: e.target.value }
                                  }
                                })}
                                disabled={!value.available}
                                placeholder="Enter price"
                              />
                            </CardContent>
                          </Card>
                        </Grid>
                      );
                    })}
                  </Grid>
                </Box>

                <Box sx={{ display: 'flex', gap: 2, pt: 2 }}>
                  <Button
                    fullWidth
                    type="submit"
                    variant="contained"
                    size="large"
                    sx={{
                      background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                      py: 1.5,
                      '&:hover': {
                        background: 'linear-gradient(135deg, #1d4ed8 0%, #7c3aed 100%)',
                        transform: 'translateY(-2px)',
                        boxShadow: '0 8px 20px rgba(37, 99, 235, 0.4)',
                      },
                      transition: 'all 0.2s',
                    }}
                  >
                    Register Train
                  </Button>
                  <Button
                    variant="outlined"
                    size="large"
                    onClick={() => window.history.back()}
                    sx={{
                      borderColor: 'rgba(37, 99, 235, 0.3)',
                      color: 'primary.main',
                      px: 4,
                      py: 1.5,
                      '&:hover': {
                        borderColor: 'primary.main',
                        bgcolor: 'rgba(37, 99, 235, 0.05)',
                      }
                    }}
                  >
                    Cancel
                  </Button>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Box>
      </Box>
    </Box>
  );
};
