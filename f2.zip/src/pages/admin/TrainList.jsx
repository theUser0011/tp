import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AdminSidebar } from '../../components/AdminSidebar';
import { Header } from '../../components/Header';
import { Edit, Trash2, Search, Plus, Train as TrainIcon } from 'lucide-react';
import { toast } from 'react-toastify';
import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  InputAdornment,
  Chip,
} from '@mui/material';

export const TrainList = () => {
  const navigate = useNavigate();
  const [trains, setTrains] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [trainToDelete, setTrainToDelete] = useState(null);

  useEffect(() => {
    loadTrains();
  }, []);

  const loadTrains = () => {
    const storedTrains = JSON.parse(localStorage.getItem('trains') || '[]');
    
    if (storedTrains.length === 0) {
      const sampleTrains = [
        {
          id: 1,
          trainNumber: '12301',
          trainName: 'Rajdhani Express',
          origin: 'New Delhi',
          destination: 'Mumbai Central',
          departureTime: '16:55',
          arrivalTime: '08:35',
          duration: '15h 40m',
        },
        {
          id: 2,
          trainNumber: '12002',
          trainName: 'Shatabdi Express',
          origin: 'New Delhi',
          destination: 'Chandigarh',
          departureTime: '07:40',
          arrivalTime: '10:50',
          duration: '3h 10m',
        },
        {
          id: 3,
          trainNumber: '12259',
          trainName: 'Duronto Express',
          origin: 'Sealdah',
          destination: 'New Delhi',
          departureTime: '16:50',
          arrivalTime: '10:05',
          duration: '17h 15m',
        },
      ];
      localStorage.setItem('trains', JSON.stringify(sampleTrains));
      setTrains(sampleTrains);
    } else {
      setTrains(storedTrains);
    }
  };

  const filteredTrains = trains.filter((train) =>
    train.trainName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    train.trainNumber.includes(searchTerm) ||
    train.origin.toLowerCase().includes(searchTerm.toLowerCase()) ||
    train.destination.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleEdit = (train) => {
    navigate(`/admin/train-update/${train.id}`, { state: { train } });
  };

  const handleDeleteClick = (train) => {
    setTrainToDelete(train);
    setShowDeleteDialog(true);
  };

  const confirmDelete = () => {
    const updatedTrains = trains.filter((t) => t.id !== trainToDelete.id);
    localStorage.setItem('trains', JSON.stringify(updatedTrains));
    setTrains(updatedTrains);
    toast.success('Train deleted successfully');
    setShowDeleteDialog(false);
    setTrainToDelete(null);
  };

  return (
    <Box sx={{ display: 'flex', bgcolor: 'background.default', minHeight: '100vh' }}>
      <AdminSidebar />
      <Box sx={{ flex: 1, ml: '280px' }}>
        <Header title="Manage Trains" />
        
        <Box sx={{ p: 4 }}>
          <Card
            elevation={0}
            sx={{
              border: '1px solid',
              borderColor: 'rgba(37, 99, 235, 0.2)',
              background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
              animation: 'fadeIn 0.5s ease-out',
              '@keyframes fadeIn': {
                from: { opacity: 0, transform: 'translateY(20px)' },
                to: { opacity: 1, transform: 'translateY(0)' },
              },
            }}
          >
            <CardContent sx={{ p: 3 }}>
              {/* Search and Actions */}
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3, gap: 2, flexWrap: 'wrap' }}>
                <TextField
                  placeholder="Search trains..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  sx={{ minWidth: 300, flex: 1, maxWidth: 500 }}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <Search size={20} color="#6b7280" />
                      </InputAdornment>
                    ),
                  }}
                />
                <Button
                  variant="contained"
                  startIcon={<Plus size={20} />}
                  onClick={() => navigate('/admin/train-register')}
                  sx={{
                    background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                    '&:hover': {
                      background: 'linear-gradient(135deg, #1d4ed8 0%, #7c3aed 100%)',
                      transform: 'translateY(-2px)',
                      boxShadow: '0 8px 20px rgba(37, 99, 235, 0.4)',
                    },
                    transition: 'all 0.2s',
                  }}
                >
                  Add New Train
                </Button>
              </Box>

              {/* Table */}
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow
                      sx={{
                        background: 'linear-gradient(135deg, rgba(37, 99, 235, 0.05) 0%, rgba(139, 92, 246, 0.05) 100%)',
                      }}
                    >
                      <TableCell><strong>Train Number</strong></TableCell>
                      <TableCell><strong>Train Name</strong></TableCell>
                      <TableCell><strong>Route</strong></TableCell>
                      <TableCell><strong>Schedule</strong></TableCell>
                      <TableCell><strong>Duration</strong></TableCell>
                      <TableCell align="center"><strong>Actions</strong></TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {filteredTrains.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} align="center" sx={{ py: 8 }}>
                          <TrainIcon size={48} color="#d1d5db" />
                          <Typography color="text.secondary" sx={{ mt: 2 }}>
                            No trains found
                          </Typography>
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredTrains.map((train, index) => (
                        <TableRow
                          key={train.id}
                          sx={{
                            '&:hover': {
                              bgcolor: 'rgba(37, 99, 235, 0.03)',
                            },
                            animation: `fadeIn 0.3s ease-out ${index * 0.05}s both`,
                            '@keyframes fadeIn': {
                              from: { opacity: 0 },
                              to: { opacity: 1 },
                            },
                          }}
                        >
                          <TableCell>
                            <Chip 
                              label={train.trainNumber} 
                              size="small"
                              sx={{
                                background: 'linear-gradient(135deg, rgba(37, 99, 235, 0.1) 0%, rgba(139, 92, 246, 0.1) 100%)',
                                color: '#2563eb',
                              }}
                            />
                          </TableCell>
                          <TableCell>{train.trainName}</TableCell>
                          <TableCell>
                            <Typography variant="body2">
                              {train.origin} → {train.destination}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2">
                              {train.departureTime} - {train.arrivalTime}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Chip 
                              label={train.duration} 
                              size="small" 
                              variant="outlined"
                              sx={{ borderColor: '#06b6d4', color: '#06b6d4' }}
                            />
                          </TableCell>
                          <TableCell align="center">
                            <Box sx={{ display: 'flex', gap: 1, justifyContent: 'center' }}>
                              <IconButton
                                onClick={() => handleEdit(train)}
                                size="small"
                                sx={{
                                  color: 'primary.main',
                                  '&:hover': {
                                    bgcolor: 'rgba(37, 99, 235, 0.1)',
                                    transform: 'scale(1.1)',
                                  },
                                  transition: 'all 0.2s',
                                }}
                              >
                                <Edit size={18} />
                              </IconButton>
                              <IconButton
                                onClick={() => handleDeleteClick(train)}
                                size="small"
                                sx={{
                                  color: 'error.main',
                                  '&:hover': {
                                    bgcolor: 'rgba(239, 68, 68, 0.1)',
                                    transform: 'scale(1.1)',
                                  },
                                  transition: 'all 0.2s',
                                }}
                              >
                                <Trash2 size={18} />
                              </IconButton>
                            </Box>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Box>
      </Box>

      {/* Delete Confirmation Dialog */}
      <Dialog 
        open={showDeleteDialog} 
        onClose={() => setShowDeleteDialog(false)}
        PaperProps={{
          sx: {
            borderRadius: 3,
            maxWidth: 400,
          }
        }}
      >
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Box
            sx={{
              width: 48,
              height: 48,
              borderRadius: 2,
              background: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Trash2 size={24} color="white" />
          </Box>
          Confirm Delete
        </DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete train <strong>{trainToDelete?.trainName}</strong>? 
            This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ p: 2.5, gap: 1 }}>
          <Button
            onClick={() => {
              setShowDeleteDialog(false);
              setTrainToDelete(null);
            }}
            variant="outlined"
            sx={{ borderColor: 'rgba(107, 114, 128, 0.3)' }}
          >
            Cancel
          </Button>
          <Button
            onClick={confirmDelete}
            variant="contained"
            sx={{
              background: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
              '&:hover': {
                background: 'linear-gradient(135deg, #dc2626 0%, #b91c1c 100%)',
              }
            }}
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
