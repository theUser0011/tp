import { AdminSidebar } from '../../components/AdminSidebar';
import { Header } from '../../components/Header';
import { Train, MapPin, Ticket, DollarSign, TrendingUp } from 'lucide-react';
import { Box, Grid, Card, CardContent, Typography, Avatar, LinearProgress, Chip } from '@mui/material';

export const AdminDashboard = () => {
  const stats = [
    {
      title: 'Total Trains',
      value: '156',
      change: '+12 this month',
      icon: Train,
      color: '#2563eb',
      bgcolor: '#eff6ff',
      gradient: 'linear-gradient(135deg, #2563eb 0%, #4f46e5 100%)',
    },
    {
      title: 'Active Routes',
      value: '89',
      change: '+5 new routes',
      icon: MapPin,
      color: '#10b981',
      bgcolor: '#ecfdf5',
      gradient: 'linear-gradient(135deg, #10b981 0%, #14b8a6 100%)',
    },
    {
      title: 'Total Bookings',
      value: '12,458',
      change: '+18% this month',
      icon: Ticket,
      color: '#8b5cf6',
      bgcolor: '#f5f3ff',
      gradient: 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)',
    },
    {
      title: 'Revenue',
      value: '$89,247',
      change: '+24% this month',
      icon: DollarSign,
      color: '#f59e0b',
      bgcolor: '#fffbeb',
      gradient: 'linear-gradient(135deg, #f59e0b 0%, #f97316 100%)',
    },
  ];

  const recentBookings = [
    { id: 'BK001', train: 'Rajdhani Express', customer: 'John Doe', date: '2025-11-05', amount: '$45' },
    { id: 'BK002', train: 'Shatabdi Express', customer: 'Jane Smith', date: '2025-11-06', amount: '$38' },
    { id: 'BK003', train: 'Duronto Express', customer: 'Mike Johnson', date: '2025-11-07', amount: '$52' },
    { id: 'BK004', train: 'Garib Rath', customer: 'Sarah Williams', date: '2025-11-08', amount: '$28' },
    { id: 'BK005', train: 'Intercity Express', customer: 'David Brown', date: '2025-11-09', amount: '$35' },
  ];

  const popularRoutes = [
    { route: 'New Delhi → Mumbai', bookings: 2145, revenue: '$42,890', percentage: 85, color: '#2563eb' },
    { route: 'Mumbai → Bangalore', bookings: 1876, revenue: '$37,520', percentage: 75, color: '#8b5cf6' },
    { route: 'Delhi → Kolkata', bookings: 1632, revenue: '$32,640', percentage: 65, color: '#06b6d4' },
    { route: 'Chennai → Hyderabad', bookings: 1421, revenue: '$28,420', percentage: 57, color: '#10b981' },
  ];

  return (
    <Box sx={{ display: 'flex', bgcolor: 'background.default', minHeight: '100vh' }}>
      <AdminSidebar />
      <Box sx={{ flex: 1, ml: '280px' }}>
        <Header title="Admin Dashboard" />
        
        <Box sx={{ p: 4 }}>
          {/* Stats Grid */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Grid 
                  item 
                  xs={12} 
                  sm={6} 
                  lg={3} 
                  key={index}
                  sx={{
                    animation: `fadeInUp 0.5s ease-out ${index * 0.1}s both`,
                    '@keyframes fadeInUp': {
                      from: {
                        opacity: 0,
                        transform: 'translateY(20px)',
                      },
                      to: {
                        opacity: 1,
                        transform: 'translateY(0)',
                      },
                    },
                  }}
                >
                  <Card
                    elevation={0}
                    sx={{
                      border: '1px solid',
                      borderColor: 'rgba(37, 99, 235, 0.1)',
                      background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
                      position: 'relative',
                      overflow: 'hidden',
                      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                      '&:hover': {
                        boxShadow: '0 20px 40px -10px rgba(37, 99, 235, 0.25)',
                        transform: 'translateY(-8px)',
                        borderColor: stat.color,
                      },
                      '&::before': {
                        content: '""',
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        right: 0,
                        height: '4px',
                        background: stat.gradient,
                      }
                    }}
                  >
                    <CardContent>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                        <Avatar
                          sx={{
                            background: stat.gradient,
                            width: 56,
                            height: 56,
                            boxShadow: `0 8px 16px ${stat.color}40`,
                          }}
                        >
                          <Icon size={28} color="white" />
                        </Avatar>
                      </Box>
                      <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
                        {stat.value}
                      </Typography>
                      <Typography color="text.secondary" sx={{ mb: 1 }}>
                        {stat.title}
                      </Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <TrendingUp size={14} color="#10b981" />
                        <Typography variant="caption" sx={{ color: 'success.main' }}>
                          {stat.change}
                        </Typography>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              );
            })}
          </Grid>

          <Grid container spacing={3}>
            {/* Recent Bookings */}
            <Grid item xs={12} lg={6}>
              <Card 
                elevation={0} 
                sx={{ 
                  border: '1px solid', 
                  borderColor: 'rgba(37, 99, 235, 0.1)',
                  background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
                  transition: 'all 0.3s',
                  '&:hover': {
                    boxShadow: '0 10px 25px -5px rgba(37, 99, 235, 0.15)',
                  }
                }}
              >
                <CardContent>
                  <Typography 
                    variant="h6" 
                    sx={{ 
                      mb: 3,
                      background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                      backgroundClip: 'text',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                    }}
                  >
                    Recent Bookings
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    {recentBookings.map((booking, idx) => (
                      <Box
                        key={booking.id}
                        sx={{
                          p: 2,
                          bgcolor: 'grey.50',
                          borderRadius: 2,
                          borderLeft: '3px solid',
                          borderLeftColor: 'primary.main',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          transition: 'all 0.2s',
                          animation: `fadeIn 0.3s ease-out ${idx * 0.1}s both`,
                          '&:hover': {
                            bgcolor: 'white',
                            transform: 'translateX(4px)',
                            boxShadow: '0 4px 12px rgba(37, 99, 235, 0.1)',
                          },
                          '@keyframes fadeIn': {
                            from: { opacity: 0 },
                            to: { opacity: 1 },
                          },
                        }}
                      >
                        <Box>
                          <Typography sx={{ fontWeight: 600, mb: 0.5 }}>
                            {booking.train}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {booking.customer} • {booking.date}
                          </Typography>
                        </Box>
                        <Box sx={{ textAlign: 'right' }}>
                          <Typography 
                            sx={{ 
                              fontWeight: 600,
                              background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                              backgroundClip: 'text',
                              WebkitBackgroundClip: 'text',
                              WebkitTextFillColor: 'transparent',
                            }}
                          >
                            {booking.amount}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {booking.id}
                          </Typography>
                        </Box>
                      </Box>
                    ))}
                  </Box>
                </CardContent>
              </Card>
            </Grid>

            {/* Popular Routes */}
            <Grid item xs={12} lg={6}>
              <Card 
                elevation={0} 
                sx={{ 
                  border: '1px solid', 
                  borderColor: 'rgba(37, 99, 235, 0.1)',
                  background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
                  transition: 'all 0.3s',
                  '&:hover': {
                    boxShadow: '0 10px 25px -5px rgba(37, 99, 235, 0.15)',
                  }
                }}
              >
                <CardContent>
                  <Typography 
                    variant="h6" 
                    sx={{ 
                      mb: 3,
                      background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                      backgroundClip: 'text',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                    }}
                  >
                    Popular Routes
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                    {popularRoutes.map((route, index) => (
                      <Box 
                        key={index}
                        sx={{
                          animation: `fadeIn 0.3s ease-out ${index * 0.15}s both`,
                          '@keyframes fadeIn': {
                            from: { opacity: 0 },
                            to: { opacity: 1 },
                          },
                        }}
                      >
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                          <Typography sx={{ fontWeight: 600 }}>
                            {route.route}
                          </Typography>
                          <Chip
                            label={`${route.bookings} bookings`}
                            size="small"
                            sx={{ 
                              background: `linear-gradient(135deg, ${route.color}20 0%, ${route.color}30 100%)`,
                              color: route.color,
                              border: '1px solid',
                              borderColor: `${route.color}40`,
                            }}
                          />
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                          <LinearProgress
                            variant="determinate"
                            value={route.percentage}
                            sx={{ 
                              flex: 1, 
                              height: 8, 
                              borderRadius: 4,
                              bgcolor: `${route.color}15`,
                              '& .MuiLinearProgress-bar': {
                                background: `linear-gradient(90deg, ${route.color} 0%, ${route.color}CC 100%)`,
                                borderRadius: 4,
                              }
                            }}
                          />
                          <Typography 
                            sx={{ 
                              fontWeight: 600, 
                              minWidth: 80, 
                              textAlign: 'right',
                              color: route.color,
                            }}
                          >
                            {route.revenue}
                          </Typography>
                        </Box>
                      </Box>
                    ))}
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </Box>
  );
};
