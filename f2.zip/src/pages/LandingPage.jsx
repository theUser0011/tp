import { useNavigate } from 'react-router-dom';
import { CheckCircle, Train, Clock, Shield, CreditCard, Search, Ticket, MapPin, Star } from 'lucide-react';
import { Box, Container, Typography, Button, Card, CardContent, Avatar, AppBar, Toolbar, Grid, Chip } from '@mui/material';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export const LandingPage = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: CheckCircle,
      title: 'Instant Booking Confirmation',
      description: 'Get your tickets confirmed instantly with real-time seat availability',
      color: '#2563eb',
    },
    {
      icon: Clock,
      title: 'Live Train Status',
      description: 'Track your train in real-time and get updates on delays and arrivals',
      color: '#10b981',
    },
    {
      icon: Shield,
      title: 'Easy Cancellations',
      description: 'Cancel your tickets hassle-free with quick refund processing',
      color: '#f59e0b',
    },
    {
      icon: CreditCard,
      title: 'Secure Payments',
      description: 'Multiple payment options with bank-grade security',
      color: '#8b5cf6',
    },
  ];

  const steps = [
    {
      icon: Search,
      title: 'Search Trains',
      description: 'Enter your journey details',
      color: '#2563eb',
    },
    {
      icon: Ticket,
      title: 'Book Tickets',
      description: 'Choose your preferred train',
      color: '#10b981',
    },
    {
      icon: MapPin,
      title: 'Travel Smart',
      description: 'Enjoy your journey',
      color: '#8b5cf6',
    },
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      review: 'Easy to use and reliable. Booked my tickets in just 2 minutes!',
      rating: 5,
      avatar: 'SJ',
    },
    {
      name: 'Mike Chen',
      review: 'Best railway booking platform. The live tracking feature is amazing.',
      rating: 5,
      avatar: 'MC',
    },
    {
      name: 'Priya Sharma',
      review: 'Great customer service and hassle-free cancellations.',
      rating: 5,
      avatar: 'PS',
    },
  ];

  return (
    <Box sx={{ bgcolor: 'background.default' }}>
      {/* Navigation */}
      <AppBar position="sticky" color="default" elevation={1} sx={{ bgcolor: 'background.paper' }}>
        <Toolbar>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flex: 1 }}>
            <Train size={32} color="#2563eb" />
            <Typography variant="h6" sx={{ color: 'primary.main', fontWeight: 700 }}>
              RailwayBooking
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 2 }}>
            <Button onClick={() => navigate('/login')} color="inherit">
              Login
            </Button>
            <Button onClick={() => navigate('/register')} variant="contained" color="primary">
              Sign Up
            </Button>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Hero Section */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #2563eb 0%, #1e40af 100%)',
          color: 'white',
          py: 12,
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        <Box
          sx={{
            position: 'absolute',
            inset: 0,
            opacity: 0.2,
            backgroundImage: 'url(/hero.png)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
          <Grid container spacing={4} alignItems="center">
            <Grid item xs={12} md={7}>
              <Chip label="✨ Trusted by 10M+ Travelers" sx={{ mb: 3, bgcolor: 'rgba(255,255,255,0.2)', color: 'white' }} />
              <Typography variant="h2" sx={{ fontWeight: 800, mb: 3, color: 'white' }}>
                Book Your Train Tickets Easily & Quickly
              </Typography>
              <Typography variant="h6" sx={{ mb: 4, color: 'rgba(255,255,255,0.9)', lineHeight: 1.6 }}>
                Experience seamless railway booking with real-time availability, instant confirmation, and secure payments
              </Typography>
              <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                <Button
                  size="large"
                  variant="contained"
                  onClick={() => navigate('/customer/search-trains')}
                  sx={{
                    bgcolor: 'white',
                    color: 'primary.main',
                    px: 4,
                    py: 1.5,
                    fontSize: '1.1rem',
                    '&:hover': { bgcolor: 'grey.100', transform: 'translateY(-2px)', boxShadow: 4 },
                    transition: 'all 0.3s',
                  }}
                >
                  Book Now
                </Button>
                <Button
                  size="large"
                  variant="outlined"
                  onClick={() => navigate('/login')}
                  sx={{
                    borderColor: 'white',
                    color: 'white',
                    px: 4,
                    py: 1.5,
                    fontSize: '1.1rem',
                    '&:hover': {
                      borderColor: 'white',
                      bgcolor: 'rgba(255,255,255,0.1)',
                      transform: 'translateY(-2px)',
                    },
                    transition: 'all 0.3s',
                  }}
                >
                  Login
                </Button>
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>

      {/* Features Section */}
      <Box sx={{ py: 10, bgcolor: 'grey.50' }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 8 }}>
            <Typography variant="h3" sx={{ fontWeight: 700, mb: 2 }}>
              Why Choose Us
            </Typography>
            <Typography variant="h6" color="text.secondary" sx={{ maxWidth: 600, mx: 'auto' }}>
              We provide the best railway booking experience with cutting-edge features
            </Typography>
          </Box>
          <Grid container spacing={4}>
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Grid item xs={12} sm={6} lg={3} key={index}>
                  <Card
                    elevation={0}
                    sx={{
                      height: '100%',
                      transition: 'all 0.3s',
                      '&:hover': {
                        transform: 'translateY(-8px)',
                        boxShadow: 6,
                      },
                      border: '1px solid',
                      borderColor: 'divider',
                    }}
                  >
                    <CardContent sx={{ p: 4 }}>
                      <Avatar
                        sx={{
                          bgcolor: `${feature.color}15`,
                          width: 56,
                          height: 56,
                          mb: 3,
                        }}
                      >
                        <Icon size={28} color={feature.color} />
                      </Avatar>
                      <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>
                        {feature.title}
                      </Typography>
                      <Typography color="text.secondary">{feature.description}</Typography>
                    </CardContent>
                  </Card>
                </Grid>
              );
            })}
          </Grid>
        </Container>
      </Box>

      {/* How It Works Section */}
      <Box sx={{ py: 10, bgcolor: 'background.paper' }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 8 }}>
            <Typography variant="h3" sx={{ fontWeight: 700, mb: 2 }}>
              How It Works
            </Typography>
            <Typography variant="h6" color="text.secondary" sx={{ maxWidth: 600, mx: 'auto' }}>
              Book your tickets in three simple steps
            </Typography>
          </Box>
          <Grid container spacing={6}>
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <Grid item xs={12} md={4} key={index}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Box sx={{ position: 'relative', display: 'inline-block', mb: 3 }}>
                      <Avatar
                        sx={{
                          bgcolor: `${step.color}15`,
                          width: 80,
                          height: 80,
                        }}
                      >
                        <Icon size={36} color={step.color} />
                      </Avatar>
                      <Avatar
                        sx={{
                          position: 'absolute',
                          top: -8,
                          right: -8,
                          bgcolor: step.color,
                          width: 32,
                          height: 32,
                          fontSize: '1rem',
                          fontWeight: 700,
                        }}
                      >
                        {index + 1}
                      </Avatar>
                    </Box>
                    <Typography variant="h5" sx={{ mb: 2, fontWeight: 600 }}>
                      {step.title}
                    </Typography>
                    <Typography color="text.secondary">{step.description}</Typography>
                  </Box>
                </Grid>
              );
            })}
          </Grid>
        </Container>
      </Box>

      {/* Testimonials Section */}
      <Box sx={{ py: 10, bgcolor: 'grey.50' }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 8 }}>
            <Typography variant="h3" sx={{ fontWeight: 700, mb: 2 }}>
              What Our Users Say
            </Typography>
            <Typography variant="h6" color="text.secondary" sx={{ maxWidth: 600, mx: 'auto' }}>
              Join thousands of satisfied travelers
            </Typography>
          </Box>
          <Grid container spacing={4}>
            {testimonials.map((testimonial, index) => (
              <Grid item xs={12} md={4} key={index}>
                <Card elevation={0} sx={{ height: '100%', border: '1px solid', borderColor: 'divider' }}>
                  <CardContent sx={{ p: 4 }}>
                    <Box sx={{ display: 'flex', gap: 0.5, mb: 3 }}>
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} size={18} fill="#fbbf24" color="#fbbf24" />
                      ))}
                    </Box>
                    <Typography sx={{ mb: 3, fontStyle: 'italic', color: 'text.secondary' }}>
                      "{testimonial.review}"
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                      <Avatar sx={{ bgcolor: 'primary.main' }}>{testimonial.avatar}</Avatar>
                      <Box>
                        <Typography sx={{ fontWeight: 600 }}>{testimonial.name}</Typography>
                        <Typography variant="caption" color="text.secondary">
                          Verified Traveler
                        </Typography>
                      </Box>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* CTA Section */}
      <Box
        sx={{
          py: 10,
          background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
          color: 'white',
        }}
      >
        <Container maxWidth="md" sx={{ textAlign: 'center' }}>
          <Typography variant="h3" sx={{ fontWeight: 700, mb: 2, color: 'white' }}>
            Start Your Journey Today
          </Typography>
          <Typography variant="h6" sx={{ mb: 4, color: 'rgba(255,255,255,0.9)' }}>
            Create your account and get exclusive deals on train bookings
          </Typography>
          <Button
            size="large"
            variant="contained"
            onClick={() => navigate('/register')}
            sx={{
              bgcolor: 'white',
              color: 'primary.main',
              px: 5,
              py: 2,
              fontSize: '1.1rem',
              '&:hover': { bgcolor: 'grey.100', transform: 'translateY(-2px)', boxShadow: 6 },
              transition: 'all 0.3s',
            }}
          >
            Create Account
          </Button>
        </Container>
      </Box>

      {/* Footer */}
      <Box sx={{ py: 6, bgcolor: 'grey.900', color: 'white' }}>
        <Container maxWidth="lg">
          <Grid container spacing={4}>
            <Grid item xs={12} md={3}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <Train size={28} />
                <Typography variant="h6" sx={{ fontWeight: 700 }}>
                  RailwayBooking
                </Typography>
              </Box>
              <Typography variant="body2" color="grey.400">
                Your trusted partner for railway travel
              </Typography>
            </Grid>
            <Grid item xs={6} md={3}>
              <Typography variant="h6" sx={{ mb: 2 }}>
                Quick Links
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                <Typography variant="body2" color="grey.400" sx={{ cursor: 'pointer', '&:hover': { color: 'white' } }}>
                  About Us
                </Typography>
                <Typography variant="body2" color="grey.400" sx={{ cursor: 'pointer', '&:hover': { color: 'white' } }}>
                  Contact
                </Typography>
                <Typography variant="body2" color="grey.400" sx={{ cursor: 'pointer', '&:hover': { color: 'white' } }}>
                  Careers
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={6} md={3}>
              <Typography variant="h6" sx={{ mb: 2 }}>
                Legal
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                <Typography variant="body2" color="grey.400" sx={{ cursor: 'pointer', '&:hover': { color: 'white' } }}>
                  Terms of Service
                </Typography>
                <Typography variant="body2" color="grey.400" sx={{ cursor: 'pointer', '&:hover': { color: 'white' } }}>
                  Privacy Policy
                </Typography>
                <Typography variant="body2" color="grey.400" sx={{ cursor: 'pointer', '&:hover': { color: 'white' } }}>
                  Refund Policy
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={12} md={3}>
              <Typography variant="h6" sx={{ mb: 2 }}>
                Support
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                <Typography variant="body2" color="grey.400" sx={{ cursor: 'pointer', '&:hover': { color: 'white' } }}>
                  Help Center
                </Typography>
                <Typography variant="body2" color="grey.400" sx={{ cursor: 'pointer', '&:hover': { color: 'white' } }}>
                  FAQs
                </Typography>
                <Typography variant="body2" color="grey.400" sx={{ cursor: 'pointer', '&:hover': { color: 'white' } }}>
                  Contact Support
                </Typography>
              </Box>
            </Grid>
          </Grid>
          <Box sx={{ borderTop: '1px solid', borderColor: 'grey.800', mt: 6, pt: 4, textAlign: 'center' }}>
            <Typography variant="body2" color="grey.500">
              © 2025 RailwayBooking. All rights reserved.
            </Typography>
          </Box>
        </Container>
      </Box>
    </Box>
  );
};
