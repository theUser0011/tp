import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CustomerSidebar } from '../../components/CustomerSidebar';
import { Header } from '../../components/Header';
import { Search, Train, ArrowRight, Calendar, MapPin, Clock, TrendingUp } from 'lucide-react';
import { toast } from 'react-toastify';
import {
  Box,
  Grid,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Chip,
  InputAdornment,
  Autocomplete,
} from '@mui/material';

// Popular Indian railway stations
const indianStations = [
  'New Delhi',
  'Mumbai Central',
  'Chennai Central',
  'Kolkata',
  'Bangalore City',
  'Hyderabad',
  'Ahmedabad',
  'Pune',
  'Jaipur',
  'Lucknow',
  'Kanpur',
  'Nagpur',
  'Indore',
  'Bhopal',
  'Patna',
  'Vadodara',
  'Agra',
  'Varanasi',
  'Surat',
  'Chandigarh',
  'Sealdah',
  'Howrah',
  'Goa',
  'Coimbatore',
  'Kochi',
  'Thiruvananthapuram',
  'Visakhapatnam',
  'Vijayawada',
  'Mysore',
  'Mangalore',
];

export const TrainSearch = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useState({
    origin: '',
    destination: '',
    travelDate: '',
  });
  const [searchResults, setSearchResults] = useState([]);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = (e) => {
    e.preventDefault();

    if (!searchParams.origin || !searchParams.destination || !searchParams.travelDate) {
      toast.error('Please fill all fields');
      return;
    }

    if (searchParams.origin === searchParams.destination) {
      toast.error('Origin and destination cannot be the same');
      return;
    }

    let trains = JSON.parse(localStorage.getItem('trains') || '[]');
    
    if (trains.length === 0) {
      trains = [
        {
          id: 1,
          trainNumber: '12301',
          trainName: 'Rajdhani Express',
          origin: 'New Delhi',
          destination: 'Mumbai Central',
          departureTime: '16:55',
          arrivalTime: '08:35',
          duration: '15h 40m',
          classes: {
            sleeper: { available: true, price: '28' },
            ac3Tier: { available: true, price: '45' },
            ac2Tier: { available: true, price: '65' },
            ac1Tier: { available: true, price: '95' },
          },
        },
        {
          id: 2,
          trainNumber: '12002',
          trainName: 'Shatabdi Express',
          origin: 'New Delhi',
          destination: 'Chandigarh',
          departureTime: '07:40',
          arrivalTime: '10:50',
          duration: '3h 10m',
          classes: {
            ac3Tier: { available: true, price: '25' },
            ac2Tier: { available: true, price: '38' },
          },
        },
        {
          id: 3,
          trainNumber: '12259',
          trainName: 'Duronto Express',
          origin: 'Sealdah',
          destination: 'New Delhi',
          departureTime: '16:50',
          arrivalTime: '10:05',
          duration: '17h 15m',
          classes: {
            sleeper: { available: true, price: '32' },
            ac3Tier: { available: true, price: '52' },
            ac2Tier: { available: true, price: '72' },
          },
        },
      ];
    }

    const results = trains.filter(
      (train) =>
        train.origin.toLowerCase().includes(searchParams.origin.toLowerCase()) &&
        train.destination.toLowerCase().includes(searchParams.destination.toLowerCase())
    );

    setSearchResults(results);
    setHasSearched(true);

    if (results.length === 0) {
      toast.info('No trains found for the selected route');
    } else {
      toast.success(`Found ${results.length} train(s)`);
    }
  };

  const handleBookNow = (train) => {
    navigate('/customer/book-ticket', { state: { train, travelDate: searchParams.travelDate } });
  };

  return (
    <Box sx={{ display: 'flex', bgcolor: 'background.default', minHeight: '100vh' }}>
      <CustomerSidebar />
      <Box sx={{ flex: 1, ml: '280px' }}>
        <Header title="Search Trains" />
        
        <Box sx={{ p: 4 }}>
          {/* Search Form */}
          <Card 
            elevation={0} 
            sx={{ 
              mb: 4, 
              border: '1px solid',
              borderColor: 'rgba(37, 99, 235, 0.2)',
              background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
              boxShadow: '0 10px 25px -5px rgba(37, 99, 235, 0.1)',
              transition: 'all 0.3s',
              '&:hover': {
                boxShadow: '0 20px 40px -10px rgba(37, 99, 235, 0.2)',
                transform: 'translateY(-2px)',
              }
            }}
          >
            <CardContent sx={{ p: 4 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                <Box
                  sx={{
                    width: 48,
                    height: 48,
                    borderRadius: 2,
                    background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: '0 4px 12px rgba(37, 99, 235, 0.3)',
                  }}
                >
                  <Search size={24} color="white" />
                </Box>
                <Box>
                  <Typography variant="h6">Search Your Train</Typography>
                  <Typography variant="body2" color="text.secondary">
                    Enter journey details to find available trains
                  </Typography>
                </Box>
              </Box>

              <Box component="form" onSubmit={handleSearch}>
                <Grid container spacing={3}>
                  <Grid item xs={12} md={4}>
                    <Autocomplete
                      freeSolo
                      options={indianStations}
                      value={searchParams.origin}
                      onChange={(event, newValue) => {
                        setSearchParams({ ...searchParams, origin: newValue || '' });
                      }}
                      onInputChange={(event, newInputValue) => {
                        setSearchParams({ ...searchParams, origin: newInputValue });
                      }}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="From Station"
                          placeholder="Select origin station"
                          required
                          InputProps={{
                            ...params.InputProps,
                            startAdornment: (
                              <>
                                <InputAdornment position="start">
                                  <MapPin size={20} color="#2563eb" />
                                </InputAdornment>
                                {params.InputProps.startAdornment}
                              </>
                            ),
                          }}
                          sx={{
                            '& .MuiOutlinedInput-root': {
                              '&:hover fieldset': {
                                borderColor: '#2563eb',
                              },
                              '&.Mui-focused fieldset': {
                                borderColor: '#2563eb',
                                borderWidth: 2,
                              }
                            }
                          }}
                        />
                      )}
                      PaperProps={{
                        sx: {
                          mt: 1,
                          boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)',
                          borderRadius: 2,
                          '& .MuiAutocomplete-listbox': {
                            '& .MuiAutocomplete-option': {
                              transition: 'all 0.2s',
                              '&:hover': {
                                background: 'linear-gradient(135deg, rgba(37, 99, 235, 0.08) 0%, rgba(139, 92, 246, 0.08) 100%)',
                              },
                              '&[aria-selected="true"]': {
                                background: 'linear-gradient(135deg, rgba(37, 99, 235, 0.15) 0%, rgba(139, 92, 246, 0.15) 100%)',
                              }
                            }
                          }
                        }
                      }}
                    />
                  </Grid>

                  <Grid item xs={12} md={4}>
                    <Autocomplete
                      freeSolo
                      options={indianStations}
                      value={searchParams.destination}
                      onChange={(event, newValue) => {
                        setSearchParams({ ...searchParams, destination: newValue || '' });
                      }}
                      onInputChange={(event, newInputValue) => {
                        setSearchParams({ ...searchParams, destination: newInputValue });
                      }}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="To Station"
                          placeholder="Select destination station"
                          required
                          InputProps={{
                            ...params.InputProps,
                            startAdornment: (
                              <>
                                <InputAdornment position="start">
                                  <MapPin size={20} color="#8b5cf6" />
                                </InputAdornment>
                                {params.InputProps.startAdornment}
                              </>
                            ),
                          }}
                          sx={{
                            '& .MuiOutlinedInput-root': {
                              '&:hover fieldset': {
                                borderColor: '#8b5cf6',
                              },
                              '&.Mui-focused fieldset': {
                                borderColor: '#8b5cf6',
                                borderWidth: 2,
                              }
                            }
                          }}
                        />
                      )}
                      PaperProps={{
                        sx: {
                          mt: 1,
                          boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)',
                          borderRadius: 2,
                          '& .MuiAutocomplete-listbox': {
                            '& .MuiAutocomplete-option': {
                              transition: 'all 0.2s',
                              '&:hover': {
                                background: 'linear-gradient(135deg, rgba(37, 99, 235, 0.08) 0%, rgba(139, 92, 246, 0.08) 100%)',
                              },
                              '&[aria-selected="true"]': {
                                background: 'linear-gradient(135deg, rgba(37, 99, 235, 0.15) 0%, rgba(139, 92, 246, 0.15) 100%)',
                              }
                            }
                          }
                        }
                      }}
                    />
                  </Grid>

                  <Grid item xs={12} md={4}>
                    <TextField
                      fullWidth
                      label="Travel Date"
                      type="date"
                      value={searchParams.travelDate}
                      onChange={(e) => setSearchParams({ ...searchParams, travelDate: e.target.value })}
                      required
                      InputLabelProps={{
                        shrink: true,
                      }}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <Calendar size={20} color="#06b6d4" />
                          </InputAdornment>
                        ),
                      }}
                      inputProps={{
                        min: new Date().toISOString().split('T')[0],
                      }}
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          '&:hover fieldset': {
                            borderColor: '#06b6d4',
                          },
                          '&.Mui-focused fieldset': {
                            borderColor: '#06b6d4',
                            borderWidth: 2,
                          }
                        }
                      }}
                    />
                  </Grid>
                </Grid>

                <Button
                  fullWidth
                  size="large"
                  type="submit"
                  variant="contained"
                  startIcon={<Search size={20} />}
                  sx={{
                    mt: 3,
                    py: 1.5,
                    textTransform: 'none',
                    background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                    boxShadow: '0 4px 12px rgba(37, 99, 235, 0.3)',
                    '&:hover': {
                      background: 'linear-gradient(135deg, #1d4ed8 0%, #7c3aed 100%)',
                      boxShadow: '0 8px 20px rgba(37, 99, 235, 0.4)',
                      transform: 'translateY(-2px)',
                    },
                    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                  }}
                >
                  Search Trains
                </Button>
              </Box>
            </CardContent>
          </Card>

          {/* Search Results */}
          {hasSearched && (
            <Box>
              {searchResults.length === 0 ? (
                <Card 
                  elevation={0} 
                  sx={{ 
                    border: '1px solid', 
                    borderColor: 'divider', 
                    textAlign: 'center', 
                    py: 8,
                    background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
                  }}
                >
                  <Train size={48} color="#d1d5db" />
                  <Typography variant="h6" sx={{ mt: 2, mb: 1 }}>
                    No Trains Found
                  </Typography>
                  <Typography color="text.secondary">
                    Try searching with different stations or dates
                  </Typography>
                </Card>
              ) : (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <TrendingUp size={20} color="#10b981" />
                    <Typography variant="h6" color="text.secondary">
                      Found {searchResults.length} train{searchResults.length > 1 ? 's' : ''} for your journey
                    </Typography>
                  </Box>
                  
                  {searchResults.map((train) => (
                    <Card
                      key={train.id}
                      elevation={0}
                      sx={{
                        border: '1px solid',
                        borderColor: 'rgba(37, 99, 235, 0.2)',
                        background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
                        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                        '&:hover': {
                          boxShadow: '0 20px 40px -10px rgba(37, 99, 235, 0.25)',
                          transform: 'translateY(-4px)',
                          borderColor: 'rgba(37, 99, 235, 0.4)',
                        },
                      }}
                    >
                      <CardContent sx={{ p: 3 }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
                          <Box>
                            <Typography 
                              variant="h6" 
                              sx={{ 
                                mb: 0.5,
                                background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                                backgroundClip: 'text',
                                WebkitBackgroundClip: 'text',
                                WebkitTextFillColor: 'transparent',
                              }}
                            >
                              {train.trainName}
                            </Typography>
                            <Typography color="text.secondary">
                              Train No: {train.trainNumber}
                            </Typography>
                          </Box>
                          <Chip
                            icon={<Clock size={16} />}
                            label={train.duration}
                            sx={{
                              background: 'linear-gradient(135deg, #06b6d4 0%, #3b82f6 100%)',
                              color: 'white',
                            }}
                          />
                        </Box>

                        <Grid container spacing={2} alignItems="center" sx={{ mb: 3 }}>
                          <Grid item xs={5}>
                            <Typography variant="caption" color="text.secondary">
                              Departure
                            </Typography>
                            <Typography variant="h6">
                              {train.departureTime}
                            </Typography>
                            <Typography color="text.secondary">
                              {train.origin}
                            </Typography>
                          </Grid>
                          <Grid item xs={2} sx={{ textAlign: 'center' }}>
                            <ArrowRight color="#6b7280" />
                          </Grid>
                          <Grid item xs={5} sx={{ textAlign: 'right' }}>
                            <Typography variant="caption" color="text.secondary">
                              Arrival
                            </Typography>
                            <Typography variant="h6">
                              {train.arrivalTime}
                            </Typography>
                            <Typography color="text.secondary">
                              {train.destination}
                            </Typography>
                          </Grid>
                        </Grid>

                        <Box
                          sx={{
                            borderTop: '1px solid',
                            borderColor: 'rgba(37, 99, 235, 0.1)',
                            pt: 2,
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            flexWrap: 'wrap',
                            gap: 2,
                          }}
                        >
                          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                            {train.classes?.sleeper?.available && (
                              <Chip
                                label={`Sleeper: $${train.classes.sleeper.price}`}
                                size="small"
                                variant="outlined"
                                sx={{
                                  borderColor: '#2563eb',
                                  color: '#2563eb',
                                  '&:hover': {
                                    background: 'rgba(37, 99, 235, 0.08)',
                                  }
                                }}
                              />
                            )}
                            {train.classes?.ac3Tier?.available && (
                              <Chip
                                label={`AC 3-Tier: $${train.classes.ac3Tier.price}`}
                                size="small"
                                variant="outlined"
                                sx={{
                                  borderColor: '#8b5cf6',
                                  color: '#8b5cf6',
                                  '&:hover': {
                                    background: 'rgba(139, 92, 246, 0.08)',
                                  }
                                }}
                              />
                            )}
                            {train.classes?.ac2Tier?.available && (
                              <Chip
                                label={`AC 2-Tier: $${train.classes.ac2Tier.price}`}
                                size="small"
                                variant="outlined"
                                sx={{
                                  borderColor: '#06b6d4',
                                  color: '#06b6d4',
                                  '&:hover': {
                                    background: 'rgba(6, 182, 212, 0.08)',
                                  }
                                }}
                              />
                            )}
                            {train.classes?.ac1Tier?.available && (
                              <Chip
                                label={`AC 1st: $${train.classes.ac1Tier.price}`}
                                size="small"
                                variant="outlined"
                                sx={{
                                  borderColor: '#10b981',
                                  color: '#10b981',
                                  '&:hover': {
                                    background: 'rgba(16, 185, 129, 0.08)',
                                  }
                                }}
                              />
                            )}
                          </Box>
                          <Button
                            variant="contained"
                            onClick={() => handleBookNow(train)}
                            sx={{
                              textTransform: 'none',
                              px: 3,
                              background: 'linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)',
                              '&:hover': {
                                background: 'linear-gradient(135deg, #1d4ed8 0%, #7c3aed 100%)',
                                transform: 'scale(1.05)',
                              },
                              transition: 'all 0.2s',
                            }}
                          >
                            Book Now
                          </Button>
                        </Box>
                      </CardContent>
                    </Card>
                  ))}
                </Box>
              )}
            </Box>
          )}
        </Box>
      </Box>
    </Box>
  );
};
