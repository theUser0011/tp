import { useState } from 'react';
import { CustomerSidebar } from '../../components/CustomerSidebar';
import { Header } from '../../components/Header';
import { XCircle, AlertTriangle } from 'lucide-react';
import { toast } from 'react-toastify';

export const CancelTicket = () => {
  const [bookingId, setBookingId] = useState('');
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [bookingToCancel, setBookingToCancel] = useState(null);

  const handleSearch = (e) => {
    e.preventDefault();

    if (!bookingId.trim()) {
      toast.error('Please enter a booking ID');
      return;
    }

    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
    
    const booking = bookings.find(
      (b) => b.bookingId === bookingId && b.userId === currentUser.id
    );

    if (!booking) {
      toast.error('Booking not found or does not belong to you');
      return;
    }

    if (booking.status === 'cancelled') {
      toast.error('This booking is already cancelled');
      return;
    }

    setBookingToCancel(booking);
    setShowConfirmDialog(true);
  };

  const confirmCancellation = () => {
    const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
    const updatedBookings = bookings.map((b) =>
      b.id === bookingToCancel.id ? { ...b, status: 'cancelled' } : b
    );

    localStorage.setItem('bookings', JSON.stringify(updatedBookings));
    toast.success('Ticket cancelled successfully. Refund will be processed within 5-7 business days.');
    
    setShowConfirmDialog(false);
    setBookingToCancel(null);
    setBookingId('');
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <CustomerSidebar />
      <div className="flex-1 ml-64">
        <Header title="Cancel Ticket" />
        
        <div className="p-8">
          <div className="bg-white rounded-xl border border-gray-200 p-8 max-w-2xl mx-auto">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-red-100 rounded-lg">
                <XCircle className="text-red-600" size={24} />
              </div>
              <div>
                <h2>Cancel Your Ticket</h2>
                <p className="text-gray-600">Enter your booking ID to cancel</p>
              </div>
            </div>

            <form onSubmit={handleSearch} className="space-y-6">
              <div>
                <label className="block text-gray-700 mb-2">Booking ID</label>
                <input
                  type="text"
                  value={bookingId}
                  onChange={(e) => setBookingId(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., BK1234567890"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Search Booking
              </button>
            </form>

            <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-start gap-3">
                <AlertTriangle className="text-yellow-600 flex-shrink-0 mt-0.5" size={20} />
                <div className="text-xs text-yellow-800">
                  <p className="mb-2">Cancellation Policy:</p>
                  <ul className="space-y-1 ml-4 list-disc">
                    <li>Full refund for cancellations made 48+ hours before departure</li>
                    <li>50% refund for cancellations made 24-48 hours before departure</li>
                    <li>No refund for cancellations made less than 24 hours before departure</li>
                    <li>Refund will be processed within 5-7 business days</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation Dialog */}
      {showConfirmDialog && bookingToCancel && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-red-100 rounded-full">
                <XCircle className="text-red-600" size={24} />
              </div>
              <h3 className="text-gray-900">Confirm Cancellation</h3>
            </div>
            
            <div className="mb-6 p-4 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-500 mb-2">Booking Details:</p>
              <p className="text-gray-900 mb-1">{bookingToCancel.trainName}</p>
              <p className="text-gray-600 mb-1">
                {bookingToCancel.origin} → {bookingToCancel.destination}
              </p>
              <p className="text-gray-600">
                Date: {bookingToCancel.travelDate}
              </p>
            </div>

            <p className="text-gray-600 mb-6">
              Are you sure you want to cancel this booking? The refund will be processed according to our cancellation policy.
            </p>

            <div className="flex gap-3">
              <button
                onClick={confirmCancellation}
                className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                Cancel Ticket
              </button>
              <button
                onClick={() => {
                  setShowConfirmDialog(false);
                  setBookingToCancel(null);
                }}
                className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Keep Booking
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
