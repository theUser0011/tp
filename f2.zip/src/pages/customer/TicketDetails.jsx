import { useLocation, useNavigate } from 'react-router-dom';
import { CustomerSidebar } from '../../components/CustomerSidebar';
import { Header } from '../../components/Header';
import { CheckCircle, Printer, Download, Train } from 'lucide-react';

export const TicketDetails = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { booking } = location.state || {};

  if (!booking) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <CustomerSidebar />
        <div className="flex-1 ml-64">
          <Header title="Ticket Details" />
          <div className="p-8">
            <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
              <p className="text-gray-600">No booking details found.</p>
              <button
                onClick={() => navigate('/customer/booking-history')}
                className="mt-4 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                View Booking History
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <CustomerSidebar />
      <div className="flex-1 ml-64">
        <Header title="Ticket Details" />
        <div className="p-8">
          <div className="max-w-4xl mx-auto">
            {/* ✅ Success Message */}
            <div className="bg-green-50 border border-green-200 rounded-xl p-6 mb-6 flex items-center gap-4">
              <div className="p-3 bg-green-100 rounded-full">
                <CheckCircle className="text-green-600" size={32} />
              </div>
              <div>
                <h2 className="text-green-900 mb-1">Booking Confirmed!</h2>
                <p className="text-green-700">Your ticket has been booked successfully.</p>
              </div>
            </div>

            {/* ✅ Ticket Card */}
            <div className="bg-white rounded-xl border-2 border-blue-200 overflow-hidden mb-6">
              {/* Header */}
              <div className="bg-blue-600 text-white p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Train size={32} />
                    <div>
                      <h2 className="text-white mb-1">{booking.trainName}</h2>
                      <p className="text-blue-100">Train No: {booking.trainNumber}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-blue-100 mb-1">Booking ID</p>
                    <p className="text-white">{booking.bookingId}</p>
                  </div>
                </div>
              </div>

              {/* Journey Details */}
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-gray-900 mb-4">Journey Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">From</p>
                    <p className="text-gray-900 mb-1">{booking.origin}</p>
                    <p className="text-gray-600">{booking.departureTime}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">To</p>
                    <p className="text-gray-900 mb-1">{booking.destination}</p>
                    <p className="text-gray-600">{booking.arrivalTime}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Travel Date</p>
                    <p className="text-gray-900">{booking.travelDate}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Class</p>
                    <p className="text-gray-900">{booking.class}</p>
                  </div>
                </div>
              </div>

              {/* Passenger Details */}
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-gray-900 mb-4">Passenger Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Name</p>
                    <p className="text-gray-900">{booking.passengerName}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Age</p>
                    <p className="text-gray-900">{booking.passengerAge}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Gender</p>
                    <p className="text-gray-900">{booking.passengerGender}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Number of Seats</p>
                    <p className="text-gray-900">{booking.seats}</p>
                  </div>
                </div>
              </div>

              {/* Fare Details */}
              <div className="p-6 bg-gray-50">
                <h3 className="text-gray-900 mb-4">Fare Details</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Total Fare</span>
                    <span className="text-gray-900">${booking.fare.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between border-t border-gray-200 pt-2">
                    <span className="text-gray-900">Amount Paid</span>
                    <span className="text-blue-600">${booking.fare.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* ✅ Actions */}
            <div className="flex gap-4">
              <button
                onClick={() => window.print()}
                className="flex-1 px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors flex items-center justify-center gap-2"
              >
                <Printer size={20} />
                Print Ticket
              </button>
              <button
                onClick={() => window.print()}
                className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
              >
                <Download size={20} />
                Download
              </button>
            </div>

            <div className="mt-6 text-center">
              <button
                onClick={() => navigate('/customer/dashboard')}
                className="text-blue-600 hover:text-blue-700"
              >
                ← Back to Dashboard
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
