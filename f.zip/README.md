
  # Train Ticket Booking System

  This is a code bundle for Train Ticket Booking System. The original project is available at https://www.figma.com/design/me1EDMgtNS2aeq8WqmgLSx/Train-Ticket-Booking-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  