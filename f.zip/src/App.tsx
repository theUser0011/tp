import { useState } from 'react';
import { Toaster } from './components/ui/sonner';
import AdminLogin from './components/admin/AdminLogin';
import AdminDashboard from './components/admin/AdminDashboard';
import TrainRegistration from './components/admin/TrainRegistration';
import TrainList from './components/admin/TrainList';
import TrainUpdate from './components/admin/TrainUpdate';
import CustomerLogin from './components/customer/CustomerLogin';
import CustomerRegistration from './components/customer/CustomerRegistration';
import CustomerDashboard from './components/customer/CustomerDashboard';
import CustomerProfile from './components/customer/CustomerProfile';
import AccountDeactivate from './components/customer/AccountDeactivate';
import TrainSearch from './components/booking/TrainSearch';
import TrainResults from './components/booking/TrainResults';
import TicketBooking from './components/booking/TicketBooking';
import TicketDetails from './components/booking/TicketDetails';
import TicketCancellation from './components/booking/TicketCancellation';
import BookingHistory from './components/booking/BookingHistory';

export type UserRole = 'admin' | 'customer' | null;

export interface Train {
  id: string;
  trainNumber: string;
  trainName: string;
  origin: string;
  destination: string;
  stops: Array<{
    station: string;
    arrival: string;
    departure: string;
  }>;
}

export interface Booking {
  id: string;
  trainNumber: string;
  trainName: string;
  date: string;
  origin: string;
  destination: string;
  class: string;
  seats: number;
  fare: number;
  status: 'Confirmed' | 'Cancelled';
}

function App() {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [selectedTrain, setSelectedTrain] = useState<Train | null>(null);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [searchParams, setSearchParams] = useState<any>(null);

  const handleAdminLogin = () => {
    setUserRole('admin');
    setCurrentPage('admin-dashboard');
  };

  const handleCustomerLogin = () => {
    setUserRole('customer');
    setCurrentPage('customer-dashboard');
  };

  const handleLogout = () => {
    setUserRole(null);
    setCurrentPage('home');
  };

  const navigateTo = (page: string, data?: any) => {
    setCurrentPage(page);
    if (data) {
      if (data.train) setSelectedTrain(data.train);
      if (data.booking) setSelectedBooking(data.booking);
      if (data.searchParams) setSearchParams(data.searchParams);
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
            <div className="max-w-4xl w-full">
              <div className="text-center mb-8">
                <h1 className="text-5xl mb-4">🚄 Train Ticket Booking System</h1>
                <p className="text-gray-600">Modern, Fast, and Reliable</p>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <button
                  onClick={() => setCurrentPage('admin-login')}
                  className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow"
                >
                  <div className="text-4xl mb-4">👨‍💼</div>
                  <h2 className="text-2xl mb-2">Admin Portal</h2>
                  <p className="text-gray-600">Manage trains and schedules</p>
                </button>
                <button
                  onClick={() => setCurrentPage('customer-login')}
                  className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow"
                >
                  <div className="text-4xl mb-4">👤</div>
                  <h2 className="text-2xl mb-2">Customer Portal</h2>
                  <p className="text-gray-600">Book and manage your tickets</p>
                </button>
              </div>
            </div>
          </div>
        );
      
      // Admin Pages
      case 'admin-login':
        return <AdminLogin onLogin={handleAdminLogin} onBack={() => setCurrentPage('home')} />;
      case 'admin-dashboard':
        return <AdminDashboard onNavigate={navigateTo} onLogout={handleLogout} />;
      case 'train-registration':
        return <TrainRegistration onNavigate={navigateTo} onLogout={handleLogout} />;
      case 'train-list':
        return <TrainList onNavigate={navigateTo} onLogout={handleLogout} />;
      case 'train-update':
        return <TrainUpdate train={selectedTrain} onNavigate={navigateTo} onLogout={handleLogout} />;
      
      // Customer Pages
      case 'customer-login':
        return <CustomerLogin onLogin={handleCustomerLogin} onRegister={() => setCurrentPage('customer-registration')} onBack={() => setCurrentPage('home')} />;
      case 'customer-registration':
        return <CustomerRegistration onRegister={handleCustomerLogin} onBack={() => setCurrentPage('customer-login')} />;
      case 'customer-dashboard':
        return <CustomerDashboard onNavigate={navigateTo} onLogout={handleLogout} />;
      case 'customer-profile':
        return <CustomerProfile onNavigate={navigateTo} onLogout={handleLogout} />;
      case 'account-deactivate':
        return <AccountDeactivate onNavigate={navigateTo} onLogout={handleLogout} />;
      
      // Booking Pages
      case 'train-search':
        return <TrainSearch onNavigate={navigateTo} onLogout={handleLogout} />;
      case 'train-results':
        return <TrainResults searchParams={searchParams} onNavigate={navigateTo} onLogout={handleLogout} />;
      case 'ticket-booking':
        return <TicketBooking train={selectedTrain} searchParams={searchParams} onNavigate={navigateTo} onLogout={handleLogout} />;
      case 'ticket-details':
        return <TicketDetails booking={selectedBooking} onNavigate={navigateTo} onLogout={handleLogout} />;
      case 'ticket-cancellation':
        return <TicketCancellation onNavigate={navigateTo} onLogout={handleLogout} />;
      case 'booking-history':
        return <BookingHistory onNavigate={navigateTo} onLogout={handleLogout} />;
      
      default:
        return <div>Page not found</div>;
    }
  };

  return (
    <div className="app">
      {renderPage()}
      <Toaster position="top-right" richColors closeButton />
    </div>
  );
}

export default App;
