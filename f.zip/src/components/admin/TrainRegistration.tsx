import { useState } from 'react';
import { Train, LayoutDashboard, List, Plus, Trash2, Save } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import DashboardLayout from '../shared/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Button } from '../ui/button';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '../ui/accordion';

interface AdminDashboardProps {
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

interface Stop {
  station: string;
  arrival: string;
  departure: string;
}

export default function TrainRegistration({ onNavigate, onLogout }: AdminDashboardProps) {
  const [trainNumber, setTrainNumber] = useState('');
  const [trainName, setTrainName] = useState('');
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [stops, setStops] = useState<Stop[]>([]);

  const sidebarItems = [
    {
      icon: <LayoutDashboard className="w-5 h-5" />,
      label: 'Dashboard',
      onClick: () => onNavigate('admin-dashboard'),
    },
    {
      icon: <Train className="w-5 h-5" />,
      label: 'Train Registration',
      onClick: () => onNavigate('train-registration'),
      active: true,
    },
    {
      icon: <List className="w-5 h-5" />,
      label: 'Train List',
      onClick: () => onNavigate('train-list'),
    },
  ];

  const addStop = () => {
    setStops([...stops, { station: '', arrival: '', departure: '' }]);
  };

  const removeStop = (index: number) => {
    setStops(stops.filter((_, i) => i !== index));
  };

  const updateStop = (index: number, field: keyof Stop, value: string) => {
    const newStops = [...stops];
    newStops[index][field] = value;
    setStops(newStops);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Train Registered Successfully!', {
      description: `Train ${trainNumber} - ${trainName} has been added to the system.`,
    });
    
    // Reset form after success
    setTimeout(() => {
      setTrainNumber('');
      setTrainName('');
      setOrigin('');
      setDestination('');
      setStops([]);
    }, 1000);
  };

  return (
    <DashboardLayout
      title="Train Registration"
      sidebarItems={sidebarItems}
      onLogout={onLogout}
    >
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Register New Train</CardTitle>
            <CardDescription>Add a new train to the system with complete route details</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit}>
              <Accordion type="single" collapsible defaultValue="basic" className="w-full">
                <AccordionItem value="basic">
                  <AccordionTrigger>Basic Information</AccordionTrigger>
                  <AccordionContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4">
                      <div className="space-y-2">
                        <Label htmlFor="trainNumber">Train Number *</Label>
                        <Input
                          id="trainNumber"
                          placeholder="e.g., 12345"
                          value={trainNumber}
                          onChange={(e) => setTrainNumber(e.target.value)}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="trainName">Train Name *</Label>
                        <Input
                          id="trainName"
                          placeholder="e.g., Rajdhani Express"
                          value={trainName}
                          onChange={(e) => setTrainName(e.target.value)}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="origin">Origin Station *</Label>
                        <Input
                          id="origin"
                          placeholder="e.g., New Delhi"
                          value={origin}
                          onChange={(e) => setOrigin(e.target.value)}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="destination">Destination Station *</Label>
                        <Input
                          id="destination"
                          placeholder="e.g., Mumbai Central"
                          value={destination}
                          onChange={(e) => setDestination(e.target.value)}
                          required
                        />
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="stops">
                  <AccordionTrigger>Intermediate Stops</AccordionTrigger>
                  <AccordionContent>
                    <div className="p-4 space-y-4">
                      {stops.map((stop, index) => (
                        <Card key={index} className="border-2">
                          <CardContent className="pt-6">
                            <div className="flex items-start gap-4">
                              <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div className="space-y-2">
                                  <Label>Station Name</Label>
                                  <Input
                                    placeholder="Station"
                                    value={stop.station}
                                    onChange={(e) => updateStop(index, 'station', e.target.value)}
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>Arrival Time</Label>
                                  <Input
                                    type="time"
                                    value={stop.arrival}
                                    onChange={(e) => updateStop(index, 'arrival', e.target.value)}
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>Departure Time</Label>
                                  <Input
                                    type="time"
                                    value={stop.departure}
                                    onChange={(e) => updateStop(index, 'departure', e.target.value)}
                                  />
                                </div>
                              </div>
                              <Button
                                type="button"
                                variant="destructive"
                                size="icon"
                                onClick={() => removeStop(index)}
                                className="mt-8"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}

                      <Button
                        type="button"
                        variant="outline"
                        onClick={addStop}
                        className="w-full"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Intermediate Stop
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>

              <div className="flex justify-end gap-4 mt-6">
                <Button type="button" variant="outline" onClick={() => onNavigate('admin-dashboard')}>
                  Cancel
                </Button>
                <Button type="submit">
                  <Save className="w-4 h-4 mr-2" />
                  Register Train
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
