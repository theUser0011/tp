import { Train, Edit, Trash2, LayoutDashboard, List } from 'lucide-react';
import DashboardLayout from '../shared/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';

interface AdminDashboardProps {
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export default function AdminDashboard({ onNavigate, onLogout }: AdminDashboardProps) {
  const sidebarItems = [
    {
      icon: <LayoutDashboard className="w-5 h-5" />,
      label: 'Dashboard',
      onClick: () => onNavigate('admin-dashboard'),
      active: true,
    },
    {
      icon: <Train className="w-5 h-5" />,
      label: 'Train Registration',
      onClick: () => onNavigate('train-registration'),
    },
    {
      icon: <List className="w-5 h-5" />,
      label: 'Train List',
      onClick: () => onNavigate('train-list'),
    },
  ];

  const stats = [
    { title: 'Total Trains', value: '47', icon: Train, color: 'bg-blue-500' },
    { title: 'Active Routes', value: '23', icon: List, color: 'bg-green-500' },
    { title: 'Recent Updates', value: '8', icon: Edit, color: 'bg-orange-500' },
    { title: 'Pending Changes', value: '3', icon: Trash2, color: 'bg-purple-500' },
  ];

  return (
    <DashboardLayout
      title="Admin Dashboard"
      sidebarItems={sidebarItems}
      onLogout={onLogout}
    >
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl mb-2">Welcome, Admin!</h2>
          <p className="text-gray-600">Manage your train schedules and routes</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm">{stat.title}</CardTitle>
                <div className={`${stat.color} p-2 rounded-lg text-white`}>
                  <stat.icon className="w-4 h-4" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <div>
          <h3 className="text-xl mb-4">Quick Actions</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('train-registration')}>
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-2">
                  <Train className="w-6 h-6 text-blue-600" />
                </div>
                <CardTitle>Register New Train</CardTitle>
                <CardDescription>Add a new train to the system</CardDescription>
              </CardHeader>
            </Card>

            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('train-list')}>
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-2">
                  <List className="w-6 h-6 text-green-600" />
                </div>
                <CardTitle>View All Trains</CardTitle>
                <CardDescription>Manage existing train records</CardDescription>
              </CardHeader>
            </Card>

            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('train-list')}>
              <CardHeader>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-2">
                  <Edit className="w-6 h-6 text-orange-600" />
                </div>
                <CardTitle>Update Schedules</CardTitle>
                <CardDescription>Modify train timings and routes</CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest updates and changes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { action: 'Train #12345 registered', time: '2 hours ago', type: 'success' },
                { action: 'Route updated for Train #67890', time: '5 hours ago', type: 'info' },
                { action: 'Train #54321 schedule modified', time: '1 day ago', type: 'warning' },
              ].map((activity, index) => (
                <div key={index} className="flex items-center gap-4 pb-4 border-b last:border-0">
                  <div className={`w-2 h-2 rounded-full ${
                    activity.type === 'success' ? 'bg-green-500' :
                    activity.type === 'info' ? 'bg-blue-500' : 'bg-orange-500'
                  }`} />
                  <div className="flex-1">
                    <p>{activity.action}</p>
                    <p className="text-sm text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
