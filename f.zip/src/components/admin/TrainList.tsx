import { useState } from 'react';
import { Train, LayoutDashboard, List, Edit, Trash2, Search } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import DashboardLayout from '../shared/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '../ui/alert-dialog';

interface TrainListProps {
  onNavigate: (page: string, data?: any) => void;
  onLogout: () => void;
}

interface TrainData {
  id: string;
  trainNumber: string;
  trainName: string;
  origin: string;
  destination: string;
  stops: Array<{ station: string; arrival: string; departure: string }>;
  schedule: string;
}

export default function TrainList({ onNavigate, onLogout }: TrainListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedTrainId, setSelectedTrainId] = useState<string | null>(null);

  const sidebarItems = [
    {
      icon: <LayoutDashboard className="w-5 h-5" />,
      label: 'Dashboard',
      onClick: () => onNavigate('admin-dashboard'),
    },
    {
      icon: <Train className="w-5 h-5" />,
      label: 'Train Registration',
      onClick: () => onNavigate('train-registration'),
    },
    {
      icon: <List className="w-5 h-5" />,
      label: 'Train List',
      onClick: () => onNavigate('train-list'),
      active: true,
    },
  ];

  // Mock data
  const [trains, setTrains] = useState<TrainData[]>([
    {
      id: '1',
      trainNumber: '12301',
      trainName: 'Rajdhani Express',
      origin: 'New Delhi',
      destination: 'Mumbai Central',
      stops: [
        { station: 'Vadodara', arrival: '04:30', departure: '04:35' },
        { station: 'Surat', arrival: '06:15', departure: '06:20' },
      ],
      schedule: 'Daily',
    },
    {
      id: '2',
      trainNumber: '12951',
      trainName: 'Mumbai Rajdhani',
      origin: 'Mumbai',
      destination: 'New Delhi',
      stops: [
        { station: 'Kota', arrival: '22:40', departure: '22:45' },
      ],
      schedule: 'Daily',
    },
    {
      id: '3',
      trainNumber: '12423',
      trainName: 'Dibrugarh Rajdhani',
      origin: 'New Delhi',
      destination: 'Dibrugarh',
      stops: [
        { station: 'Lucknow', arrival: '23:00', departure: '23:10' },
        { station: 'Guwahati', arrival: '19:30', departure: '19:45' },
      ],
      schedule: 'Daily',
    },
    {
      id: '4',
      trainNumber: '12009',
      trainName: 'Shatabdi Express',
      origin: 'New Delhi',
      destination: 'Lucknow',
      stops: [
        { station: 'Kanpur', arrival: '11:30', departure: '11:35' },
      ],
      schedule: 'Mon-Sat',
    },
    {
      id: '5',
      trainNumber: '22691',
      trainName: 'Bangalore Rajdhani',
      origin: 'Bangalore',
      destination: 'New Delhi',
      stops: [
        { station: 'Pune', arrival: '07:15', departure: '07:20' },
        { station: 'Vadodara', arrival: '13:45', departure: '13:50' },
      ],
      schedule: 'Daily',
    },
  ]);

  const filteredTrains = trains.filter(train =>
    train.trainNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    train.trainName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    train.origin.toLowerCase().includes(searchQuery.toLowerCase()) ||
    train.destination.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleEdit = (train: TrainData) => {
    onNavigate('train-update', { train });
  };

  const handleDeleteClick = (trainId: string) => {
    setSelectedTrainId(trainId);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = () => {
    if (selectedTrainId) {
      const deletedTrain = trains.find(t => t.id === selectedTrainId);
      setTrains(trains.filter(t => t.id !== selectedTrainId));
      toast.success('Train Deleted Successfully', {
        description: `Train ${deletedTrain?.trainNumber} - ${deletedTrain?.trainName} has been removed.`,
      });
    }
    setDeleteDialogOpen(false);
    setSelectedTrainId(null);
  };

  return (
    <DashboardLayout
      title="Train List"
      sidebarItems={sidebarItems}
      onLogout={onLogout}
    >
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <CardTitle>All Trains</CardTitle>
            <div className="flex items-center gap-2 w-full md:w-auto">
              <div className="relative flex-1 md:w-80">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search trains..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Train Number</TableHead>
                  <TableHead>Train Name</TableHead>
                  <TableHead>Route</TableHead>
                  <TableHead>Schedule</TableHead>
                  <TableHead>Stops</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTrains.map((train) => (
                  <TableRow key={train.id}>
                    <TableCell>{train.trainNumber}</TableCell>
                    <TableCell>{train.trainName}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span>{train.origin}</span>
                        <span className="text-gray-400">→</span>
                        <span>{train.destination}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">
                        {train.schedule}
                      </span>
                    </TableCell>
                    <TableCell>{train.stops.length} stops</TableCell>
                    <TableCell>
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(train)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteClick(train.id)}
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredTrains.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <Train className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No trains found matching your search.</p>
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the train
              from the system.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
}
