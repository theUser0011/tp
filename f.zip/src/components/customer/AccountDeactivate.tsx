import { useState } from 'react';
import { User, UserX, Search, Ticket, XCircle, History, LayoutDashboard, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import DashboardLayout from '../shared/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '../ui/alert-dialog';
import { Checkbox } from '../ui/checkbox';
import { Label } from '../ui/label';

interface AccountDeactivateProps {
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export default function AccountDeactivate({ onNavigate, onLogout }: AccountDeactivateProps) {
  const [confirmChecked, setConfirmChecked] = useState(false);

  const sidebarItems = [
    {
      icon: <LayoutDashboard className="w-5 h-5" />,
      label: 'Dashboard',
      onClick: () => onNavigate('customer-dashboard'),
    },
    {
      icon: <User className="w-5 h-5" />,
      label: 'Update Profile',
      onClick: () => onNavigate('customer-profile'),
    },
    {
      icon: <Search className="w-5 h-5" />,
      label: 'Search Trains',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <Ticket className="w-5 h-5" />,
      label: 'Book Ticket',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <XCircle className="w-5 h-5" />,
      label: 'Cancel Ticket',
      onClick: () => onNavigate('ticket-cancellation'),
    },
    {
      icon: <History className="w-5 h-5" />,
      label: 'Booking History',
      onClick: () => onNavigate('booking-history'),
    },
    {
      icon: <UserX className="w-5 h-5" />,
      label: 'Deactivate Account',
      onClick: () => onNavigate('account-deactivate'),
      active: true,
    },
  ];

  const handleDeactivate = () => {
    toast.warning('Account Deactivated', {
      description: 'Your account has been deactivated. You will be logged out.',
    });
    
    // Simulate account deactivation
    setTimeout(() => {
      onLogout();
    }, 1500);
  };

  return (
    <DashboardLayout
      title="Deactivate Account"
      sidebarItems={sidebarItems}
      onLogout={onLogout}
    >
      <div className="max-w-2xl mx-auto">
        <Card className="border-red-200">
          <CardHeader>
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
            <CardTitle className="text-center text-red-600">Deactivate Your Account</CardTitle>
            <CardDescription className="text-center">
              This action will permanently deactivate your account
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-red-50 border border-red-200 rounded-lg p-6">
              <h3 className="text-red-900 mb-4">⚠️ Warning</h3>
              <p className="text-red-800 mb-4">
                Before you proceed, please note the following:
              </p>
              <ul className="space-y-2 text-red-800 list-disc list-inside">
                <li>All your active bookings will be cancelled</li>
                <li>You will lose access to your booking history</li>
                <li>Your profile information will be permanently deleted</li>
                <li>This action cannot be undone</li>
                <li>You will need to create a new account to use our services again</li>
              </ul>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox 
                id="confirm"
                checked={confirmChecked}
                onCheckedChange={(checked) => setConfirmChecked(checked as boolean)}
              />
              <Label 
                htmlFor="confirm" 
                className="text-sm cursor-pointer leading-relaxed"
              >
                I understand that deactivating my account is permanent and cannot be reversed. 
                I want to proceed with account deactivation.
              </Label>
            </div>

            <div className="flex gap-4">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => onNavigate('customer-dashboard')}
              >
                Cancel
              </Button>
              
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button 
                    variant="destructive" 
                    className="flex-1"
                    disabled={!confirmChecked}
                  >
                    <UserX className="w-4 h-4 mr-2" />
                    Deactivate Account
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will permanently deactivate your account and delete all your data.
                      You will be logged out immediately.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction 
                      onClick={handleDeactivate}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      Yes, Deactivate My Account
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
