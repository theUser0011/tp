import { useState } from 'react';
import { LogIn, ArrowLeft, UserPlus } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Button } from '../ui/button';

interface CustomerLoginProps {
  onLogin: () => void;
  onRegister: () => void;
  onBack: () => void;
}

export default function CustomerLogin({ onLogin, onRegister, onBack }: CustomerLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Mock validation - check for demo credentials
    if (email === 'customer@example.com' && password === 'customer123') {
      toast.success('Login Successful!', {
        description: `Welcome back, ${email}!`,
      });
      setTimeout(() => onLogin(), 500);
    } else if (email && password) {
      // Accept any credentials for demo
      toast.success('Login Successful!', {
        description: `Welcome, ${email}!`,
      });
      setTimeout(() => onLogin(), 500);
    } else {
      toast.error('Login Failed', {
        description: 'Please enter valid email and password',
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>

        <Card className="shadow-xl">
          <CardHeader className="space-y-1">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-3xl">👤</span>
            </div>
            <CardTitle className="text-center text-2xl">Customer Login</CardTitle>
            <CardDescription className="text-center">
              Sign in to book your train tickets
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>

              <Button type="submit" className="w-full">
                <LogIn className="w-4 h-4 mr-2" />
                Login
              </Button>

              <div className="text-center text-sm text-gray-500 mt-4">
                Demo: customer@example.com / customer123
              </div>

              <div className="text-center pt-4 border-t">
                <p className="text-sm text-gray-600 mb-3">Don't have an account?</p>
                <Button
                  type="button"
                  variant="outline"
                  onClick={onRegister}
                  className="w-full"
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Create Account
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
