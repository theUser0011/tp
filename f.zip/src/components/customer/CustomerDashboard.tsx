import { User, UserX, Search, Ticket, XCircle, History, LayoutDashboard } from 'lucide-react';
import DashboardLayout from '../shared/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';

interface CustomerDashboardProps {
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export default function CustomerDashboard({ onNavigate, onLogout }: CustomerDashboardProps) {
  const sidebarItems = [
    {
      icon: <LayoutDashboard className="w-5 h-5" />,
      label: 'Dashboard',
      onClick: () => onNavigate('customer-dashboard'),
      active: true,
    },
    {
      icon: <User className="w-5 h-5" />,
      label: 'Update Profile',
      onClick: () => onNavigate('customer-profile'),
    },
    {
      icon: <Search className="w-5 h-5" />,
      label: 'Search Trains',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <Ticket className="w-5 h-5" />,
      label: 'Book Ticket',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <XCircle className="w-5 h-5" />,
      label: 'Cancel Ticket',
      onClick: () => onNavigate('ticket-cancellation'),
    },
    {
      icon: <History className="w-5 h-5" />,
      label: 'Booking History',
      onClick: () => onNavigate('booking-history'),
    },
    {
      icon: <UserX className="w-5 h-5" />,
      label: 'Deactivate Account',
      onClick: () => onNavigate('account-deactivate'),
    },
  ];

  const quickStats = [
    { title: 'Active Bookings', value: '3', icon: Ticket, color: 'bg-green-500' },
    { title: 'Cancelled', value: '1', icon: XCircle, color: 'bg-red-500' },
    { title: 'Total Trips', value: '12', icon: History, color: 'bg-blue-500' },
  ];

  return (
    <DashboardLayout
      title="Customer Dashboard"
      sidebarItems={sidebarItems}
      onLogout={onLogout}
      headerActions={
        <div className="flex items-center gap-3">
          <div className="text-right hidden md:block">
            <p className="text-sm">Welcome back,</p>
            <p>John Doe</p>
          </div>
          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
            <User className="w-5 h-5 text-green-600" />
          </div>
        </div>
      }
    >
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl mb-2">Welcome back, John!</h2>
          <p className="text-gray-600">Book your next journey with ease</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {quickStats.map((stat, index) => (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm">{stat.title}</CardTitle>
                <div className={`${stat.color} p-2 rounded-lg text-white`}>
                  <stat.icon className="w-4 h-4" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <div>
          <h3 className="text-xl mb-4">Quick Actions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('train-search')}>
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-2">
                  <Search className="w-6 h-6 text-blue-600" />
                </div>
                <CardTitle>Search Trains</CardTitle>
                <CardDescription>Find trains for your journey</CardDescription>
              </CardHeader>
            </Card>

            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('train-search')}>
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-2">
                  <Ticket className="w-6 h-6 text-green-600" />
                </div>
                <CardTitle>Book Ticket</CardTitle>
                <CardDescription>Reserve your seat now</CardDescription>
              </CardHeader>
            </Card>

            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('booking-history')}>
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-2">
                  <History className="w-6 h-6 text-purple-600" />
                </div>
                <CardTitle>View History</CardTitle>
                <CardDescription>Check your past bookings</CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>

        {/* Recent Bookings */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Bookings</CardTitle>
            <CardDescription>Your latest ticket reservations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { train: 'Rajdhani Express #12301', route: 'New Delhi → Mumbai', date: 'Nov 15, 2025', status: 'Confirmed' },
                { train: 'Shatabdi Express #12009', route: 'New Delhi → Lucknow', date: 'Nov 20, 2025', status: 'Confirmed' },
                { train: 'Mumbai Rajdhani #12951', route: 'Mumbai → New Delhi', date: 'Nov 10, 2025', status: 'Cancelled' },
              ].map((booking, index) => (
                <div key={index} className="flex items-center justify-between pb-4 border-b last:border-0">
                  <div className="flex-1">
                    <p>{booking.train}</p>
                    <p className="text-sm text-gray-500">{booking.route}</p>
                    <p className="text-sm text-gray-500">{booking.date}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs ${
                    booking.status === 'Confirmed' 
                      ? 'bg-green-100 text-green-700' 
                      : 'bg-red-100 text-red-700'
                  }`}>
                    {booking.status}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
