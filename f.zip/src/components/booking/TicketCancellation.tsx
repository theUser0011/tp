import { useState } from 'react';
import { User, UserX, Search, Ticket, XCircle, History, LayoutDashboard, AlertTriangle } from 'lucide-react';
import DashboardLayout from '../shared/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Button } from '../ui/button';
import { Alert, AlertDescription } from '../ui/alert';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '../ui/alert-dialog';

interface TicketCancellationProps {
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export default function TicketCancellation({ onNavigate, onLogout }: TicketCancellationProps) {
  const [ticketId, setTicketId] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [cancelled, setCancelled] = useState(false);

  const sidebarItems = [
    {
      icon: <LayoutDashboard className="w-5 h-5" />,
      label: 'Dashboard',
      onClick: () => onNavigate('customer-dashboard'),
    },
    {
      icon: <User className="w-5 h-5" />,
      label: 'Update Profile',
      onClick: () => onNavigate('customer-profile'),
    },
    {
      icon: <Search className="w-5 h-5" />,
      label: 'Search Trains',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <Ticket className="w-5 h-5" />,
      label: 'Book Ticket',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <XCircle className="w-5 h-5" />,
      label: 'Cancel Ticket',
      onClick: () => onNavigate('ticket-cancellation'),
      active: true,
    },
    {
      icon: <History className="w-5 h-5" />,
      label: 'Booking History',
      onClick: () => onNavigate('booking-history'),
    },
    {
      icon: <UserX className="w-5 h-5" />,
      label: 'Deactivate Account',
      onClick: () => onNavigate('account-deactivate'),
    },
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (ticketId) {
      setShowConfirmation(true);
    }
  };

  const handleConfirmCancellation = () => {
    setCancelled(true);
    setShowConfirmation(false);
    
    setTimeout(() => {
      setTicketId('');
      setCancelled(false);
    }, 5000);
  };

  return (
    <DashboardLayout
      title="Cancel Ticket"
      sidebarItems={sidebarItems}
      onLogout={onLogout}
    >
      <div className="max-w-3xl mx-auto">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <XCircle className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <CardTitle>Cancel Your Ticket</CardTitle>
                <CardDescription>Enter your ticket ID to cancel your booking</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {cancelled && (
              <Alert className="bg-green-50 border-green-200">
                <AlertDescription className="text-green-800">
                  ✓ Ticket cancelled successfully! Refund will be processed within 5-7 business days.
                </AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSearch} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="ticketId">Ticket ID / Booking ID *</Label>
                <Input
                  id="ticketId"
                  placeholder="e.g., TKT123456"
                  value={ticketId}
                  onChange={(e) => setTicketId(e.target.value.toUpperCase())}
                  required
                />
                <p className="text-sm text-gray-500">
                  You can find your Ticket ID in your booking confirmation
                </p>
              </div>

              <Button type="submit" className="w-full">
                <Search className="w-4 h-4 mr-2" />
                Find Ticket
              </Button>
            </form>

            {/* Cancellation Policy */}
            <div className="border-t pt-6">
              <h3 className="mb-4 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600" />
                Cancellation Policy
              </h3>
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="space-y-3 text-sm">
                  <div className="flex items-start gap-2">
                    <span className="text-orange-600 mt-0.5">•</span>
                    <div>
                      <span className="text-orange-900">More than 48 hours before departure:</span>
                      <p className="text-orange-800">Full refund (minus cancellation charges)</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-orange-600 mt-0.5">•</span>
                    <div>
                      <span className="text-orange-900">24-48 hours before departure:</span>
                      <p className="text-orange-800">50% refund</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-orange-600 mt-0.5">•</span>
                    <div>
                      <span className="text-orange-900">4-24 hours before departure:</span>
                      <p className="text-orange-800">25% refund</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-orange-600 mt-0.5">•</span>
                    <div>
                      <span className="text-orange-900">Less than 4 hours before departure:</span>
                      <p className="text-orange-800">No refund</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-orange-600 mt-0.5">•</span>
                    <div>
                      <p className="text-orange-800">Cancellation charges: ₹50 per ticket</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Bookings */}
            <div className="border-t pt-6">
              <h3 className="mb-4">Your Recent Bookings</h3>
              <div className="space-y-3">
                {[
                  { id: 'TKT9A7B3C', train: 'Rajdhani Express #12301', date: 'Nov 15, 2025', status: 'Confirmed' },
                  { id: 'TKT8D5E2F', train: 'Shatabdi Express #12009', date: 'Nov 20, 2025', status: 'Confirmed' },
                ].map((booking) => (
                  <div
                    key={booking.id}
                    className="border rounded-lg p-4 hover:border-blue-500 cursor-pointer transition-colors"
                    onClick={() => setTicketId(booking.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p>{booking.train}</p>
                        <p className="text-sm text-gray-500">{booking.date}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-500">Ticket ID</p>
                        <p className="text-blue-600">{booking.id}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Confirmation Dialog */}
        <AlertDialog open={showConfirmation} onOpenChange={setShowConfirmation}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirm Ticket Cancellation</AlertDialogTitle>
              <AlertDialogDescription className="space-y-2">
                <p>Are you sure you want to cancel this ticket?</p>
                <div className="bg-gray-50 p-4 rounded-lg mt-4">
                  <p className="text-sm"><span className="text-gray-600">Ticket ID:</span> {ticketId}</p>
                  <p className="text-sm"><span className="text-gray-600">Train:</span> Rajdhani Express #12301</p>
                  <p className="text-sm"><span className="text-gray-600">Date:</span> Nov 15, 2025</p>
                  <p className="text-sm mt-2"><span className="text-gray-600">Refund Amount:</span> ₹2,055 (after cancellation charges)</p>
                </div>
                <p className="text-sm text-red-600 mt-4">This action cannot be undone.</p>
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>No, Keep Ticket</AlertDialogCancel>
              <AlertDialogAction 
                onClick={handleConfirmCancellation}
                className="bg-red-600 hover:bg-red-700"
              >
                Yes, Cancel Ticket
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </DashboardLayout>
  );
}
