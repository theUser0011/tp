import { User, UserX, Search, Ticket, XCircle, History, LayoutDashboard, Clock, IndianRupee } from 'lucide-react';
import DashboardLayout from '../shared/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';

interface TrainResultsProps {
  searchParams: any;
  onNavigate: (page: string, data?: any) => void;
  onLogout: () => void;
}

export default function TrainResults({ searchParams, onNavigate, onLogout }: TrainResultsProps) {
  const sidebarItems = [
    {
      icon: <LayoutDashboard className="w-5 h-5" />,
      label: 'Dashboard',
      onClick: () => onNavigate('customer-dashboard'),
    },
    {
      icon: <User className="w-5 h-5" />,
      label: 'Update Profile',
      onClick: () => onNavigate('customer-profile'),
    },
    {
      icon: <Search className="w-5 h-5" />,
      label: 'Search Trains',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <Ticket className="w-5 h-5" />,
      label: 'Book Ticket',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <XCircle className="w-5 h-5" />,
      label: 'Cancel Ticket',
      onClick: () => onNavigate('ticket-cancellation'),
    },
    {
      icon: <History className="w-5 h-5" />,
      label: 'Booking History',
      onClick: () => onNavigate('booking-history'),
    },
    {
      icon: <UserX className="w-5 h-5" />,
      label: 'Deactivate Account',
      onClick: () => onNavigate('account-deactivate'),
    },
  ];

  const trains = [
    {
      id: '1',
      trainNumber: '12301',
      trainName: 'Rajdhani Express',
      departure: '16:55',
      arrival: '08:35',
      duration: '15h 40m',
      classes: [
        { name: 'AC 1st Class', price: 3500, available: 12 },
        { name: 'AC 2-Tier', price: 2100, available: 45 },
        { name: 'AC 3-Tier', price: 1450, available: 89 },
      ],
    },
    {
      id: '2',
      trainNumber: '12951',
      trainName: 'Mumbai Rajdhani',
      departure: '17:05',
      arrival: '08:50',
      duration: '15h 45m',
      classes: [
        { name: 'AC 1st Class', price: 3600, available: 8 },
        { name: 'AC 2-Tier', price: 2200, available: 32 },
        { name: 'AC 3-Tier', price: 1500, available: 67 },
      ],
    },
    {
      id: '3',
      trainNumber: '12009',
      trainName: 'Shatabdi Express',
      departure: '06:10',
      arrival: '12:30',
      duration: '6h 20m',
      classes: [
        { name: 'AC Chair Car', price: 850, available: 78 },
        { name: 'Executive Class', price: 1650, available: 24 },
      ],
    },
  ];

  const handleBookNow = (train: any) => {
    onNavigate('ticket-booking', { train, searchParams });
  };

  return (
    <DashboardLayout
      title="Available Trains"
      sidebarItems={sidebarItems}
      onLogout={onLogout}
    >
      <div className="max-w-5xl mx-auto">
        {/* Search Summary */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-wrap items-center gap-4 text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-500">From:</span>
                <span>{searchParams?.origin || 'New Delhi'}</span>
              </div>
              <span className="text-gray-400">→</span>
              <div className="flex items-center gap-2">
                <span className="text-gray-500">To:</span>
                <span>{searchParams?.destination || 'Mumbai Central'}</span>
              </div>
              <span className="text-gray-400">|</span>
              <div className="flex items-center gap-2">
                <span className="text-gray-500">Date:</span>
                <span>{searchParams?.travelDate || 'Nov 15, 2025'}</span>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                className="ml-auto"
                onClick={() => onNavigate('train-search')}
              >
                Modify Search
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Train Results */}
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl">{trains.length} trains found</h2>
          </div>

          {trains.map((train) => (
            <Card key={train.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <CardTitle className="flex items-center gap-3">
                      <span>{train.trainName}</span>
                      <Badge variant="outline">#{train.trainNumber}</Badge>
                    </CardTitle>
                    <CardDescription className="mt-1">
                      {searchParams?.origin || 'New Delhi'} → {searchParams?.destination || 'Mumbai Central'}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-center">
                      <div className="text-2xl">{train.departure}</div>
                      <div className="text-xs text-gray-500">Departure</div>
                    </div>
                    <div className="flex flex-col items-center px-4">
                      <Clock className="w-4 h-4 text-gray-400 mb-1" />
                      <div className="text-sm">{train.duration}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl">{train.arrival}</div>
                      <div className="text-xs text-gray-500">Arrival</div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {train.classes.map((cls, index) => (
                    <div
                      key={index}
                      className="border rounded-lg p-4 flex flex-col justify-between hover:border-blue-500 transition-colors"
                    >
                      <div>
                        <div className="mb-2">{cls.name}</div>
                        <div className="flex items-center gap-1 text-green-600 mb-2">
                          <IndianRupee className="w-4 h-4" />
                          <span className="text-xl">{cls.price}</span>
                        </div>
                        <div className="text-sm text-gray-500">
                          {cls.available} seats available
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className="mt-4 w-full"
                        onClick={() => handleBookNow({ ...train, selectedClass: cls })}
                      >
                        Book Now
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {trains.length === 0 && (
          <Card>
            <CardContent className="text-center py-12">
              <div className="text-gray-500">
                <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No trains found for your search criteria.</p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => onNavigate('train-search')}
                >
                  Search Again
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
