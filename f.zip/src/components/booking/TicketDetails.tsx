import { User, UserX, Search, Ticket, XCircle, History, LayoutDashboard, Download, Printer, CheckCircle, IndianRupee, Calendar, Clock, MapPin } from 'lucide-react';
import DashboardLayout from '../shared/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Separator } from '../ui/separator';

interface TicketDetailsProps {
  booking: any;
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export default function TicketDetails({ booking, onNavigate, onLogout }: TicketDetailsProps) {
  const sidebarItems = [
    {
      icon: <LayoutDashboard className="w-5 h-5" />,
      label: 'Dashboard',
      onClick: () => onNavigate('customer-dashboard'),
    },
    {
      icon: <User className="w-5 h-5" />,
      label: 'Update Profile',
      onClick: () => onNavigate('customer-profile'),
    },
    {
      icon: <Search className="w-5 h-5" />,
      label: 'Search Trains',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <Ticket className="w-5 h-5" />,
      label: 'Book Ticket',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <XCircle className="w-5 h-5" />,
      label: 'Cancel Ticket',
      onClick: () => onNavigate('ticket-cancellation'),
    },
    {
      icon: <History className="w-5 h-5" />,
      label: 'Booking History',
      onClick: () => onNavigate('booking-history'),
    },
    {
      icon: <UserX className="w-5 h-5" />,
      label: 'Deactivate Account',
      onClick: () => onNavigate('account-deactivate'),
    },
  ];

  const handlePrint = () => {
    window.print();
  };

  return (
    <DashboardLayout
      title="Ticket Details"
      sidebarItems={sidebarItems}
      onLogout={onLogout}
    >
      <div className="max-w-4xl mx-auto">
        {/* Success Message */}
        <div className="bg-green-50 border-2 border-green-200 rounded-lg p-6 mb-6 text-center">
          <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-2xl text-green-800 mb-2">Booking Confirmed!</h2>
          <p className="text-green-700">Your ticket has been successfully booked</p>
        </div>

        {/* Ticket Card */}
        <Card className="print:shadow-none">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-800 text-white rounded-t-lg">
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl">E-Ticket</CardTitle>
              <div className="text-right">
                <div className="text-sm opacity-90">Booking ID</div>
                <div className="text-xl">{booking?.id || 'TKT123456'}</div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-8 space-y-6">
            {/* Passenger Details */}
            <div>
              <h3 className="mb-4 flex items-center gap-2">
                <User className="w-5 h-5" />
                Passenger Information
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-gray-50 p-4 rounded-lg">
                <div>
                  <span className="text-sm text-gray-600">Name</span>
                  <p>John Doe</p>
                </div>
                <div>
                  <span className="text-sm text-gray-600">Age</span>
                  <p>30 years</p>
                </div>
                <div>
                  <span className="text-sm text-gray-600">Gender</span>
                  <p>Male</p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Journey Details */}
            <div>
              <h3 className="mb-4 flex items-center gap-2">
                <Ticket className="w-5 h-5" />
                Journey Details
              </h3>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <span className="text-sm text-gray-600">From</span>
                      <p className="text-lg">{booking?.origin || 'New Delhi'}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-6 h-6 text-red-600" />
                    </div>
                    <div>
                      <span className="text-sm text-gray-600">To</span>
                      <p className="text-lg">{booking?.destination || 'Mumbai Central'}</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-blue-50 p-4 rounded-lg">
                  <div>
                    <span className="text-sm text-gray-600 flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      Date
                    </span>
                    <p>{booking?.date || 'Nov 15, 2025'}</p>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600 flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      Departure
                    </span>
                    <p>16:55</p>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600 flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      Arrival
                    </span>
                    <p>08:35 (Next Day)</p>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Train & Class Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="mb-3">Train Information</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Train Number:</span>
                    <span>{booking?.trainNumber || '12301'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Train Name:</span>
                    <span>{booking?.trainName || 'Rajdhani Express'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Class:</span>
                    <span>{booking?.class || 'AC 2-Tier'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Seats:</span>
                    <span>{booking?.seats || 1}</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="mb-3">Fare Details</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total Fare:</span>
                    <span className="flex items-center text-green-600">
                      <IndianRupee className="w-4 h-4" />
                      {booking?.fare || 2205}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
                      {booking?.status || 'Confirmed'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">PNR Status:</span>
                    <span className="text-green-600">CNF</span>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Actions */}
            <div className="flex flex-wrap gap-4 print:hidden">
              <Button onClick={handlePrint} variant="outline" className="flex-1">
                <Printer className="w-4 h-4 mr-2" />
                Print Ticket
              </Button>
              <Button variant="outline" className="flex-1">
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
              <Button onClick={() => onNavigate('customer-dashboard')} className="flex-1">
                Go to Dashboard
              </Button>
            </div>

            {/* Important Notes */}
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 text-sm">
              <h4 className="mb-2">Important Information:</h4>
              <ul className="space-y-1 text-gray-700 list-disc list-inside">
                <li>Please carry a valid ID proof during your journey</li>
                <li>Report at the station at least 20 minutes before departure</li>
                <li>Cancellation allowed up to 4 hours before departure</li>
                <li>Keep this ticket handy for verification</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
