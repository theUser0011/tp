import { useState } from 'react';
import { User, UserX, Search, Ticket, XCircle, History, LayoutDashboard, Filter, Eye, Download, IndianRupee } from 'lucide-react';
import DashboardLayout from '../shared/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Badge } from '../ui/badge';

interface BookingHistoryProps {
  onNavigate: (page: string, data?: any) => void;
  onLogout: () => void;
}

export default function BookingHistory({ onNavigate, onLogout }: BookingHistoryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const sidebarItems = [
    {
      icon: <LayoutDashboard className="w-5 h-5" />,
      label: 'Dashboard',
      onClick: () => onNavigate('customer-dashboard'),
    },
    {
      icon: <User className="w-5 h-5" />,
      label: 'Update Profile',
      onClick: () => onNavigate('customer-profile'),
    },
    {
      icon: <Search className="w-5 h-5" />,
      label: 'Search Trains',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <Ticket className="w-5 h-5" />,
      label: 'Book Ticket',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <XCircle className="w-5 h-5" />,
      label: 'Cancel Ticket',
      onClick: () => onNavigate('ticket-cancellation'),
    },
    {
      icon: <History className="w-5 h-5" />,
      label: 'Booking History',
      onClick: () => onNavigate('booking-history'),
      active: true,
    },
    {
      icon: <UserX className="w-5 h-5" />,
      label: 'Deactivate Account',
      onClick: () => onNavigate('account-deactivate'),
    },
  ];

  const bookings = [
    {
      id: 'TKT9A7B3C',
      date: '2025-11-15',
      trainNumber: '12301',
      trainName: 'Rajdhani Express',
      route: 'New Delhi → Mumbai Central',
      class: 'AC 2-Tier',
      seats: 2,
      fare: 4410,
      status: 'Confirmed',
      pnr: 'CNF',
    },
    {
      id: 'TKT8D5E2F',
      date: '2025-11-20',
      trainNumber: '12009',
      trainName: 'Shatabdi Express',
      route: 'New Delhi → Lucknow',
      class: 'AC Chair Car',
      seats: 1,
      fare: 850,
      status: 'Confirmed',
      pnr: 'CNF',
    },
    {
      id: 'TKT7C4A1B',
      date: '2025-11-10',
      trainNumber: '12951',
      trainName: 'Mumbai Rajdhani',
      route: 'Mumbai → New Delhi',
      class: 'AC 3-Tier',
      seats: 3,
      fare: 4350,
      status: 'Cancelled',
      pnr: 'CAN',
    },
    {
      id: 'TKT6B9D8E',
      date: '2025-10-28',
      trainNumber: '12423',
      trainName: 'Dibrugarh Rajdhani',
      route: 'New Delhi → Dibrugarh',
      class: 'AC 2-Tier',
      seats: 2,
      fare: 5200,
      status: 'Confirmed',
      pnr: 'CNF',
    },
    {
      id: 'TKT5E3F7A',
      date: '2025-10-15',
      trainNumber: '22691',
      trainName: 'Bangalore Rajdhani',
      route: 'Bangalore → New Delhi',
      class: 'AC 1st Class',
      seats: 1,
      fare: 6500,
      status: 'Confirmed',
      pnr: 'CNF',
    },
    {
      id: 'TKT4D2C1B',
      date: '2025-10-05',
      trainNumber: '12009',
      trainName: 'Shatabdi Express',
      route: 'Lucknow → New Delhi',
      class: 'Executive Class',
      seats: 1,
      fare: 1650,
      status: 'Confirmed',
      pnr: 'CNF',
    },
  ];

  const filteredBookings = bookings.filter(booking => {
    const matchesSearch = 
      booking.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      booking.trainName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      booking.trainNumber.includes(searchQuery);
    
    const matchesStatus = 
      statusFilter === 'all' || 
      booking.status.toLowerCase() === statusFilter.toLowerCase();
    
    return matchesSearch && matchesStatus;
  });

  const handleViewDetails = (booking: any) => {
    onNavigate('ticket-details', { booking });
  };

  return (
    <DashboardLayout
      title="Booking History"
      sidebarItems={sidebarItems}
      onLogout={onLogout}
    >
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <CardTitle>Your Bookings</CardTitle>
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto">
              <div className="relative flex-1 sm:w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search by ticket ID or train..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-40">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="confirmed">Confirmed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Desktop Table View */}
          <div className="hidden md:block border rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Ticket ID</TableHead>
                  <TableHead>Train</TableHead>
                  <TableHead>Route</TableHead>
                  <TableHead>Class</TableHead>
                  <TableHead>Seats</TableHead>
                  <TableHead>Fare</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredBookings.map((booking) => (
                  <TableRow key={booking.id}>
                    <TableCell>{new Date(booking.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</TableCell>
                    <TableCell>
                      <code className="text-xs bg-gray-100 px-2 py-1 rounded">{booking.id}</code>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div>{booking.trainName}</div>
                        <div className="text-xs text-gray-500">#{booking.trainNumber}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">{booking.route}</div>
                    </TableCell>
                    <TableCell>{booking.class}</TableCell>
                    <TableCell>{booking.seats}</TableCell>
                    <TableCell>
                      <div className="flex items-center text-green-600">
                        <IndianRupee className="w-3 h-3" />
                        {booking.fare}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={booking.status === 'Confirmed' ? 'default' : 'destructive'}
                        className={booking.status === 'Confirmed' ? 'bg-green-500' : ''}
                      >
                        {booking.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleViewDetails(booking)}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Mobile Card View */}
          <div className="md:hidden space-y-4">
            {filteredBookings.map((booking) => (
              <Card key={booking.id} className="border-2">
                <CardContent className="pt-6">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <p>{booking.trainName}</p>
                        <p className="text-sm text-gray-500">#{booking.trainNumber}</p>
                      </div>
                      <Badge 
                        variant={booking.status === 'Confirmed' ? 'default' : 'destructive'}
                        className={booking.status === 'Confirmed' ? 'bg-green-500' : ''}
                      >
                        {booking.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600">{booking.route}</div>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-gray-500">Date:</span> {new Date(booking.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </div>
                      <div>
                        <span className="text-gray-500">Class:</span> {booking.class}
                      </div>
                      <div>
                        <span className="text-gray-500">Seats:</span> {booking.seats}
                      </div>
                      <div className="flex items-center text-green-600">
                        <IndianRupee className="w-3 h-3" />
                        {booking.fare}
                      </div>
                    </div>
                    <div className="text-xs text-gray-500">
                      Ticket ID: <code className="bg-gray-100 px-2 py-1 rounded">{booking.id}</code>
                    </div>
                    <div className="flex gap-2 pt-2">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex-1"
                        onClick={() => handleViewDetails(booking)}
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        View
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1">
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredBookings.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No bookings found matching your search.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
