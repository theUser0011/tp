import { useState } from 'react';
import { User, UserX, Search, Ticket, XCircle, History, LayoutDashboard, IndianRupee, Users } from 'lucide-react';
import DashboardLayout from '../shared/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Separator } from '../ui/separator';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '../ui/alert-dialog';

interface TicketBookingProps {
  train: any;
  searchParams: any;
  onNavigate: (page: string, data?: any) => void;
  onLogout: () => void;
}

export default function TicketBooking({ train, searchParams, onNavigate, onLogout }: TicketBookingProps) {
  const [numSeats, setNumSeats] = useState('1');
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);

  const sidebarItems = [
    {
      icon: <LayoutDashboard className="w-5 h-5" />,
      label: 'Dashboard',
      onClick: () => onNavigate('customer-dashboard'),
    },
    {
      icon: <User className="w-5 h-5" />,
      label: 'Update Profile',
      onClick: () => onNavigate('customer-profile'),
    },
    {
      icon: <Search className="w-5 h-5" />,
      label: 'Search Trains',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <Ticket className="w-5 h-5" />,
      label: 'Book Ticket',
      onClick: () => onNavigate('train-search'),
      active: true,
    },
    {
      icon: <XCircle className="w-5 h-5" />,
      label: 'Cancel Ticket',
      onClick: () => onNavigate('ticket-cancellation'),
    },
    {
      icon: <History className="w-5 h-5" />,
      label: 'Booking History',
      onClick: () => onNavigate('booking-history'),
    },
    {
      icon: <UserX className="w-5 h-5" />,
      label: 'Deactivate Account',
      onClick: () => onNavigate('account-deactivate'),
    },
  ];

  const baseFare = train?.selectedClass?.price || 2100;
  const seats = parseInt(numSeats) || 1;
  const subtotal = baseFare * seats;
  const tax = Math.round(subtotal * 0.05);
  const total = subtotal + tax;

  const handleConfirmBooking = () => {
    const booking = {
      id: 'TKT' + Math.random().toString(36).substr(2, 9).toUpperCase(),
      trainNumber: train?.trainNumber || '12301',
      trainName: train?.trainName || 'Rajdhani Express',
      date: searchParams?.travelDate || 'Nov 15, 2025',
      origin: searchParams?.origin || 'New Delhi',
      destination: searchParams?.destination || 'Mumbai Central',
      class: train?.selectedClass?.name || 'AC 2-Tier',
      seats: seats,
      fare: total,
      status: 'Confirmed' as const,
    };
    
    setConfirmDialogOpen(false);
    onNavigate('ticket-details', { booking });
  };

  return (
    <DashboardLayout
      title="Book Ticket"
      sidebarItems={sidebarItems}
      onLogout={onLogout}
    >
      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Booking Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Booking Details</CardTitle>
                <CardDescription>Complete your ticket reservation</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Train Information */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h3 className="mb-3">Train Information</h3>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <span className="text-gray-600">Train:</span>
                      <p>{train?.trainName || 'Rajdhani Express'} (#{train?.trainNumber || '12301'})</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Class:</span>
                      <p>{train?.selectedClass?.name || 'AC 2-Tier'}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">From:</span>
                      <p>{searchParams?.origin || 'New Delhi'}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">To:</span>
                      <p>{searchParams?.destination || 'Mumbai Central'}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Date:</span>
                      <p>{searchParams?.travelDate || 'Nov 15, 2025'}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Time:</span>
                      <p>{train?.departure || '16:55'} - {train?.arrival || '08:35'}</p>
                    </div>
                  </div>
                </div>

                {/* Passenger Details */}
                <div className="space-y-4">
                  <h3>Passenger Information</h3>
                  
                  <div className="space-y-2">
                    <Label htmlFor="numSeats">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        <span>Number of Seats *</span>
                      </div>
                    </Label>
                    <Select value={numSeats} onValueChange={setNumSeats}>
                      <SelectTrigger id="numSeats">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 5, 6].map(num => (
                          <SelectItem key={num} value={num.toString()}>
                            {num} {num === 1 ? 'Seat' : 'Seats'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Passenger Name *</Label>
                      <Input id="name" placeholder="John Doe" defaultValue="John Doe" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="age">Age *</Label>
                      <Input id="age" type="number" placeholder="25" defaultValue="30" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="gender">Gender *</Label>
                      <Select defaultValue="male">
                        <SelectTrigger id="gender">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="male">Male</SelectItem>
                          <SelectItem value="female">Female</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="contact">Contact Number *</Label>
                      <Input id="contact" type="tel" placeholder="9876543210" defaultValue="9876543210" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Fare Summary */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle>Fare Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Base Fare × {seats}</span>
                    <span className="flex items-center">
                      <IndianRupee className="w-3 h-3" />
                      {subtotal}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">GST (5%)</span>
                    <span className="flex items-center">
                      <IndianRupee className="w-3 h-3" />
                      {tax}
                    </span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span>Total Amount</span>
                    <span className="flex items-center text-green-600">
                      <IndianRupee className="w-4 h-4" />
                      <span className="text-xl">{total}</span>
                    </span>
                  </div>
                </div>

                <Button 
                  className="w-full" 
                  size="lg"
                  onClick={() => setConfirmDialogOpen(true)}
                >
                  Confirm Booking
                </Button>

                <div className="text-xs text-gray-500 text-center">
                  You can cancel your ticket up to 4 hours before departure
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Confirmation Dialog */}
        <AlertDialog open={confirmDialogOpen} onOpenChange={setConfirmDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirm Your Booking</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to book {seats} {seats === 1 ? 'seat' : 'seats'} on {train?.trainName || 'Rajdhani Express'} 
                from {searchParams?.origin || 'New Delhi'} to {searchParams?.destination || 'Mumbai Central'} 
                for ₹{total}?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleConfirmBooking}>
                Confirm & Pay
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </DashboardLayout>
  );
}
