import { useState } from 'react';
import { User, UserX, Search, Ticket, XCircle, History, LayoutDashboard, Train, Calendar, MapPin } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import DashboardLayout from '../shared/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';

interface TrainSearchProps {
  onNavigate: (page: string, data?: any) => void;
  onLogout: () => void;
}

export default function TrainSearch({ onNavigate, onLogout }: TrainSearchProps) {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [travelDate, setTravelDate] = useState('');

  const sidebarItems = [
    {
      icon: <LayoutDashboard className="w-5 h-5" />,
      label: 'Dashboard',
      onClick: () => onNavigate('customer-dashboard'),
    },
    {
      icon: <User className="w-5 h-5" />,
      label: 'Update Profile',
      onClick: () => onNavigate('customer-profile'),
    },
    {
      icon: <Search className="w-5 h-5" />,
      label: 'Search Trains',
      onClick: () => onNavigate('train-search'),
      active: true,
    },
    {
      icon: <Ticket className="w-5 h-5" />,
      label: 'Book Ticket',
      onClick: () => onNavigate('train-search'),
    },
    {
      icon: <XCircle className="w-5 h-5" />,
      label: 'Cancel Ticket',
      onClick: () => onNavigate('ticket-cancellation'),
    },
    {
      icon: <History className="w-5 h-5" />,
      label: 'Booking History',
      onClick: () => onNavigate('booking-history'),
    },
    {
      icon: <UserX className="w-5 h-5" />,
      label: 'Deactivate Account',
      onClick: () => onNavigate('account-deactivate'),
    },
  ];

  const stations = [
    'New Delhi',
    'Mumbai Central',
    'Bangalore',
    'Chennai',
    'Kolkata',
    'Hyderabad',
    'Pune',
    'Ahmedabad',
    'Jaipur',
    'Lucknow',
    'Kanpur',
    'Vadodara',
    'Surat',
    'Guwahati',
    'Dibrugarh',
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    toast.info('Searching for trains...', {
      description: `${origin} → ${destination} on ${travelDate}`,
    });
    
    setTimeout(() => {
      onNavigate('train-results', {
        searchParams: { origin, destination, travelDate }
      });
    }, 500);
  };

  // Get tomorrow's date as minimum
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const minDate = tomorrow.toISOString().split('T')[0];

  return (
    <DashboardLayout
      title="Search Trains"
      sidebarItems={sidebarItems}
      onLogout={onLogout}
    >
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Train className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <CardTitle>Find Your Train</CardTitle>
                <CardDescription>Search for available trains on your route</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSearch} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="origin">
                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="w-4 h-4 text-green-600" />
                      <span>From (Origin Station) *</span>
                    </div>
                  </Label>
                  <Select value={origin} onValueChange={setOrigin} required>
                    <SelectTrigger id="origin">
                      <SelectValue placeholder="Select origin station" />
                    </SelectTrigger>
                    <SelectContent>
                      {stations.map((station) => (
                        <SelectItem key={station} value={station}>
                          {station}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="destination">
                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="w-4 h-4 text-red-600" />
                      <span>To (Destination Station) *</span>
                    </div>
                  </Label>
                  <Select value={destination} onValueChange={setDestination} required>
                    <SelectTrigger id="destination">
                      <SelectValue placeholder="Select destination station" />
                    </SelectTrigger>
                    <SelectContent>
                      {stations.filter(s => s !== origin).map((station) => (
                        <SelectItem key={station} value={station}>
                          {station}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="travelDate">
                    <div className="flex items-center gap-2 mb-2">
                      <Calendar className="w-4 h-4 text-blue-600" />
                      <span>Date of Journey *</span>
                    </div>
                  </Label>
                  <Input
                    id="travelDate"
                    type="date"
                    value={travelDate}
                    onChange={(e) => setTravelDate(e.target.value)}
                    min={minDate}
                    required
                  />
                </div>
              </div>

              <Button type="submit" className="w-full" size="lg">
                <Search className="w-5 h-5 mr-2" />
                Search Trains
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Popular Routes */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Popular Routes</CardTitle>
            <CardDescription>Frequently searched train routes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { from: 'New Delhi', to: 'Mumbai Central' },
                { from: 'Mumbai Central', to: 'Bangalore' },
                { from: 'New Delhi', to: 'Lucknow' },
                { from: 'Chennai', to: 'Bangalore' },
              ].map((route, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setOrigin(route.from);
                    setDestination(route.to);
                  }}
                  className="p-4 border-2 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all text-left"
                >
                  <div className="flex items-center gap-2">
                    <span>{route.from}</span>
                    <span className="text-gray-400">→</span>
                    <span>{route.to}</span>
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
